<?php

class SystemSetting{

private $system;

function getSetting(){
	
$system['login_role_refrech']='active';

$system['camp_role_refresh']='active'; 

$system['support_advertiser_tab']='active';

$system['support_publisher_tab']='active';

return $system;

	}

}

$system = new SystemSetting;

?>