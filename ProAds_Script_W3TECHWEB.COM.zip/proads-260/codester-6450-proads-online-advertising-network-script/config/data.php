<?php

 /*
 |--------------------------------------------------------------------------
 | Configuration & Connection & Functions & Models
 |--------------------------------------------------------------------------
 |
 | Load config file getting info.
 | load database connector file.
 | Load our functions file.
 | Load our smarty model files.
 |
 */

 if (!file_exists(dirname(__DIR__).'/config/app.php')):
     
 require_once (dirname(__DIR__).'/config/models/configModel.php');

 else:
     
 require_once ('config.php');
 
 endif;

 require_once (CONNECT.'dbconnect.class.php');

 require_once (MODELS.'smartyModel.php');

 require_once (CONFIG.'function.php');

 require_once (MODELS.'functionModel.php');

 if (DB_ERR && $info->install == 'on'):

 errorAndDie('Missing database parameter');

 endif;
 
 if (empty(HOST)):

 $HOST = $hs->site_url();

 else:
    
 $HOST = HOST;

 endif;

 //ON
 
 if ($info->install == 'on'):

 $uid = $se->new_session('user','logged','uid');

 $smart->users($uid);
 
 $smart->sign_option();
 
 if (isset($uid)):
     
 $user = $query->addquery('select','tbl_user','*','i', $uid,'user_id=?');
 
 endif;

 $GoMail = new UserMailer;

 $up = new Uploader;

 $pm = new Checkouts;

 //OFF
 elseif (!isset($_SERVER['REQUEST_URI'])):
  
 Redirect(['controller'=> 'installer','action'=> 'index']);
 
 elseif(isset($_SERVER['REQUEST_URI'])):
 
 if(!isset($_SESSION['ACCESS'])):
 
 $_SESSION['ACCESS'] = str_replace('/','',ACCESS);
 
 endif;
 
 if(ACCESS != DS.$_SESSION['ACCESS'].INSTALL_FILE && ACCESS != DS.$_SESSION['ACCESS'].DATABASE_FILE && ACCESS != DS.$_SESSION['ACCESS'].BUILD_FILE && ACCESS != DS.$_SESSION['ACCESS'].ADMIN_FILE):
 
 $HOST = $HOST.$_SESSION['ACCESS'].DS;
 
 Redirect(['controller'=> 'installer','action'=> 'index']);
 
 endif;
 
 endif;