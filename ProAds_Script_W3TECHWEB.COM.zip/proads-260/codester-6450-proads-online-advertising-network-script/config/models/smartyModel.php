<?php

 class smartyModel extends SystemSetting{
  
 public function users($id){
 
 global $smarty;
 
 switch ($id):
    
 case '0':

 case NULL:

 define('IsLogged',false);

 $smarty->assign('notlogged', true);
  
 $smarty->assign('logged',false);
 
 break;

 default:
 
 define('IsLogged',true);

 $smarty->assign('logged', true);

 $smarty->assign('notlogged',false);
 
 break;

 endswitch;

  }
 
 public function sign_option(){
     
 global $smarty,$query,$info,$option,$uid,$HOST;

 $this->system=parent::getSetting();

 $option = $query->opt_all('value,header','tbl_config');

 $smarty->assign('support_advertiser_tab',$this->system['support_advertiser_tab']); 

 $smarty->assign('support_publisher_tab',$this->system['support_publisher_tab']); 

 $smarty->assign('HOST',$HOST); 
 
 $smarty->assign('site_url',$_SERVER['HTTP_HOST']); 

 $smarty->assign('THEME',Theme);
 
 $smarty->assign('date',Year);
 
 $smarty->assign('name',$option['0']['0']);
 
 $smarty->assign('ref_percent',$option['1']['0']);
 
 $smarty->assign('min_deposit',$option['2']['0']);

 $smarty->assign('sumbole',$option['3']['0']);

 $smarty->assign('with_min',$option['4']['0']);
 
 $smarty->assign('reCAPTCHA_site_key',$option['5']['0']);
 
 $smarty->assign('reCAPTCHA_secret_key',$option['6']['0']);

 $smarty->assign('fake_deals',$option['7']['0']);

 $smarty->assign('Favicon_url',$option['8']['0']);

 $smarty->assign('site_description',$option['9']['0']);

 $smarty->assign('site_title',$option['10']['0']);

 $smarty->assign('keywords',$option['65']['0']);

 $smarty->assign('language',$option['12']['0']);

 $smarty->assign('support_email',$option['13']['0']);

 $smarty->assign('code_head',$option['14']['0']);

 $smarty->assign('footer_code',base64_decode($option['15']['0']));
 
 $smarty->assign('currency',$option['17']['0']);

 $smarty->assign('APPversion',$info->version);

 $smarty->assign('banner_728x90',$option['22']['0']);
 
 $smarty->assign('banner_468x60',$option['23']['0']);
 
 $smarty->assign('banner_336x280',$option['24']['0']);
 
 $smarty->assign('banner_300x250',$option['25']['0']);
 
 $smarty->assign('banner_300x600',$option['26']['0']);
 
 $smarty->assign('Logo',$option['27']['0']);

 $smarty->assign('Logo2',$option['28']['0']);
 
 $smarty->assign('activate_email',$option['29']['0']);

 $smarty->assign('member_head',$option['32']['0']);

 $smarty->assign('admin_head',$option['33']['0']);
 
 $smarty->assign('admin_percent',$option['40']['0']);

 $smarty->assign('enable_note',$option['42']['0']);

 $smarty->assign('body_code',$option['43']['0']);
 
 $smarty->assign('auth_head',$option['44']['0']);

 $smarty->assign('home_color',$option['46']['0']);

 $smarty->assign('captcha_signup',$option['54']['0']);

 $smarty->assign('captcha_login',$option['55']['0']);
 
 $smarty->assign('captcha_forgot',$option['56']['0']);
 
 $smarty->assign('banner_120x600',$option['61']['0']);
 
 $smarty->assign('banner_200x200',$option['62']['0']);
 
 $smarty->assign('banner_125x125',$option['63']['0']);

 $smarty->assign('enable_sites_category',$option['66']['0']);

 $smarty->assign('enable_rcd_tabs',$option['67']['0']);

 $smarty->assign('enable_send_info',$option['68']['0']);

 $smarty->assign('enable_text_b',$option['69']['0']);

 $smarty->assign('disable_advertiser',$option['70']['0']);

 $smarty->assign('disable_publishers',$option['71']['0']);

 $smarty->assign('max_ip_day',$option['72']['0']);

 $data = $query->addquery('select','deposite_methods','count(id) as depositcount');
 
 $smarty->assign('depositcount',$data->depositcount);

 $data = $query->addquery('select','tbl_withdrawal','count(withdrawal_id) as withdrawal_nu');
 
 $smarty->assign('withdrawal_nu',$data->withdrawal_nu);
 
 $data = $query->addquery('select','tbl_user','count(user_id) as user_n');
 
 $smarty->assign('user_n',$data->user_n);
 
//pending amount of withdrawals

$data = $query->addquery('select','tbl_withdrawal','count(withdrawal_id) as withdrawal_id','i','2','status=?');

$smarty->assign('withdrawal_id',number_format($data->withdrawal_id));

 //Deposits Methods
 
 $data = $query->addquery('select','deposite_methods','status','s','Bitcoin','methods=?');
 
 $smarty->assign('Bitcoin_status',$data->status);
 
 $data = $query->addquery('select','deposite_methods','status','s','PayPal','methods=?');
 
 $smarty->assign('PayPal_status',$data->status);
 
 $data = $query->addquery('select','deposite_methods','status','s','Payza','methods=?');
 
 $smarty->assign('Payza_status',$data->status);
 
 $data = $query->addquery('select','deposite_methods','status','s','Discover','methods=?');
 
 $smarty->assign('Discover_status',$data->status);
 
 $data = $query->addquery('select','deposite_methods','status','s','AmericanExpress','methods=?');
 
 $smarty->assign('AmericanExpress_status',$data->status);
 
 $data = $query->addquery('select','deposite_methods','status','s','DinersClub','methods=?');
 
 $smarty->assign('DinersClub_status',$data->status);
 
 $data = $query->addquery('select','deposite_methods','status','s','MasterCard','methods=?');
 
 $smarty->assign('MasterCard_status',$data->status);

 $data = $query->addquery('select','deposite_methods','status','s','Visa','methods=?');
 
 $smarty->assign('Visa_status',$data->status);
 
 $data = $query->addquery('select','tbl_config','value','s','enable_bank','header=?');
 
 $smarty->assign('bank_status',$data->value);
 
 $data = $query->addquery('select','tbl_config','value','s','bank_account','header=?');
 
 $smarty->assign('bank_account',$data->value);
 
 if (isset($uid)):

 $user = $query->addquery('select','tbl_user','*','i', $uid,'user_id=?');
 
 $smarty->assign('role',$user->role);

 endif;
 
 }
 
 public function sign_user_fun(){
 
 global $smarty,$query,$option,$uid,$HOST,$RESdate,$RESip,$mail_option,$mail_host,$mail_port,$mail_ssluse,$mail_pass,$mail_username;

 $user = $query->addquery('select','tbl_user','*','i', $uid,'user_id=?');
 
 //username
 $smarty->assign('username',$user->username);

 //ads
 $smarty->assign('ads_persite',$option['38']['0']);

 $smarty->assign('ads_perpage',$option['39']['0']);

 //site_urlnon
 $smarty->assign('site_urlnon',$HOST);

 //COLOR
 $smarty->assign('dashboard_color',$option['45']['0']);

 //websites
 $smarty->assign('site_status',$option['34']['0']);

 //Ref
 $smarty->assign('referral_publisher',$option['16']['0']);

 //MIN_PRICE==CPC
 $smarty->assign('cpc_click',$option['41']['0']);

 //MIN_PRICE==CPM
 $smarty->assign('views_min',$option['36']['0']);

 //MIN_CLICK==CPC
 $smarty->assign('clicks_min',$option['37']['0']);

 //MIN_VIEWS==CPM
 $smarty->assign('cpm_views',$option['35']['0']);

 //MIN_POP_PRICE==CPM
 $smarty->assign('cpm_pop',$option['47']['0']);
 
 $smarty->assign('cpc_pop',$option['48']['0']);

 //MIN_POP_CLICKS==CPC
 $smarty->assign('pop_clicks',$option['50']['0']);

 //MIN_POP_VIEWS==CPM
 $smarty->assign('pop_views',$option['51']['0']);

 //MIN_DIRECT_PRICE
 $smarty->assign('cpm_direct',$option[49][0]);

 //MIN_DIRECT_HITS
 $smarty->assign('direct_hits',$option[52][0]);

 $smarty->assign('enable_banners',$option['30']['0']);

 $smarty->assign('enable_popups',$option['31']['0']);
  
 $smarty->assign('enable_direct',$option['64']['0']);
     
 //mailer
 $smarty->assign('mail_option',$mail_option);

 $smarty->assign('mail_host',$mail_host);

 $smarty->assign('mail_port',$mail_port);

 $smarty->assign('mail_ssl',$mail_ssluse);

 $smarty->assign('mail_pass',$mail_pass);

 $smarty->assign('mail_username',$mail_username);

 $data = $query->addquery('select','announcements','count(id) as announcecount');
 
 $smarty->assign('announcecount',number_format($data->announcecount));
 
 $withnote=array();

 $data = $query->limit('log_history','ip,date','id','desc','1','i','1','status=?');
 
 while($res=$data->fetch_assoc()){

 $RESdate = $ipnote=$res['date'];

 $RESip = $ipnote=$res['ip'];

 $ipnote = ['ip'=>$res['ip'],'date'=>$res['date']];

 array_push($withnote,$ipnote);
 
 }
 
 }
 
 public function sign_deposits(){

 global $smarty,$query,$bitcoin,$paypal,$payza,$che2ckout_id,$che2ckout_sec;

 $bitcoin = $query->addquery('select','deposite_methods','*','s', 'Bitcoin','methods=?');
 
 $paypal = $query->addquery('select','deposite_methods','*','s', 'PayPal','methods=?');

 $payza = $query->addquery('select','deposite_methods','*','s', 'Payza','methods=?');
 
 $che2ckout_id = $query->addquery('select','tbl_config','value','s', 'che2ckout_id','header=?');
 
 $che2ckout_sec = $query->addquery('select','tbl_config','value','s', 'che2ckout_secret','header=?');

 //bitcoin
 
 $smarty->assign('bit_processor',$bitcoin->processor);

 $smarty->assign('publick_key',$bitcoin->publick_key);

 $smarty->assign('secret_key',$bitcoin->secret_key);

 $smarty->assign('ipn',$bitcoin->ipn);

 $smarty->assign('merchant_id',$bitcoin->account);

 $smarty->assign('BTCaddress',$bitcoin->address);

 $smarty->assign('coin_curr',$bitcoin->info);

 //paypal
 
 $smarty->assign('paypal_account',$paypal->account);

 //payza
 
 $smarty->assign('payza_account',$payza->account);
 
 //2checkout
 
 $smarty->assign('2checkout_id',$che2ckout_id->value);

 $smarty->assign('2checkout_secret',$che2ckout_sec->value);

 }
 
 public function sign_withdrawals(){
     
 global $smarty,$option,$query,$bitcoin_w,$fhb_w,$paypal_w,$payza_w,$bank_w;

 $bitcoin_w = $query->addquery('select','withdraw_methods','*','s', 'Bitcoin','methods=?');
 
 $fhb_w = $query->addquery('select','withdraw_methods','*','s', 'FaucetHub','methods=?');

 $paypal_w = $query->addquery('select','withdraw_methods','*','s', 'PayPal','methods=?');

 $payza_w = $query->addquery('select','withdraw_methods','*','s', 'Payza','methods=?');
 
 $bank_w = $query->addquery('select','withdraw_methods','*','s', 'BankTransfer','methods=?');

 //bitcoin
 
 $smarty->assign('enable_bitcoin',$bitcoin_w->status);

 $smarty->assign('m_bitcoin',$bitcoin_w->withdraw_min);

 $smarty->assign('f_bitcoin',$bitcoin_w->fee);

 //faucethub
 
 $smarty->assign('enable_fhb',$fhb_w->status);

 $smarty->assign('m_fhb',$fhb_w->withdraw_min);

 $smarty->assign('f_fhb',$fhb_w->fee);

 $smarty->assign('api_fhb',$option['73']['0']);


 //paypal

 $smarty->assign('enable_paypal',$paypal_w->status);
 
 $smarty->assign('m_paypal',$paypal_w->withdraw_min);

 $smarty->assign('f_paypal',$paypal_w->fee);

 //payza
 
 $smarty->assign('enable_payza',$payza_w->status);

 $smarty->assign('m_payza',$payza_w->withdraw_min);
	
 $smarty->assign('f_payza',$payza_w->fee);
 
 //bank transfer

 $smarty->assign('enable_bank',$bank_w->status);
 
 $smarty->assign('m_bank',$bank_w->withdraw_min);
	
 $smarty->assign('f_bank',$bank_w->fee);
	
     
 }
 
 public function sign_style($banner_size){
 
 global $smarty;
 
if($banner_size == '728x90'){
$style = 'width:728px; height:90px;';
$smarty->assign('style',$style);
}

if($banner_size == '468x60'){
$style = 'width:468; height:60px;';
$smarty->assign('style',$style);
}

if($banner_size == '336x280'){
$style = 'width:336px; height:280px;';
$smarty->assign('style',$style);
}

if($banner_size == '300x250'){
$style = 'width:300px; height:250px;';
$smarty->assign('style',$style);
}

if($banner_size == '300x600'){
$style = 'width:300px; height:600px;';
$smarty->assign('style',$style);
}

if($banner_size == '120x600'){
$style = 'width:120px; height:600px;';
$smarty->assign('style',$style);
}

if($banner_size == '200x200'){
$style = 'width:200px; height:200px;';
$smarty->assign('style',$style);
}

if($banner_size == '125x125'){
$style = 'width:125px; height:125px;';
$smarty->assign('style',$style);
}
 
 }

 
 }


$smart = new smartyModel;
