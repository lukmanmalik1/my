<?php


  class functionModel{
    
 public function referer($ref){

 $refer = parse_url($ref);
 
 $refer = isset($refer['host']);
 
 if($refer == $_SERVER['HTTP_HOST'] || $refer == ''){
     
 $refer_domain = 'Direct';
 
 $referer = '';
 
 }else{
     
 $refer_domain = $refer;
 
 $referer = $ref;
 
 }

 
 return (object) ['host'=> $refer_domain,'url'=> $referer];

 }
 
 public function version_($theme){
 
 $server = 'https://codsem.com/proads/server/themes/update?theme='.$theme.'&v=new';

 $ch = curl_init();

 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

 curl_setopt($ch, CURLOPT_URL, $server);

 $result = curl_exec($ch);

 curl_close($ch);

 $arr = json_decode($result, true);

 return $arr['version'];
 
 }

 public function d_banner($dvc,$size,$type,$imploded){
 
 global $query;
 
 $data = $query->normal("select count(id) as num from tbl_banner where banner_device = '$dvc' and banner_type = '$type' and banner_size = '$size' and status = '1' and filter IN ('$imploded')");
 
 return $data->fetch_assoc();
 
 }

 
 
 public function DataCharts($mode,$role){
   
   global $query,$user,$smarty;
   
  //Days of Week
  
  $mon_value= date('d/m/y', strtotime('Monday this week'));

  $tue_value= date('d/m/y', strtotime('Tuesday this week'));

  $wed_value= date('d/m/y', strtotime('Wednesday this week'));

  $thu_value= date('d/m/y', strtotime('Thursday this week'));

  $fri_value= date('d/m/y', strtotime('Friday this week'));

  $sat_value= date('d/m/y', strtotime('Saturday this week'));

  $sun_value= date('d/m/y', strtotime('Sunday this week'));

 switch($role):
 
 case 'pub':
     
 if ($mode == 'clicks'):
     
 //clicks

 $Monday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$mon_value.',0','pub_id=?,date=?,clicks<>?');

 $Tuesday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$tue_value.',0','pub_id=?,date=?,clicks<>?');

 $Wednesday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$wed_value.',0','pub_id=?,date=?,clicks<>?');

 $Thursday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$thu_value.',0','pub_id=?,date=?,clicks<>?');

 $Friday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$fri_value.',0','pub_id=?,date=?,clicks<>?');

 $Saturday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$sat_value.',0','pub_id=?,date=?,clicks<>?');

 $Sunday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$sun_value.',0','pub_id=?,date=?,clicks<>?');

$smarty->assign('MondayClicks',$Monday->clicks);

$smarty->assign('TuesdayClicks',$Tuesday->clicks);

$smarty->assign('WednesdayClicks',$Wednesday->clicks);

$smarty->assign('ThursdayClicks',$Thursday->clicks);

$smarty->assign('FridayClicks',$Friday->clicks);

$smarty->assign('SaturdayClicks',$Saturday->clicks);

$smarty->assign('SundayClicks',$Sunday->clicks);

 else:
 
 //views

 $Monday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$mon_value.',0','pub_id=?,date=?,views<>?');

 $Tuesday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$tue_value.',0','pub_id=?,date=?,views<>?');

 $Wednesday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$wed_value.',0','pub_id=?,date=?,views<>?');

 $Thursday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$thu_value.',0','pub_id=?,date=?,views<>?');

 $Friday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$fri_value.',0','pub_id=?,date=?,views<>?');

 $Saturday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$sat_value.',0','pub_id=?,date=?,views<>?');

 $Sunday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$sun_value.',0','pub_id=?,date=?,views<>?');

$smarty->assign('MondayViews',$Monday->views);

$smarty->assign('TuesdayViews',$Tuesday->views);

$smarty->assign('WednesdayViews',$Wednesday->views);

$smarty->assign('ThursdayViews',$Thursday->views);

$smarty->assign('FridayViews',$Friday->views);

$smarty->assign('SaturdayViews',$Saturday->views);

$smarty->assign('SundayViews',$Sunday->views);

 endif;
 
 break;
 
 case 'adv':
     
 if ($mode == 'clicks'):

 //clicks

 $Monday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$mon_value.',0','adv_id=?,date=?,clicks<>?');

 $Tuesday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$tue_value.',0','adv_id=?,date=?,clicks<>?');

 $Wednesday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$wed_value.',0','adv_id=?,date=?,clicks<>?');

 $Thursday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$thu_value.',0','adv_id=?,date=?,clicks<>?');

 $Friday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$fri_value.',0','adv_id=?,date=?,clicks<>?');

 $Saturday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$sat_value.',0','adv_id=?,date=?,clicks<>?');

 $Sunday = $query->addquery('select','tbl_stat','count(clicks) as clicks','isi',$user->user_id.','.$sun_value.',0','adv_id=?,date=?,clicks<>?');

$smarty->assign('MondayClicks',$Monday->clicks);

$smarty->assign('TuesdayClicks',$Tuesday->clicks);

$smarty->assign('WednesdayClicks',$Wednesday->clicks);

$smarty->assign('ThursdayClicks',$Thursday->clicks);

$smarty->assign('FridayClicks',$Friday->clicks);

$smarty->assign('SaturdayClicks',$Saturday->clicks);

$smarty->assign('SundayClicks',$Sunday->clicks);

 else:
 
 //views

 $Monday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$mon_value.',0','adv_id=?,date=?,views<>?');

 $Tuesday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$tue_value.',0','adv_id=?,date=?,views<>?');

 $Wednesday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$wed_value.',0','adv_id=?,date=?,views<>?');

 $Thursday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$thu_value.',0','adv_id=?,date=?,views<>?');

 $Friday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$fri_value.',0','adv_id=?,date=?,views<>?');

 $Saturday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$sat_value.',0','adv_id=?,date=?,views<>?');

 $Sunday = $query->addquery('select','tbl_stat','count(views) as views','isi',$user->user_id.','.$sun_value.',0','adv_id=?,date=?,views<>?');

$smarty->assign('MondayViews',$Monday->views);

$smarty->assign('TuesdayViews',$Tuesday->views);

$smarty->assign('WednesdayViews',$Wednesday->views);

$smarty->assign('ThursdayViews',$Thursday->views);

$smarty->assign('FridayViews',$Friday->views);

$smarty->assign('SaturdayViews',$Saturday->views);

$smarty->assign('SundayViews',$Sunday->views);

 endif;
 
 break;
 
 endswitch;

    }


}

$fun = new functionModel;