<?php
//================================== Policy ==================================//

//REQUIRED
require_once (dirname(dirname(__FILE__)).'/loader.php');

$smarty->assign('policyp',base64_decode($option['20']['0']));

show('Pages/Policy/index');
//================================== Policy =================================//

?>