<?php
//================================== Policy ==================================//

//REQUIRED
require_once (dirname(dirname(__FILE__)).'/loader.php');


show('Pages/Policy/coockie');
//================================== Policy =================================//

?>