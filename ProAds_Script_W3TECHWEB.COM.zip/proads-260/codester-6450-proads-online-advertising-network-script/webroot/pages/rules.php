<?php

//================================== Rules ==================================//

//REQUIRED
require_once (dirname(dirname(__FILE__)).'/loader.php');

$smarty->assign('rulesp',base64_decode($option['18']['0']));

show('Pages/Terms/rules');
//================================== Rules =================================//

?>