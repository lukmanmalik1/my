<?php

 require_once (dirname(dirname(__FILE__)).'/functions.php');

 if(!isset($_COOKIE['id'])){

 exit('NOT ALLOWED');

 }else{

 $decode_token = base64_decode($_COOKIE['id']);

 $data=$query->addquery('select','tbl_codes','token,code_type,code','is',$user->user_id.','.$decode_token,'user_id=?,token=?');

 $smarty->assign('code_type',$data->code_type);

 if($decode_token == !empty($data->token)){

 $smarty->assign('code',base64_decode($data->code));

 }else{

 exit('Error: NOT FOUND!');

 }
 }

 show('Publisher/Zones/ads');

?>