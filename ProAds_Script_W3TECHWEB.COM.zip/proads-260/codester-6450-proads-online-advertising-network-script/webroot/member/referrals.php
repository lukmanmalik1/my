<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

if ($option[16][0] != '1'):
    
exit('NOT ALLOWED');

endif;

$smarty->assign('uid',$user->user_id);

$data = $query->addquery('select','tbl_user','count(user_id) as countref','i',$user->user_id,'parent_id=?');

$smarty->assign('count',($data->countref)? $data->countref : 0 );

$data = $query->addquery('fetch','tbl_user','*','i',$user->user_id,'parent_id=?');

while($res=$data->fetch_assoc()){

$ar=array('username'=>$res['username'],'status'=>$res['status'],'created'=>$res['created']);

array_push($with,$ar);

}

$smarty->assign('with',$with);

show('Publisher/Profile/referrals');

?>