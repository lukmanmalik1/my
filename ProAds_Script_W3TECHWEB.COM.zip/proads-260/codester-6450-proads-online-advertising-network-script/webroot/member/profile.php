<?php

//================================ PROFILE ====================================>

require_once (dirname(dirname(__FILE__)).'/functions.php');

//allowed payments

$data = $query->addquery('fetch','withdraw_methods','*','i','1','status=?');

while($res=$data->fetch_assoc()){

$ar=array('methods'=>$res['methods'],'status'=>$res['status'],'id'=>$res['id']);

array_push($with,$ar);

}

$smarty->assign('methods',$with);

//profile info

$smarty->assign('first_name',$user->first_name);

$smarty->assign('last_name',$user->last_name);

$smarty->assign('email',$user->email);

$smarty->assign('country',$user->country);

$smarty->assign('withdraw_account',$user->withdrawal_account);

$smarty->assign('withdrawal_method',$user->withdrawal_method);

if(isset($_POST['edit'] ) ){

if($sr->post() == 'true'){

$fname = check_request('first_name');

$lname = check_request('last_name');

$email = check_request('email',false,'email');

$country = check_request('country');

$waccount = check_request('withdrawal_account');

$wmethod = check_request('withdrawal_method');

$query->addquery('update','tbl_user','first_name=?,last_name=?,email=?,country=?,withdrawal_account=?,withdrawal_method=?,modified=?','sssssssi',[$fname,$lname,$email,$country,$waccount,$wmethod,$dateForm,$user->user_id],'user_id=?');

session_acv('success','mess_success');

Redirect(['controller' => 'member', 'action' => 'profile']);
}

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('error','required');

Redirect(['controller' => 'member', 'action' => 'profile']);
}
}
else{

alerts('success','mess_success');

alerts('error','required');

}


if( isset($_POST['pass'] ) ){

$request = check_request('newpassword','md5');

$request = check_request('confnewpassword','md5');

$request = check_request('prepass','md5');

if($sr->post() == 'true' && $request){

$newpass = check_request('newpassword','md5');
	
$Confnewpass = check_request('confnewpassword','md5');

$prepass = check_request('prepass','md5');

$newRecover = check_request('newpassword','base64_encode');

$data = $query->addquery('select','tbl_user','recover','i',$user->user_id,'user_id=?');

$decodeRec = base64_decode($data->recover);

$md5Rec = md5($decodeRec);

if($user->password == $prepass && $newpass == $Confnewpass && $md5Rec == $prepass){

$query->addquery('update','tbl_user','password=?,recover=?','ssi',[$newpass,$newRecover,$user->user_id],'user_id=?');
		
session_acv('success','change');

Redirect(['controller' => 'member', 'action' => 'profile']);

}elseif($newpass != $Confnewpass){

session_acv('errorpass','confirm');

Redirect(['controller' => 'member', 'action' => 'profile']);

}elseif($md5Rec == $prepass){

session_acv('errorpass','unchange');

Redirect(['controller' => 'member', 'action' => 'profile']);
	}
else{

session_acv('errorpass','unchange');

Redirect(['controller' => 'member', 'action' => 'profile']);
	}

}

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('errorpass','required');

Redirect(['controller' => 'member', 'action' => 'profile']);

}

}else{
	    
alerts('success','change');

alerts('errorpass','confirm');

alerts('errorpass','unchange');

alerts('errorpass','required');

}

show('Publisher/Profile/index');

?>