<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

if( isset($_POST['send-message'] ) ){

if($sr->post() == 'true'){

if (empty($option[13][0])):

session_acv('empty_mail','err_mail');

Redirect(['controller' => 'member', 'action' => 'support']);

endif;

$GoMail->message(["from"=> $_POST['mail'],"to"=> $option[13][0],"name" => $_POST['name'],"message" => $_POST['message']]);

session_acv('success','sent');

Redirect(['controller' => 'member', 'action' => 'support']);

}

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('errormail','required');

Redirect(['controller' => 'member', 'action' => 'support']);
 }
}
else{

alerts('success','sent');

alerts('errormail','required');

alerts('empty_mail','err_mail');

}

show('Publisher/Support/index');

?>