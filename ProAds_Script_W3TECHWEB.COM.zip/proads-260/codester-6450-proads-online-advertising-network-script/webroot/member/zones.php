<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('found_code',number_format($query->num_rows('tbl_codes','code_id','i',$user->user_id,'user_id=?')));

$data=$query->limit('tbl_codes','*','code_id','desc',$result['start'].','.$result['perpage'],'i',$user->user_id,'user_id=?');

while($res=$data->fetch_assoc()){

$ar=array('code_id'=>$res['code_id'],'url'=>$res['url'],'site_type'=>$res['site_type'],'code_type'=>$res['code_type'],'status'=>$res['status'],'code_name'=>$res['code_name'],'token'=>$res['token'],'idToken'=>base64_encode($res['token']),'code'=>base64_decode($res['code']),'rcd'=>base64_encode($res['code_id']),'filter'=>str_replace('clean',' ',implode(" ", json_decode($res['filter']))));

array_push($with,$ar);

}

$smarty->assign('with',$with);

$data = number_format($query->num_rows('tbl_link','link_id','i',$user->user_id,'user_id=?'));

$smarty->assign('found_site', $data);

if($data > 0){

if( isset($_POST['post'] ) ){

Redirect(['controller' => 'member', 'action' => 'addzones']);

}
}

if( isset($_POST['get'] ) ){

$request = check_request('c_id');

if ($request):

//24h
setcookie('id', base64_encode($request), time()+60*60*24, 'code.php', $_SERVER['HTTP_HOST']);

Redirect(['controller' => 'member', 'action' => 'code']);

endif;

}

//delete
if( isset($_POST['delete'] ) ){

$request = check_request('cc_id',false,'int');

if ($request):

$query->addquery('delete','tbl_codes',false,'i',$request,'code_id=?');

$_SESSION['success']['delete']=true;

Redirect(['controller' => 'member', 'action' => 'zones']);

endif;

}else{

alerts('success','delete');

alerts('zone','changed');

alerts('zone','deleted');

}

paging($result['screen']+1,ceil($query->num_rows('tbl_codes','*','i',$user->user_id,'user_id=?')/$result['perpage'])+1,'zones?p=');

show('Publisher/Zones/index');

?>