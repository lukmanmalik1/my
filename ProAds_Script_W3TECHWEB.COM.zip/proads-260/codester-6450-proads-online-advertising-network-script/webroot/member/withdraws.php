<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');
	
$data=$query->limit('tbl_withdrawal','*','withdrawal_id','desc',$result['start'].','.$result['perpage'],'i',$user->user_id,'user_id=?');

while($res=$data->fetch_assoc()){

$ar=array('wthid'=>$res['withdrawal_id'],'amount'=>$res['amount'],'fee'=>$res['fee'],'withdrawal_account'=>$res['withdrawal_account'],'withdrawal_method'=>$res['withdrawal_method'],'created'=>$res['created'],'status'=>$res['status']);

array_push($with,$ar);

}

$smarty->assign('with',$with);

paging($result['screen']+1,ceil($query->num_rows('tbl_withdrawal','*','i',$user->user_id,'user_id=?')/$result['perpage'])+1,'withdraws?p=');

show('Publisher/Withdraw/view');

?>