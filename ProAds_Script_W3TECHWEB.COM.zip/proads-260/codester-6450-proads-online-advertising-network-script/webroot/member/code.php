<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

if(!isset($_COOKIE['id']) ){

exit('NOT ALLOWED');

}else{

$decode_token = base64_decode($_COOKIE['id']);

$data=$query->addquery('select','tbl_codes','*','is',"$user->user_id,$decode_token",'user_id=?,token=?');

if($decode_token == $data->token){

$data=$query->addquery('fetch','tbl_codes','*','ii',"$user->user_id,$data->code_id",'user_id=?,code_id=?');

while($res=$data->fetch_assoc()){

$ar=array('code_id'=>$res['code_id'],'url'=>$res['url'],'site_type'=>$res['site_type'],'code_type'=>$res['code_type'],'status'=>$res['status'],'code_name'=>$res['code_name'],'code_balance'=>$res['code_balance'],'code_views'=>$res['code_views'],'code_clicks'=>$res['code_clicks'],'code'=>base64_decode($res['code']));

array_push($with,$ar);

}

$smarty->assign('with',$with);

}
}

show('Publisher/Zones/code');

?>
