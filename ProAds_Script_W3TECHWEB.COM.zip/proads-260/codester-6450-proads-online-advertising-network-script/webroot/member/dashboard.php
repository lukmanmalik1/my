<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('publisher_earnings',$user->publisher_earnings);

$smarty->assign('withdrawal_method',$user->withdrawal_method);

$data = $query->limit('announcements','*','id','desc',$result['screen'].','.$result['perpage'],'i','1','published=?');

while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'title'=>$res['title'],'content'=>$res['content'],'created'=>$res['created']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

$fun->DataCharts('clicks','pub');

$fun->DataCharts('views','pub');

//TOTAL
$data = $query->addquery('select','tbl_codes','count(code_id) as zcount','i',$user->user_id,'user_id=?');

$smarty->assign('zcount',number_format($data->zcount));

//EARN==TODAY
$data = $query->addquery('select','tbl_stat','sum(publisher_earn) as zearnMonth','is',"$user->user_id,$current_day",'pub_id=?,date=?');
 
$smarty->assign('zearnMonth',number_format($data->zearnMonth, 5, '.', ''));

//CLICKS==TODAY
$data = $query->addquery('select','tbl_stat','sum(clicks) as zclicksMonth','is',"$user->user_id,$current_day",'pub_id=?,date=?');

$smarty->assign('zclicksMonth',number_format($data->zclicksMonth));

//EARN==TODAY
$data = $query->addquery('select','tbl_stat','sum(publisher_earn) as earnToday','is',"$user->user_id,$current_day",'pub_id=?,date=?');

$smarty->assign('earnToday',number_format($data->earnToday, 5, '.', ''));

//VIEWS==TODAY
$data = $query->addquery('select','tbl_stat','sum(views) as viewsToday','is',"$user->user_id,$current_day",'pub_id=?,date=?');

$smarty->assign('viewsToday',number_format($data->viewsToday));

//CLICKS==TODAY
$data = $query->addquery('select','tbl_stat','sum(clicks) as clicksToday','is',"$user->user_id,$current_day",'pub_id=?,date=?');

$smarty->assign('clicksToday',number_format($data->clicksToday));

//TOTAL
$data =$query->addquery('select','tbl_withdrawal','count(withdrawal_id) as wcount','i',"$user->user_id",'user_id=?');

$smarty->assign('wcount',number_format($data->wcount));

//AMOUNT
$data =$query->addquery('select','tbl_withdrawal','sum(amount) as withdrawAmount','ii',"$user->user_id,3",'user_id=?,status=?');

$smarty->assign('withdrawAmount',number_format($data->withdrawAmount, 5, '.', ''));

//APPROVED
$data=$query->addquery('select','tbl_link','count(link_id) as apprWebcount','ii',"$user->user_id,1",'user_id=?,status=?');

$smarty->assign('apprWebcount',number_format($data->apprWebcount));

//PENDING
$data=$query->addquery('select','tbl_link','count(link_id) as waitWebcount','ii',"$user->user_id,2",'user_id=?,status=?');

$smarty->assign('waitWebcount',number_format($data->waitWebcount));

//REJECTED
$data=$query->addquery('select','tbl_link','count(link_id) as rejWebcount','ii',"$user->user_id,4",'user_id=?,status=?');

$smarty->assign('rejWebcount',number_format($data->rejWebcount));

//BANNED
$data=$query->addquery('select','tbl_link','count(link_id) as banWebcount','ii',"$user->user_id,3",'user_id=?,status=?');

$smarty->assign('banWebcount',number_format($data->banWebcount));

show('Publisher/Layout/dashboard');

?>