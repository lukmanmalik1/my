<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('withdraw_account',$user->withdrawal_account);

$smarty->assign('withdrawal_method',$user->withdrawal_method);

$smarty->assign('publisher_earnings',$user->publisher_earnings);

if(!empty($user->withdrawal_method)){

$data = $query->addquery('select','withdraw_methods','*','s',$user->withdrawal_method,'methods=?');

$smarty->assign('miniWith',$data->withdraw_min);

$smarty->assign('withdraw_type',$data->type);

$smarty->assign('fee',number_format($data->fee, 5, '.', ''));

$Realwith = number_format($user->publisher_earnings - $data->fee, 5, '.', '');

}
else{

$smarty->assign('miniWith',$option[4][0]);

}

if( isset($_POST['withdraw']) ){

if($sr->post() == 'true'){

//true
if($user->publisher_earnings < $data->withdraw_min && !empty($user->withdrawal_method)){
    
session_acv('errorwithdraw','withdraw_small');

Redirect(['controller' => 'member', 'action' => 'withdraw']);

}elseif(empty($user->withdrawal_method)){

Redirect(['controller' => 'member', 'action' => 'profile']);

}

if($user->publisher_earnings >= $data->withdraw_min && !empty($data->withdraw_min)){

$query->addquery('insert','tbl_withdrawal','user_id,amount,fee,withdrawal_account,withdrawal_method,status,created','issssis',[$user->user_id,$Realwith,$data->fee,$user->withdrawal_account,$user->withdrawal_method,'2',$dateForm]);

$query->addquery('update','tbl_user','publisher_earnings=publisher_earnings-?','si',[$user->publisher_earnings,$user->user_id],'user_id=?');

session_acv('success','manual_succ');

Redirect(['controller' => 'member', 'action' => 'withdraw']);

}

}elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);

}elseif($sr->post() == 'empty'){

session_acv('errorwithdraw','required');

Redirect(['controller' => 'member', 'action' => 'profile']);

}
  }

else{

alerts('errorwithdraw','withdraw_small');

alerts('success','manual_succ');

alerts('errorwithdraw','required');

}


show('Publisher/Withdraw/index');
?>