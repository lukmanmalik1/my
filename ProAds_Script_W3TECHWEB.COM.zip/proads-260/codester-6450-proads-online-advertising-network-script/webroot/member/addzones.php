<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('found_site',number_format($query->num_rows('tbl_link','link_id','i',$user->user_id,'user_id=?')));

$data = $query->addquery('fetch','tbl_link','url,status','i',$user->user_id,'user_id=?');

while($res=$data->fetch_assoc()){
    
$ar=array('url'=>$res['url'],'urlencode'=>base64_encode($res['url']),'status'=>$res['status']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

if(isset($_POST['addcode'] ) ){

$code_name = check_request('code_name');

$code_type = check_request('code_type');

$code_size = check_request('code_size');

$url_decode = check_request('url','base64_decode');

$code_display = check_request('display');

$json = json_encode(explode(' ','clean'.check_request('nsfw').check_request('gamble') . check_request('shady'). check_request('risky')));

if($sr->post() == 'true'){

$data = $query->addquery('select','tbl_link','status','s',$url_decode,'url=?');

if($data->status != '1'){

session_acv('errorzone','inactive');

Redirect(['controller' => 'member', 'action' => 'addzones']);

}else{

$codeUrl = str_replace($hs->site_protocol(),$code_display,$HOST);

if($code_type == 'direct' ){

$data = $query->addquery('select','tbl_codes','*','sis',$code_name.','.$user->user_id.','.$url_decode,'code_name=?,user_id=?,url=?');

if($code_name == $data->code_name){

session_acv('errorzone','same_name');

Redirect(['controller' => 'member', 'action' => 'addzones']);


}else{

$unique_id = $query->addquery('insert','tbl_codes','user_id,code_name,url,code_type,code_size,filter,status,created','isssssss',[$user->user_id,$code_name,$url_decode,$code_type,$code_size,$json,'1',$dateForm]);


$data = $query->addquery('select','tbl_link','link_id','s',$url_decode,'url=?');

$enc_siteid	= base64_encode($data->link_id);

$hash = base64_encode($unique_id);

$bin_token = $unique_id.bin2hex(openssl_random_pseudo_bytes(16));

$encode_token = base64_encode($bin_token);

//24h
setcookie('id', $encode_token, time()+60*60*24, 'ads.php', $_SERVER['HTTP_HOST']);

$code1 = $codeUrl.'codes/zone_d?rcd='.$hash;

$code = base64_encode($code1);

$query->addquery('update','tbl_codes','code=?,site_id=?,token=?','sisii',[$code,$data->link_id,$bin_token,$user->user_id,$unique_id],'user_id=?,code_id=?');

Redirect(['controller' => 'member', 'action' => 'ads']);

}

}elseif($code_type == 'popup' ){

if(startsWith($HOST,'http:')):

$codeUrl = str_replace('http:','',$HOST);

elseif(startsWith($HOST,'https:')):

$codeUrl = str_replace('https:','',$HOST);

endif;

$data = $query->addquery('select','tbl_codes','*','sis',"$code_name,$user->user_id,$url_decode",'code_name=?,user_id=?,url=?');

if($code_name == $data->code_name){

session_acv('errorzone','same_name');

Redirect(['controller' => 'member', 'action' => 'addzones']);

}else{

$unique_id = $query->addquery('insert','tbl_codes','user_id,code_name,url,code_type,code_size,filter,status,created','isssssss',[$user->user_id,$code_name,$url_decode,$code_type,$code_size,$json,'1',$dateForm]);

$data = $query->addquery('select','tbl_link','link_id','s',$url_decode,'url=?');

$enc_siteid	= base64_encode($data->link_id);

$hash = base64_encode($unique_id);

$bin_token = $unique_id.bin2hex(openssl_random_pseudo_bytes(16));

$encode_token = base64_encode($bin_token);

/*24h */
setcookie('id', $encode_token, time()+60*60*24, 'ads.php', $_SERVER['HTTP_HOST']);

$code1= '<script type="text/javascript" src="'.$codeUrl.'codes/zone?rcd='.$hash.'"></script>';

$code = base64_encode($code1);

$query->addquery('update','tbl_codes','code=?,site_id=?,token=?','sisii',[$code,$data->link_id,$bin_token,$user->user_id,$unique_id],'user_id=?,code_id=?');

Redirect(['controller' => 'member', 'action' => 'ads']);

}

}
    
    
elseif($code_type == 'image' || $code_type == 'text' ){

    if($code_size=='728x90'){
        $style='style="width:728px; height:90px;';
    }
    if($code_size=='468x60'){
        $style='style="width:468; height:60px;';
    }
    if($code_size=='336x280'){
        $style='style="width:336px; height:280px;';
    }
    if($code_size=='300x250'){
        $style='style="width:300px; height:250px;';
    }
    if($code_size=='300x600'){
        $style='style="width:300px; height:600px;';
    }
    if($code_size=='120x600'){
        $style='style="width:120px; height:600px;';
    }
    if($code_size=='200x200'){
        $style='style="width:200px; height:200px;';
    }
    if($code_size=='125x125'){
        $style='style="width:125px; height:125px;';
    }

if(startsWith($HOST,'http:')):

$codeUrl = str_replace('http:','',$HOST);

elseif(startsWith($HOST,'https:')):

$codeUrl = str_replace('https:','',$HOST);

endif;


$data = $query->addquery('select','tbl_codes','*','sis',$code_name.','.$user->user_id.','.$url_decode,'code_name=?,user_id=?,url=?');

if($code_name == $data->code_name){

session_acv('errorzone','same_name');

Redirect(['controller' => 'member', 'action' => 'addzones']);

}else{

$unique_id = $query->addquery('insert','tbl_codes','user_id,code_name,url,code_type,code_size,filter,status,created','isssssss',[$user->user_id,$code_name,$url_decode,$code_type,$code_size,$json,'1',$dateForm]);

$data = $query->addquery('select','tbl_link','link_id','s',$url_decode,'url=?');

$enc_siteid	= base64_encode($data->link_id);

$hash = base64_encode($unique_id);

$bin_token = $unique_id.bin2hex(openssl_random_pseudo_bytes(16));

$encode_token = base64_encode($bin_token);

/*24h */
setcookie('id', $encode_token, time()+60*60*24, 'ads.php', $_SERVER['HTTP_HOST']);

  $code1 = '<iframe src="'.$codeUrl.'codes/banner?rcd='.$hash.'" scrolling="no" '. $style.' border:0px; padding:0;overflow:hidden" allowtransparency="true"></iframe>';

  $code= base64_encode($code1);

$query->addquery('update','tbl_codes','code=?,site_id=?,token=?','sisii',[$code,$data->link_id,$bin_token,$user->user_id,$unique_id],'user_id=?,code_id=?');

Redirect(['controller' => 'member', 'action' => 'ads']);

  }
   }

else{

session_acv('errorzone','invalid_type');

Redirect(['controller' => 'member', 'action' => 'addzones']);

}

 }
}

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('errorzone','required');

Redirect(['controller' => 'member', 'action' => 'addzones']);

  }
}
else{

alerts('errorzone','error_msg');

alerts('errorzone','same_name');

alerts('errorzone','required');

alerts('errorzone','inactive');

alerts('errorzone','invalid_type');

}

show('Publisher/Zones/add');
?>