<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$data = $query->limit('tbl_cat','*','id','desc',$result['start'].','.$result['perpage'],'i','1','status=?');

while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'name'=>$res['name']);

array_push($with,$ar);

}

$smarty->assign('with',$with);

if( isset($_POST['addsite'] ) ){

$request = check_request('url');

$request = check_request('site_type');

$posted_url = check_request('url');

$site_type = check_request('site_type');

if($sr->post() == 'true'){

if(strpos($posted_url,'www.') !== false) {

session_acv('errorsite','match_www');

Redirect(['controller' => 'member', 'action' => 'addsite']);

}elseif(strpos($posted_url,'http://') !== false) {

session_acv('errorsite','match_http');

Redirect(['controller' => 'member', 'action' => 'addsite']);

}elseif(strpos($posted_url,'https://') !== false) {

session_acv('errorsite','match_https');

Redirect(['controller' => 'member', 'action' => 'addsite']);

}elseif(strpos($posted_url,'www.') === false && strpos($posted_url,'http://') === false && strpos($posted_url,'https://') === false) {

//true
$exist_url = $query->addquery('select','tbl_link','url','s',$posted_url,'url=?');

$bannerd_url = $query->addquery('select','tbl_banned','bann_site','s',$posted_url,'bann_site=?');

if($posted_url == !empty($bannerd_url->bann_sit)){

$_SESSION['errorsite']['error_banned']=true;

Redirect(['controller' => 'member', 'action' => 'addsite']);

}
elseif($posted_url == !empty($exist_url->url)){

$_SESSION['errorsite']['error_exist']=true;

Redirect(['controller' => 'member', 'action' => 'addsite']);

}
else{

switch(Catclosed):

case true :

$query->addquery('insert','tbl_link','user_id,url,site_type,status,created','issis',[$user->user_id,$posted_url,$site_type,$option[34][0],$dateForm]);

break;

case false :

$query->addquery('insert','tbl_link','user_id,url,status,created','isis',[$user->user_id,$posted_url,$option[34][0],$dateForm]);

break;

endswitch;

session_acv('success','succ_site');

Redirect(['controller' => 'member', 'action' => 'sites']);
  }
}
}
elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('errorsite','required');

Redirect(['controller' => 'member', 'action' => 'addsite']);

}else{
    
session_acv('errorsite','required');

Redirect(['controller' => 'member', 'action' => 'addsite']);

}

}else{

alerts('errorsite','match_www');

alerts('errorsite','match_http');

alerts('errorsite','match_https');

alerts('errorsite','error_banned');

alerts('errorsite','error_exist');

alerts('errorsite','required');

}

show('Publisher/Websites/add');

?>