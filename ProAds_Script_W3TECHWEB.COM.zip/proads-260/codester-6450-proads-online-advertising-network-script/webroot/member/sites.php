<?php
  
require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('found_code',number_format($query->num_rows('tbl_codes','code_id','i',$user->user_id,'user_id=?')));

$smarty->assign('found_site',number_format($query->num_rows('tbl_link','link_id','i',$user->user_id,'user_id=?')));

$data=$query->limit('tbl_link','*','link_id','desc',$result['start'].','.$result['perpage'],'i',$user->user_id,'user_id=?');

while($res=$data->fetch_assoc()){
    
$ar=array('link_id'=>$res['link_id'],'url'=>$res['url'],'site_type'=>$res['site_type'],'status'=>$res['status']);

array_push($with,$ar);

}

$smarty->assign('with',$with);

if( isset($_POST['post'] ) ){

Redirect(['controller' => 'member', 'action' => 'addsite']);

}

if( isset($_POST['delete'] ) ){

$request = check_request('l_id',false,'int');

if ($request):

$data = $query->addquery('select','tbl_link','url','ii',"$user->user_id,$request",'user_id=?,link_id=?');

$query->addquery('delete','tbl_link',false,'i',$request,'link_id=?');

$query->addquery('delete','tbl_codes',false,'s',$data->url,'url=?');

$_SESSION['success']['delete']=true;

Redirect(['controller' => 'member', 'action' => 'sites']);

endif;


}else{

alerts('success','succ_site');

alerts('success','delete');

}

if( isset($_POST['addcodes'] ) ){

Redirect(['controller' => 'member', 'action' => 'addzones']);

}

paging($result['screen']+1,ceil($query->num_rows('tbl_link','*','i',$user->user_id,'user_id=?')/$result['perpage'])+1,'sites?p=');

show('Publisher/Websites/index');

?>