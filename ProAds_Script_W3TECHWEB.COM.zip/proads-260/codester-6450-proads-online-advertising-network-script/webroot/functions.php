<?php

//=============================================================================>
//- ALL FUNCTIONS START FROM HERE
//=============================================================================>

 require_once "loader.php";

 //current dir
 
 function Getdir(){
 
 $UrlREQUEST = $_SERVER['REQUEST_URI'];

 $Parts = explode('/',$UrlREQUEST);

 $Dir = $_SERVER['SERVER_NAME'];
 
 for ($i = 0; $i < count($Parts) - 1; $i++) {

  $Dir .= $Parts[$i] . "/";
 }

  return $Dir;
 }
 
 //assign
 
 $smart->sign_user_fun();
 
 $smart->sign_deposits();

 $smart->sign_withdrawals();

 //validate members

 secure_role($user->role,$_SERVER['HTTP_HOST'],Getdir());

 //expired
 
 if(empty($uid) || $uid == '0'){
    
 $_SESSION['success']['expired']=true;

 Redirect(['controller' => 'auth', 'action' => 'login']);

 }

 //not logged
 
 if( !isset($_SESSION['user']['logged'])) {

 Redirect(['controller' => 'auth', 'action' => 'login']);

 }

 //pages
 
 function pages($perpage = 15,$screen = 0){

 if (!isset($_GET['p']) || $_GET['p']==0 )
 $screen;
 else
 $screen=$_GET['p']-1;
 $start = $screen * $perpage;
 return array('perpage' => $perpage, 'screen' => $screen , 'start' => $start);
 }

 function paging($page,$last_page,$part,$custom=false){

 global $smarty;

 $paging = false;

 if($page != 1){
 $paging.='<li><a href="'.$part.($page - 1).'">&lsaquo;</a></li>';
 }

 if($page > 4){
 $paging.='<li><a href="'.$part.($page-$page+1).'">&laquo;</a></li>';
 }

 for($i=4;$i>0;$i--)
 if($page-$i>0){
 $paging.='<li><a href="'.$part.($page-$i).'">'.($page-$i).'</a></li>';
 }

 if ($page == 0){
 $paging.='<li><a>&rsaquo;</a></li>';
 }

 elseif($page == $last_page){
 $paging.='<li><a>&lsaquo;</a></li>';
 }
 else{
 $paging.='<li><a>'.$page.'</a></li>';
 }

 for($i=1 ; $i<5 ; $i++)
 if($last_page-($page+$i)>0){
 $paging.='<li><a href="'.$part.($page+$i).'">'.($page+$i).'</a></li>';
 }
 if ($page < $last_page - 5){
 $paging.='<li><a href="'.$part.($last_page - 1).'">&raquo;</a></li>';
 }

 if ($page != $last_page-1){
 $paging.='<li><a href="'.$part.($page + 1).'">&rsaquo;</a></li>';
 }
 if($paging && !$custom){
     
     $smarty->assign('paging',$paging);

  }
  
 if($paging && $custom){
     
     return $paging;
     
  }
  
 }

 //count camp
 
 function sign_campagins(){

 global $query,$user,$smarty;

  //active
  
  $data=$query->addquery('select','tbl_banner','count(id) as activebann','ii',"$user->user_id,1",'user_id=?,status=?');
  
  define('ACTIVEBANN',number_format($data->activebann));

  $data = $query->addquery('select','tbl_popup','count(id) as activepop','ii',"$user->user_id,1",'user_id=?,status=?');
  
  define('ACTIVEPOP',number_format($data->activepop));

  $data = $query->addquery('select','tbl_direct','count(id) as activedir','ii',"$user->user_id,1",'user_id=?,status=?');
  define('ACTIVEDIR',number_format($data->activedir));

  $activeCampaigns = ACTIVEBANN + ACTIVEPOP + ACTIVEDIR ;

  //inactive
  
  $data=$query->addquery('select','tbl_banner','count(id) as inactivebann','ii',"$user->user_id,2",'user_id=?,status=?');
  define('INACTIVEBANN',number_format($data->inactivebann));

  $data=$query->addquery('select','tbl_popup','count(id) as inactivepop','ii',"$user->user_id,2",'user_id=?,status=?');
  define('INACTIVEPOP',number_format($data->inactivepop));

  $data=$query->addquery('select','tbl_direct','count(id) as inactivedir','ii',"$user->user_id,2",'user_id=?,status=?');
  define('INACTIVEDIR',number_format($data->inactivedir));

  $inactiveCampaigns = INACTIVEBANN + INACTIVEPOP + INACTIVEDIR ;

  //completed
  
  $data=$query->addquery('select','tbl_banner','count(id) as completebann','ii',"$user->user_id,3",'user_id=?,status=?');
  define('COMPLETEBANN',number_format($data->completebann));

  $data=$query->addquery('select','tbl_popup','count(id) as completepop','ii',"$user->user_id,3",'user_id=?,status=?');
  define('COMPLETEPOP',number_format($data->completepop));

  $data=$query->addquery('select','tbl_direct','count(id) as completedir','ii',"$user->user_id,3",'user_id=?,status=?');
  define('COMPLETEDIR',number_format($data->completedir));

  $completeCampaigns = COMPLETEBANN + COMPLETEPOP + COMPLETEDIR ;

  //rejected
  
  $data=$query->addquery('select','tbl_banner','count(id) as rejectbann','ii',"$user->user_id,5",'user_id=?,status=?');
  define('REJECTBANN',number_format($data->rejectbann));

  $data=$query->addquery('select','tbl_popup','count(id) as rejectbpop','ii',"$user->user_id,5",'user_id=?,status=?');
  define('REJECTPOP',number_format($data->rejectbpop));

  $data=$query->addquery('select','tbl_direct','count(id) as rejectbdir','ii',"$user->user_id,5",'user_id=?,status=?');
  define('REJECTDIR',number_format($data->rejectbdir));
  
  $rejectCampaigns = REJECTBANN + REJECTPOP + REJECTDIR;

  //waiting
  
  $data=$query->addquery('select','tbl_banner','count(id) as waitbann','ii',"$user->user_id,4",'user_id=?,status=?');
  define('WAITBANN',number_format($data->waitbann));

  $data=$query->addquery('select','tbl_popup','count(id) as waitpop','ii',"$user->user_id,4",'user_id=?,status=?');
  define('WAITPOP',number_format($data->waitpop));

  $data=$query->addquery('select','tbl_direct','count(id) as waitdir','ii',"$user->user_id,4",'user_id=?,status=?');
  define('WAITDIR',number_format($data->waitdir));

  $waitCampaigns = WAITBANN + WAITPOP + WAITDIR ;
  
  $smarty->assign('activeCamp',number_format($activeCampaigns));

  $smarty->assign('inactiveCamp',number_format($inactiveCampaigns));

  $smarty->assign('completeCamp',number_format($completeCampaigns));

  $smarty->assign('rejectCamp',number_format($rejectCampaigns));

  $smarty->assign('waitCamp',number_format($waitCampaigns));
  
 }

 //ALEXA RANKING CHECKER
 class Get_Alexa_Ranking{

 public function get_rank($domain){
     
 $url = "https://data.alexa.com/data?cli=10&dat=snbamz&url=".$domain;
 $ch = curl_init();  
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
 curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,2); 
 curl_setopt($ch, CURLOPT_URL, $url);  
 $data = curl_exec($ch);  
 curl_close($ch);  
 $xml = new SimpleXMLElement($data);  
 $popularity = $xml->xpath("//POPULARITY");
 $rank = (string)$popularity[0]['TEXT']; 
   
   return $rank;
  }
 }

 //note
 
 if ($option['42']['0'] == '1'){

 $smarty->assign('time',$RESdate);

 $smarty->assign('ip',$RESip);

 }

 alerts('success','noteIp');

 $with=array();

 $result = pages();
 
 $fhb = new FaucetHub($option['73']['0'], 'BTC');

 $smarty->assign('protocol',$hs->site_protocol());

//================================= END FUNCTIONS ============================//
?>