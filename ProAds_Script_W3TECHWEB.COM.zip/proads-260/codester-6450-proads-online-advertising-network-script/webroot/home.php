<?php

 require_once ('loader.php');

 if(isset($_GET['r']) &&  $_GET['r'] > 0):

 $data = $query->addquery('select','tbl_user','login_ip,register_ip','i',$_GET['r'],'user_id=?');

 if ($ip_visit != $data->login_ip && $ip_visit != $data->register_ip):
    
 setcookie('r', trim($_GET['r']), time() + 60 * 60 * 24 * 30);

 Redirect(['controller' => 'auth', 'action' => 'signup']);

 endif;

 endif;

 show('Home/home');

?>