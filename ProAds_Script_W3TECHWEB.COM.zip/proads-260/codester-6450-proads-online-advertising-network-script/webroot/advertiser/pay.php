<?php
//============================= START PAYMENTS ===============================//

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('mess_success',false);

$smarty->assign('small',false);

//COOKIES==PAY
if($_COOKIE['pay']){

$inv_id = $_COOKIE['pay'];

$decode_inv = base64_decode($inv_id);

$data = $query->addquery('select','tbl_invoice','id,token,amount,type','i',$decode_inv,'id=?');

$smarty->assign('invoice_am',$data->amount);

if( isset($_POST['pay'] ) ){

$payment_method = check_request('pay_method');

$smarty->assign('payment_method',$payment_method);

if($sr->post() == 'true'){


 if($data->amount < $option[2][0]):

 session_acv('errorpay','small');

 Redirect(['controller' => 'advertiser', 'action' => 'pay']);

 else:

 $method = $query->addquery('select','deposite_methods','account','s',$payment_method,'methods=?');

 switch($payment_method){

 case 'BankTransfer':

 $smarty->assign('mess_success',true);

 $_SESSION['banktransfer']['amount'] = $data->amount;

 $_SESSION['banktransfer']['inv_number'] = $data->id;

 header('refresh:2;url= deposits/banktrans');
 
 break;
 
 case 'Bitcoin':

 $smarty->assign('mess_success',true);

 $pm->coinpayments($data->token,$data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;
 
 case 'PayPal':

 $smarty->assign('mess_success',true);

 $pm->paypal($data->token,$data->type,$data->id,number_format($data->amount, 2, '.', ''),$method->account);

 break;
 
 case 'Payza':

 $smarty->assign('mess_success',true);

 $pm->payza($data->type,$data->id,number_format($data->amount, 2, '.', ''),$method->account);

 break;

 case 'Discover':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;
 
 case 'AmericanExpress':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;
 
 case 'DinersClub':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;

 
 case 'Visa':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;

 case 'MasterCard':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;

 }

 endif;

}

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('warning','required');

Redirect(['controller' => 'advertiser', 'action' => 'pay']);

}

}else{

alerts('errorpay','small');

}

}else{

Redirect(['controller' => 'advertiser', 'action' => 'invoices']);

}

show('Advertiser/Payments/pay');

//============================== END PAYMENTS ================================//
?>