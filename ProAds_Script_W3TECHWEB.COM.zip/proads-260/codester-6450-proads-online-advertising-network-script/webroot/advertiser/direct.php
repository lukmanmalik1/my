<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

if($option[64][0] != '1'){

exit("NOT ALLOWED");

}else{

$data = $query->limit('tbl_cat','*','id','desc',$result['start'].','.$result['perpage'],'i','1','status=?');

while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'name'=>$res['name']);

array_push($with,$ar);

}

$smarty->assign('with',$with);

if(isset($_POST['direct'] ) ){

$direct_name = check_request('name');

$direct_website = check_request('direct_website');
	
$direct_clicks= check_request('clicks');
	
$direct_device = check_request('direct_device');

$cat = check_request('cat');

 switch($_POST['direct_country']):
    
 case NULL: $direct_country = '["ALL"]';
 
 break;
 default: $direct_country = json_encode($_POST['direct_country']);
 
 break;
 endswitch;


if($sr->post() == 'true'){

//CALUCATE
$result = number_format(($option[49][0] * $direct_clicks) / 1000, 5, '.', '');

//PERCENT
$price_calucate = number_format(($option[40][0] / 100) * $result, 5, '.', '');

//REAL
$price = number_format($result - $price_calucate, 5, '.', '') ;

if($direct_clicks < $option[52][0]){

session_acv('warning','invalidclick');

Redirect(['controller' => 'advertiser', 'action' => 'direct']);

}else{

if($user->advertiser_balance >= $result){

$query->addquery('insert','tbl_direct','user_id,direct_url,name,price,direct_price,direct_clicks,direct_country,direct_device,category,filter,status,created','isssssssssis',[$user->user_id,$direct_website,$direct_name,$result,$price,$direct_clicks,$direct_country,$direct_device,$cat,'clean','1',$dateForm]);

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance-?','si',[$result,$user->user_id],'user_id=?');

$query->addquery('insert','tbl_stat','admin_earn,date','ss',[$price_calucate,$current_month]);

session_acv('success','campaign_succ');

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);
  	
}else{

//ERROR
session_acv('warning','not_enoghtdir');

Redirect(['controller' => 'advertiser', 'action' => 'direct']);

	}
 }



}elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);


}elseif($sr->post() == 'empty'){

session_acv('warning','requiredir');

Redirect(['controller' => 'advertiser', 'action' => 'direct']);

 }
  
}else{

alerts('warning','msg_dir');

alerts('warning','not_enoghtdir');

alerts('warning','invalidclick');

alerts('warning','requiredir');

}
}


show('Advertiser/Purchase/direct')
?>