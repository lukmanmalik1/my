<?php

 require_once (dirname(dirname(__FILE__)).'/functions.php');

 $bannerRole = $_COOKIE['banner_role'];

 $smarty->assign('bannerRole',$bannerRole);

$data = $query->limit('tbl_cat','*','id','desc',$result['start'].','.$result['perpage'],'i','1','status=?');

while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'name'=>$res['name']);

array_push($with,$ar);

}

$smarty->assign('with',$with);

 if($_COOKIE['banner_role'] && $option[30][0] == '1'){

 if( isset($_POST['banner'] ) ){

 $banner_title = check_request('banner_title');
	
 $banner_dsc =   check_request('banner_dsc');
	
 $banner_type =  check_request('banner_type');
	
 $banner_size =  check_request('banner_size');
	
 $banner_site =  check_request('banner_website');
	
 $bann_clicks  =  check_request('clicks');

 $banner_device = check_request('banner_device');

 $cat = check_request('cat');

 switch(isset($_POST['banner_country'])):
    
 case NULL: $banner_country = '["ALL"]';
 
 break;
 default: $banner_country = json_encode($_POST['banner_country']);
 
 break;
 endswitch;

//var_export($banner_country);

//exit();

if($sr->post() == 'true'){

//true 
if($_COOKIE['banner_role'] == 'CPC'){

//CALUCATE
$result = number_format(($option[41][0] * $bann_clicks) / 1000, 5, '.', '');

//PERCENT
$price_calucate = number_format(($option[40][0] / 100) * $result, 5, '.', '');

//REAL
$price = number_format($result - $price_calucate, 5, '.', '') ;

if($bann_clicks < $option[37][0]){

session_acv('warning','invalidclick');

Redirect(['controller' => 'advertiser', 'action' => 'banner']);

}else{

//ENOUGHT
if($user->advertiser_balance >= $result){

//UPLOAD
$up->photo(

 [

 'photo' => $_FILES["photo"],
 
 'error' => $_FILES["photo"]["error"],
 
 'path' => 'advertiser/uploads/',
 
 'controller' => 'advertiser', 
 
 'action' => 'banner'
 
  ]);

$banner = $up->img();

$query->addquery('insert','tbl_banner','user_id,banner_image,banner_url,banner_title,banner_dscr,price,banner_price,banner_clicks,banner_country,banner_device,banner_size,banner_type,type_spend,category,filter,status,created','issssssssssssssis',[$user->user_id,$banner,$banner_site,$banner_title,$banner_dsc,$result,$price,$bann_clicks,$banner_country,$banner_device,$banner_size,$banner_type,'clicks',$cat,'clean','1',$dateForm]);

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance-?','si',[$result,$user->user_id],'user_id=?');

$query->addquery('insert','tbl_stat','admin_earn,date','ss',[$price_calucate,$current_month]);

session_acv('success','campaign_succ');

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{
    
//ERROR
session_acv('warning','not_enoghtbann');

Redirect(['controller' => 'advertiser', 'action' => 'banner']);
   }
 }

}elseif($_COOKIE['banner_role'] == 'CPM'){

//CALUCATE
$result = number_format(($option[35][0] * $bann_clicks) / 1000, 5, '.', '');

//PERCENT
$price_calucate = number_format(($option[40][0] / 100) * $result, 5, '.', '');

//REAL
$price = number_format($result - $price_calucate, 5, '.', '') ;

if($bann_clicks < $option[36][0]){

session_acv('warning','invalidclick');

Redirect(['controller' => 'advertiser', 'action' => 'banner']);

//ENOUGHT
}elseif($user->advertiser_balance >= $result){

//UPLOAD
$up->photo(
    
  [
  
  'photo' => $_FILES["photo"],
  
  'error' => $_FILES["photo"]["error"],
  
  'path' => 'advertiser/uploads/',
  
  'controller' => 'advertiser',
  
  'action' => 'banner'
  
  ]);

$banner = $up->img();

$query->addquery('insert','tbl_banner','user_id,banner_image,banner_url,banner_title,banner_dscr,price,banner_price,banner_views,banner_country,banner_device,banner_size,banner_type,type_spend,category,filter,status,created','issssssssssssssis',[$user->user_id,$banner,$banner_site,$banner_title,$banner_dsc,$result,$price,$bann_clicks,$banner_country,$banner_device,$banner_size,$banner_type,'views',$cat,'clean','1',$dateForm]);

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance-?','si',[$result,$user->user_id],'user_id=?');

$query->addquery('insert','tbl_stat','admin_earn,date','ss',[$price_calucate,$current_month]);

session_acv('success','campaign_succ');

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

//ERROR
session_acv('warning','not_enoghtbann');

Redirect(['controller' => 'advertiser', 'action' => 'banner']);

	}
  
 }
 

}elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);

}elseif($sr->post() == 'empty'){

session_acv('warning','requiredbann');

Redirect(['controller' => 'advertiser', 'action' => 'banner']);

}

}else{

alerts('warning','upe_bann');

alerts('warning','format_bann');

alerts('warning','size_bann');

alerts('warning','up_bann');

alerts('warning','cpm_bann');

alerts('warning','cpc_bann');

alerts('warning','not_enoghtbann');
   
alerts('warning','requiredbann');

alerts('warning','invalidclick');

}
}

else{

header("location: buy-banner");

}

show('Advertiser/Purchase/banner');

?>