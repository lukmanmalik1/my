<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$data=$query->limit('tbl_banner','*','id','desc',$result['start'].','.$result['perpage'],'i',$user->user_id,'user_id=?');

while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'banner_url'=>$res['banner_url'],'views'=>$res['views'],'clicks'=>$res['clicks'],'spend'=>$res['spend'],'type_spend'=>$res['type_spend'],'status'=>$res['status'],'banner_size'=>$res['banner_size'],'banner_clicks'=>$res['banner_clicks'],'banner_views'=>$res['banner_views']);

array_push($with,$ar);

}

$smarty->assign('with',$with);
	
if(isset($_POST['deactivate_banner'] ) ){

$query->addquery('update','tbl_banner','status=?','ii',['2',$_POST['b_id']],'id=?');

$_SESSION['success']['pause_banner']=true;

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

alerts('success','pause_banner');

alerts('delete_camp','deleted');

}

if( isset($_POST['activate_banner'] ) ){

$query->addquery('update','tbl_banner','status=?','ii',['1',$_POST['b_id']],'id=?');

$_SESSION['success']['activate_banner']=true;

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

alerts('success','activate_banner');

alerts('success','campaign_succ');

}

$BannerP = paging($result['screen']+1,ceil($query->num_rows('tbl_banner','*','i',$user->user_id,'user_id=?')/$result['perpage'])+1,'campaigns?p=',true);

$smarty->assign('BannerP',$BannerP);

$smarty->assign('n_banner',$query->num_rows('tbl_banner','*','i',$user->user_id,'user_id=?'));


/*------------------ Popups -----------------------*/

$with_popup=array();

$data=$query->limit('tbl_popup','*','id','desc',$result['start'].','.$result['perpage'],'i',$user->user_id,'user_id=?');

while($res=$data->fetch_assoc()){
    
$ar_popup=array('popup_id'=>$res['id'],'popup_user'=>$res['user_id'],'popup_url'=>$res['popup_url'],'popup_views'=>$res['views'],'popup_clicks'=>$res['clicks'],'popup_spend'=>$res['spend'],'popup_price'=>$res['price'],'pop_price'=>$res['popup_price'],'pop_views'=>$res['popup_views'],'pop_clicks'=>$res['popup_clicks'],'popup_country'=>$res['popup_country'],'popup_device'=>$res['popup_device'],'type_spend'=>$res['type_spend'],'popup_status'=>$res['status'],'popup_created'=>$res['created']);

array_push($with_popup,$ar_popup);
	}

$smarty->assign('with_popup',$with_popup);

//pause

if( isset($_POST['deactivate_popup'] ) ){

$query->addquery('update','tbl_popup','status=?','ii',['2',$_POST['p_id']],'id=?');

$_SESSION['success']['pause_popup']=true;

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

alerts('success','pause_popup');

}

if( isset($_POST['activate_popup'] ) ){

$query->addquery('update','tbl_popup','status=?','ii',['1',$_POST['p_id']],'id=?');

$_SESSION['success']['activate_popup']=true;

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

alerts('success','activate_popup');

}


if( isset($_POST['delete_popup'] ) ){

$query->addquery('delete','tbl_popup',false,'i',$_POST['p_id'],'id=?');

$_SESSION['success']['delete_popup']=true;

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

alerts('success','delete_popup');

}


$PopP = paging($result['screen']+1,ceil($query->num_rows('tbl_popup','*','i',$user->user_id,'user_id=?')/$result['perpage'])+1,'campaigns?p=',true);

$smarty->assign('PopP',$PopP);

$smarty->assign('n_pop',$query->num_rows('tbl_popup','*','i',$user->user_id,'user_id=?'));

/*------------------ Directs links -----------------------*/

$with_direct=array();

$data=$query->limit('tbl_direct','*','id','desc',$result['start'].','.$result['perpage'],'i',$user->user_id,'user_id=?');

while($res=$data->fetch_assoc()){
    
$ar_direct=array('direct_id'=>$res['id'],'direct_user'=>$res['user_id'],'direct_url'=>$res['direct_url'],'direct_clicks'=>$res['clicks'],'direct_spend'=>$res['spend'],'direct_price'=>$res['price'],'dir_price'=>$res['direct_price'],'dir_clicks'=>$res['direct_clicks'],'direct_country'=>implode(', ',json_decode($res['direct_country'])),'direct_device'=>$res['direct_device'],'direct_status'=>$res['status'],'direct_created'=>$res['created']);

array_push($with_direct,$ar_direct);
	}

$smarty->assign('with_direct',$with_direct);

if( isset($_POST['deactivate_direct'] ) ){

$query->addquery('update','tbl_direct','status=?','ii',['2',$_POST['d_id']],'id=?');

$_SESSION['success']['deactivate_direct']=true;

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

alerts('success','deactivate_direct');


if( isset( $_SESSION['success']['deactivate_direct'])) {

$smarty->assign('deactivate_direct',true);

unset( $_SESSION['success'] ) ;
}
}


if( isset($_POST['activate_direct'] ) ){

$query->addquery('update','tbl_direct','status=?','ii',['1',$_POST['d_id']],'id=?');

$_SESSION['success']['activate_direct']=true;

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

alerts('success','activate_direct');

}

$DirectP = paging($result['screen']+1,ceil($query->num_rows('tbl_direct','*','i',$user->user_id,'user_id=?')/$result['perpage'])+1,'campaigns?p=',true);

$smarty->assign('DirectP',$DirectP);

$smarty->assign('n_direct',$query->num_rows('tbl_direct','*','i',$user->user_id,'user_id=?'));

show('Advertiser/Campaigns/index');
?>