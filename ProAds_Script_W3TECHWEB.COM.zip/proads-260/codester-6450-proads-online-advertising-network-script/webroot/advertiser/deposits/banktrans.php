<?php

require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

$smarty->assign('banktransfer_am',$_SESSION['banktransfer']['amount']);

$smarty->assign('banktransfer_nu',$_SESSION['banktransfer']['inv_number']);

show('Advertiser/Payments/bank_transfer');

?>