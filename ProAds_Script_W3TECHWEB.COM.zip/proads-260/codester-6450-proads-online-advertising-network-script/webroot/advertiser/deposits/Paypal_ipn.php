<?php
//============================== PAYPAL IPN ==================================//
//= WHEN THIS FILES RECIEVE A ($_GET) INFORMATIONS ABOUT PAYMENT W'LL CONFIRM //
//= WITHER THIS IS A TRUE PAYMENTS OR FALSE AND (UPDATE/INSERT) DB WITH INFO =//
//============================== PAYPAL IPN ==================================//

require_once (dirname(dirname(dirname(__FILE__))).'/loader.php');

if(!isset($_GET['item_number'])){

exit('NOT ALLOWED');

}else{

$invoice = $query->addquery('select','tbl_invoice','*','i',$_GET['item_number'],'id=?');

if(isset($_GET['item_number']) && $invoice->token == $_GET['cm']){

$invoice_number =     $_GET['item_number']; 

$item_name      =     $_GET['item_name']; 

$txn_id         =     $_GET['tx']; 

$payment_gross  =     $_GET['amt']; 

$currency_code  =     $_GET['cc']; 

$payment_status =     $_GET['st']; 

$custom         =     $_GET['cm'];

//transactions

$transaction = $query->addquery('select','payments','*','s',$txn_id,'txn_id=?');
	

//validate

if(!empty($txn_id) && $user->user_id == $invoice->user_id && $payment_gross == $invoice->amount && $payment_status == 'Completed' && $custom == $invoice->token && $transaction->txn_id != $txn_id && $invoice->type == $item_name){

//success

$query->addquery('insert','payments','user_id,item_number,txn_id,payment_gross,currency_code,payment_status,type,created','isssssss',[$invoice->user_id,$invoice_number,$txn_id,$payment_gross,$currency_code,$payment_status,'PayPal',$dateForm]);

$query->addquery('update','tbl_invoice','status=?','ii',['1',$invoice_number],'id=?');

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance+?','si',[$payment_gross,$invoice->user_id],'user_id=?');

header('location:'.$HOST.'advertiser/deposits/Status/success');

    }
else{

//error

$query->addquery('insert','payments','user_id,item_number,txn_id,payment_gross,currency_code,payment_status,type,created','isssssss',[$invoice->user_id,$invoice_number,$txn_id,$payment_gross,$currency_code,'Failed','PayPal',$dateForm]);

header('location:'.$HOST.'advertiser/deposits/Status/cancel');
}
}
}

?> 