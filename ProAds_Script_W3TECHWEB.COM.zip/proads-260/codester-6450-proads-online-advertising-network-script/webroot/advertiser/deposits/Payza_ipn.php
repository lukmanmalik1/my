<?php
//============================== PAYZA IPN ===================================//
//= WHEN THIS FILES RECIEVE A ($_GET) INFORMATIONS ABOUT PAYMENT W'LL CONFIRM //
//= WITHER THIS IS A TRUE PAYMENTS OR FALSE AND (UPDATE/INSERT) DB WITH INFO =//
//============================== PAYZA IPN ===================================//

//REQUIRED
require_once (dirname(dirname(dirname(__FILE__))).'/loader.php');

 define("IPN_V2_HANDLER", "https://secure.payza.com/ipn2.ashx");
 define("TOKEN_IDENTIFIER", "token="); 
 $token = urlencode($_POST['token']); 
 //preappend the identifier string "token=" 
 $token = TOKEN_IDENTIFIER.$token; 


 /** * * Sends the URL encoded TOKEN string to the Payza's IPN handler * using cURL and retrieves the response. * * variable $response holds the response string from the Payza's IPN V2. */

//$response = '';

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, IPN_V2_HANDLER);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $token);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);

curl_close($ch);

if(!empty($response) && !empty(urldecode($_GET['ap_itemcode']))){
    
if(strlen($response) > 0)
  {
if(urldecode($response)=='INVALID TOKEN'){

//error

$query->addquery('insert','payments','item_number,currency_code,payment_gross,type,payment_status,created','issssssss',[urldecode($_GET['ap_itemcode']),urldecode($_GET['ap_currency']),urldecode($_GET['ap_amount']),'Payza',$response,$dateForm]);

$result = 'Failed';
}
  }else
        {
  // the response is decoded, now you can process it in your system
$res = urldecode($response);

$ap_itemcode =  urldecode($_GET['ap_itemcode']); 

$ap_merchant =  urldecode($_GET['ap_merchant']); 

$ap_purchasetype = urldecode($_GET['ap_purchasetype']);

$ap_amount =  urldecode($_GET['ap_amount']); 

$ap_itemname =  urldecode($_GET['ap_itemname']);

$ap_currency =  urldecode($_GET['ap_currency']); 

$ap_ipnversion =  urldecode($_GET['ap_ipnversion']); 

$ap_testmode =  urldecode($_GET['ap_testmode']);

$ap_batchnumber =  urldecode($_GET['ap_batchnumber']);

$invoice = $query->addquery('select','tbl_invoice','user_id','i',$ap_itemcode,'id=?');

//success

$query->addquery('insert','payments','item_number,currency_code,payment_gross,type,payment_status,created','isssss',[$ap_itemcode,$ap_currency,$ap_amount,'Payza','success',$dateForm]);

$query->addquery('update','tbl_invoice','status=?','ii',['1',$ap_itemcode],'id=?');

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance+?','si',[$ap_amount,$invoice->user_id],'user_id=?');

$result = 'Success';
        }
        
echo $result.' - Res :'. $response;

}else{

exit('NOT ALLOWED');

}