<?php
//payment failed

setcookie("ad_pay", 1, time()+60*14,'/');
header('location: /advertiser/dashboard');

?>