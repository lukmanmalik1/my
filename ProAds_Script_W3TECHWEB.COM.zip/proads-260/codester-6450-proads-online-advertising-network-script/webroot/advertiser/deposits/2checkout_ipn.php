<?php
//============================ 2CHECKOUT IPN =================================//
//= WHEN THIS FILES RECIEVE A ($_GET) INFORMATIONS ABOUT PAYMENT W'LL CONFIRM //
//= WITHER THIS IS A TRUE PAYMENTS OR FALSE AND (UPDATE/INSERT) DB WITH INFO =//
//============================ 2CHECKOUT IPN =================================//

require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

if(!isset($_REQUEST['order_number']) || empty($_REQUEST['order_number'])){

exit('NOT ALLOWED');

}else{

//GET DATA

$li_0_product_id = $_GET['li_0_product_id'];

$li_0_name       = $_GET['li_0_name'];

$ship_zip        = $_GET['ship_zip'];

$ship_state      = $_GET['ship_state'];

$email_ipn       = $_GET['email'];

$li_0_price      = $_GET['li_0_price'];

$total_ipn       = $_GET['total'];

$ship_name       = $_GET['ship_name'];

$li_0_quantity   = $_GET['li_0_quantity'];

$ship_country    = $_GET['ship_country'];

$last_name_ipn   = $_GET['last_name'];

$street_address  = $_GET['li_0_price'];

//SECRECT_WORD
$hashSecretWord = $option[58][0];

//ACCOUNT
$hashSid = $option[57][0];

$invoice = $query->addquery('select','tbl_invoice','*','i',$li_0_product_id,'id=?');

//number

$hashOrder = $_REQUEST['order_number'];

//transaction 

$transaction = $query->addquery('select','payments','txn_id','i',$hashOrder,'txn_id=?');

//confirm

$StringToHash = strtoupper(md5($hashSecretWord . $hashSid . $hashOrder . $invoice->amount));

if($StringToHash == $_REQUEST['key'] && $transaction->txn_id != $hashOrder && $li_0_quantity == '1' && $total_ipn == $invoice->amount){

$query->addquery('insert','payments','user_id,item_number,txn_id,payment_gross,payment_status,type,created','iisssss',[$invoice->user_id,$li_0_product_id,$hashOrder,$invoice->amount,'Completed','2checkout',$dateForm]);

$query->addquery('update','tbl_invoice','status=?','ii',['1',$li_0_product_id],'id=?');

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance+?','si',[$invoice->amount,$invoice->user_id],'user_id=?');

setcookie("ad_pay", 1, time()+60*14,'/');

header('location:'.$HOST.'advertiser/deposits/Status/success');

} 
else {

//failed

$query->addquery('insert','payments','user_id,item_number,txn_id,payment_gross,payment_status,type,created','iisssss',[$invoice->user_id,$li_0_product_id,$hashOrder,$invoice->amount,'Failed','2checkout',$dateForm]);

header('location: /advertiser/deposits/Status/cancel');}
}

?>