<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

if($option[30][0] != '1'){

exit('NOT ALLOWED');

}else{
    
$smarty->assign('CPC',false);

$smarty->assign('CPM',false);

if( isset($_POST['go'] ) ){ 

if( $_POST['role'] == 'CPC'){

$smarty->assign('CPC',true);

//15m
setcookie('banner_role', $_POST['role'], time()+60*15, 'banner.php', $_SERVER['HTTP_HOST']);
}

elseif( $_POST['role'] == 'CPM'){

$smarty->assign('CPM',true);
// 15m
setcookie('banner_role', $_POST['role'], time()+60*15, 'banner.php', $_SERVER['HTTP_HOST']);
}

if($system->getSetting()['camp_role_refresh'] == 'active'):

header( "refresh:2;url=banner" );

else:

redirect(['controller' => 'advertiser', 'action' => 'banner']);

endif;

}
}

show('Advertiser/Purchase/buy-banner');

?>