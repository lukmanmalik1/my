<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$PopRole = $_COOKIE['role'];

$smarty->assign('PopRole',$PopRole);

$data = $query->limit('tbl_cat','*','id','desc',$result['start'].','.$result['perpage'],'i','1','status=?');

while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'name'=>$res['name']);

array_push($with,$ar);

}

$smarty->assign('with',$with);


if(isset($_COOKIE['role']) && $option[31][0] == '1'){

if( isset($_POST['popup'] ) ){
 
$pop_name = check_request('name');
	
$pop_website = check_request('pop_website');
	
$pop_click = check_request('clicks');

$pop_device = check_request('pop_device');

$cat = check_request('cat');

 switch(isset($_POST['pop_country'])):
    
 case NULL: $pop_country = '["ALL"]';
 
 break;
 default: $pop_country = json_encode($_POST['pop_country']);
 
 break;
 endswitch;


if($sr->post() == 'true'){

//true
if($_COOKIE['role'] == 'CPM'){

//CALUCATE
$result = number_format(($option[47][0] * $pop_click) / 1000, 5, '.', '');

//PERCENT
$price_calucate = number_format(($option[40][0] / 100) * $result, 5, '.', '');

//REAL
$price = number_format($result - $price_calucate, 5, '.', '') ;


if($pop_click < $option[50][0]){

session_acv('warning','invalidckick');

Redirect(['controller' => 'advertiser', 'action' => 'pop']);

}else{

if($user->advertiser_balance >= $result){

$query->addquery('insert','tbl_popup','user_id,popup_url,name,price,popup_price,popup_views,popup_country,popup_device,type_spend,category,filter,status,created','issssssssssis',[$user->user_id,$pop_website,$pop_name,$result,$price,$pop_click,$pop_country,$pop_device,'views',$cat,'clean','1',$dateForm]);

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance-?','si',[$result,$user->user_id],'user_id=?');

$query->addquery('insert','tbl_stat','admin_earn,date','ss',[$price_calucate,$current_month]);

session_acv('success','campaign_succ');

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

//ERROR
session_acv('warning','not_enoghtpop');

Redirect(['controller' => 'advertiser', 'action' => 'pop']);

 }
}

}elseif($_COOKIE['role'] == 'CPC'){

//CALUCATE
$result = number_format(($option[48][0] * $pop_click) / 1000, 5, '.', '');

//PERCENT
$price_calucate = number_format(($option[40][0] / 100) * $result, 5, '.', '');

//REAL
$price = number_format($result - $price_calucate, 5, '.', '') ;

if($pop_click < $option[50][0]){

session_acv('warning','invalidclick');

Redirect(['controller' => 'advertiser', 'action' => 'pop']);

}else{
    
if($user->advertiser_balance >= $result){

$query->addquery('insert','tbl_popup','user_id,popup_url,name,price,popup_price,popup_clicks,popup_country,popup_device,type_spend,category,filter,status,created','issssssssssis',[$user->user_id,$pop_website,$pop_name,$result,$price,$pop_click,$pop_country,$pop_device,'clicks',$cat,'clean','1',$dateForm]);

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance-?','si',[$result,$user->user_id],'user_id=?');

$query->addquery('insert','tbl_stat','admin_earn,date','ss',[$price_calucate,$current_month]);

session_acv('success','campaign_succ');

Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

}else{

//ERROR
session_acv('warning','not_enoghtpop');

Redirect(['controller' => 'advertiser', 'action' => 'pop']);

	}
  }
 }

}elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);


}elseif($sr->post() == 'empty'){

session_acv('warning','requiredpop');

Redirect(['controller' => 'advertiser', 'action' => 'pop']);

}

}
else{

alerts('warning','cpm_popup');

alerts('warning','cpc_popup');

alerts('warning','not_enoghtpop');
   
alerts('warning','requiredpop');

alerts('warning','invalidclick');

}

}else{

Redirect(['controller' => 'advertiser', 'action' => 'buy-popup']);

}

show('Advertiser/Purchase/pop');

?>