<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

if($option[31][0] != '1'){

exit('NOT ALLOWED');

}else{
    
$smarty->assign('CPC',false);

$smarty->assign('CPM',false);


if( isset($_POST['go'] ) ){

if($_POST['role'] == 'CPC'){
    
// 15m
setcookie('role', $_POST['role'], time()+60*15, 'pop.php', $_SERVER['HTTP_HOST']);
    
$smarty->assign('CPC',true);
}

else if($_POST['role'] == 'CPM'){
    
// 15m
setcookie('role', $_POST['role'], time()+60*15, 'pop.php', $_SERVER['HTTP_HOST']);
  
$smarty->assign('CPM',true);

}

if($system->getSetting()['camp_role_refresh'] == 'active'):

header( "refresh:2;url=pop" );

else:

redirect(['controller' => 'advertiser', 'action' => 'pop']);

endif;

}
}

show('Advertiser/Purchase/buy-popup')
?>