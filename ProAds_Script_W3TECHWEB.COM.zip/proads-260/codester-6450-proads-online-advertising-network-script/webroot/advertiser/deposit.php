<?php
//============================= START DEPOSIT ===============================//

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('mess_success',false);

$smarty->assign('small',false);

alerts('err_small','am_small');

alerts('err_parm','need_settings');

alerts('err_token','wrong_token');


if( isset($_POST['deposit'] ) ){

$payment_method = check_request('paymentWay');

$smarty->assign('payment_method',$payment_method);

$payment_amount = check_request('amount');

$invoiceTokendata = bin2hex(openssl_random_pseudo_bytes(16));

if($sr->post() == 'true'){

 if($payment_amount < $option[2][0]):

 session_acv('errorm','small');

 Redirect(['controller' => 'advertiser', 'action' => 'deposit']);

 else:

 $id = $query->addquery('insert','tbl_invoice','user_id,amount,method,type,token,status,created','issssis',[$user->user_id,$payment_amount,$payment_method,'Deposit Money',$invoiceTokendata,'2',$dateForm]);

 $data = $query->addquery('select','tbl_invoice','id,token,amount,type','i',$id,'id=?');

 $method = $query->addquery('select','deposite_methods','account','s',$payment_method,'methods=?');

 switch($payment_method){

 case 'BankTransfer':

 $smarty->assign('mess_success',true);

 $_SESSION['banktransfer']['amount'] = $data->amount;

 $_SESSION['banktransfer']['inv_number'] = $data->id;

 header('refresh:2;url= deposits/banktrans');
 
 break;
 
 case 'Bitcoin':

 $smarty->assign('mess_success',true);

 $pm->coinpayments($data->token,$data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;
 
 case 'PayPal':

 $smarty->assign('mess_success',true);

 $pm->paypal($data->token,$data->type,$data->id,number_format($data->amount, 2, '.', ''),$method->account);

 break;
 
 case 'Payza':

 $smarty->assign('mess_success',true);

 $pm->payza($data->type,$data->id,number_format($data->amount, 2, '.', ''),$method->account);

 break;

 case 'Discover':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;
 
 case 'AmericanExpress':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;
 
 case 'DinersClub':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;

 
 case 'Visa':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;

 case 'MasterCard':

 $smarty->assign('mess_success',true);

 $pm->_2checkout($data->type,$data->id,number_format($data->amount, 2, '.', ''));

 break;

 }

 endif;

}elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);

}

elseif($sr->post() == 'empty'){

session_acv('errorm','required');

Redirect(['controller' => 'advertiser', 'action' => 'deposit']);

 }

}else{

alerts('errorm','small');

}

show('Advertiser/Payments/index');

//================================ END DEPOSIT ===============================//
?>