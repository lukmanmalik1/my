<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');


show('Advertiser/Reports/tracking');

?>