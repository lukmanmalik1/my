<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-10-01 10:23:10
         compiled from "/home/lodmpcom/public_html/webroot/template/Main/Advertiser/Reports/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12189361895bb1f58e1cebe1-94947022%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a485d75a60a9870b1a675b847553533f7751a19e' => 
    array (
      0 => '/home/lodmpcom/public_html/webroot/template/Main/Advertiser/Reports/index.tpl',
      1 => 1537011676,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12189361895bb1f58e1cebe1-94947022',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'name' => 0,
    'err_null' => 0,
    'csrfToken' => 0,
    'with_banner' => 0,
    'foo' => 0,
    'campaign_id' => 0,
    'campaign' => 0,
    'with_popup' => 0,
    'with_direct' => 0,
    'dashboard_color' => 0,
    'with_stateAll' => 0,
    'sumbole' => 0,
    'with_stateCountry' => 0,
    'with_stateReferer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bb1f58e260a65_56300216',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bb1f58e260a65_56300216')) {function content_5bb1f58e260a65_56300216($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("../Layout/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <title>Reports - <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</title>

    <div class="layout-content">
        <div class="layout-content-body">
            <div class="title-bar">

                <h1 class="title-bar-title">
<span class="d-ib"><div class="fa fa-line-chart "></div> Reports</span>
                </h1><hr>
     <center>
 <?php if ($_smarty_tpl->tpl_vars['err_null']->value) {?>
    <div class='alert alert-warning'>Error: Please select all options.</div>
 <?php }?>

            <br></center>
<br>
<style>
.pagebreak { page-break-before: always; }
</style>

            </div>
<div class="box box-primary">
    <div class="box-body">
       
        <form method="GET" >
            
        <input type='hidden' name='id' value="<?php echo $_smarty_tpl->tpl_vars['csrfToken']->value;?>
"/>

        <div class="form-group select ">
            <select name="campaign_id" class="form-control">
                
           
        <option selected="selected">Select Campaign</option>
            
          <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with_banner']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
        <option value="<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
|1" <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
<?php $_tmp1=ob_get_clean();?><?php if ($_smarty_tpl->tpl_vars['campaign_id']->value==$_tmp1&&$_smarty_tpl->tpl_vars['campaign']->value==1) {?> selected="selected"<?php }?>>#<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
 - <?php echo $_smarty_tpl->tpl_vars['foo']->value['banner_title'];?>
 (Banner)</option><?php } ?>
           <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with_popup']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
        <option value="<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
|2" <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
<?php $_tmp2=ob_get_clean();?><?php if ($_smarty_tpl->tpl_vars['campaign_id']->value==$_tmp2&&$_smarty_tpl->tpl_vars['campaign']->value==2) {?> selected="selected"<?php }?>>#<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
 - <?php echo $_smarty_tpl->tpl_vars['foo']->value['name'];?>
 (Popup)</option><?php } ?>
        
           <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with_direct']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
        <option value="<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
|3" <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
<?php $_tmp3=ob_get_clean();?><?php if ($_smarty_tpl->tpl_vars['campaign_id']->value==$_tmp3&&$_smarty_tpl->tpl_vars['campaign']->value==3) {?> selected="selected"<?php }?>>#<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
 - <?php echo $_smarty_tpl->tpl_vars['foo']->value['name'];?>
 (Direct)</option><?php } ?>
        
        </select></div>
        
<button name="fill" class="btn btn-default btn-sm" type="submit" value='ok'>Filter</button>
        </form>
    </div>
</div>
   <div class="box-header with-border" style="width: 1012px;height: 300px;border-style: solid;border-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;">
        <h3 class="box-title" style="background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;color: #ffffff;margin-top: 0px;height: 50px;font-family: Helvetica;font-size: 20px;"><div class="fa fa-bar-chart"></div> Campaign Details</h3>
          <p><div class="table-responsive">
                                <table class="table table-middle">
                                    <thead>
                                    <tr>
                                        <th><div class="fa fa-sort"></div>  Type</th>
                                        <th><div class="fa fa-bar-chart"></div> Views</th>
                                        <th><div class="fa fa-bullseye"></div> Clicks</th>
                                        <th><div class="fa fa-dollar"></div> Spendings</th>

                                    </tr>
                                    </thead>
      <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with_stateAll']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
                                    <tbody class="page-break">
      <?php if ($_smarty_tpl->tpl_vars['foo']->value['type_cam']==1) {?>
                                    <td>Spend</td>
      <?php } elseif ($_smarty_tpl->tpl_vars['foo']->value['type_cam']==2) {?>
                                    <td>IP Changed</td>
      <?php } elseif ($_smarty_tpl->tpl_vars['foo']->value['type_cam']==4) {?>
                                    <td>Fraud</td>
      <?php }?>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['views'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['clicks'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['publisher_earn'];
echo $_smarty_tpl->tpl_vars['sumbole']->value;?>
</td>
                                    </tbody>
         <?php } ?>
         <?php if (!$_smarty_tpl->tpl_vars['foo']->value['id']) {?>
          <td>No available data.</td>
          <?php }?>
                                </table>
                            </div>

              
              
              </p>
    </div><br>

        
            
              <div class="page-break" style="overflow: auto;border-style: solid;width: 500px;height: 300px;border-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;border-top-width: 4px;border-left-width: 4px;border-right-width: 4px;border-bottom-width: 4px;display:inline-block;margin-right:10px;">
        <h3 class="box-title" style="background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;color: #ffffff;margin-top: 0px;height: 50px;font-family: Helvetica;font-size: 20px;"><div class="fa fa-globe"></div>  Countries</h3>
          <p>
              <div class="table-responsive">
                                <table class="table table-middle">
                                    <thead>
                                    <tr>
                                        <th> Country</th>
                                        <th> Views</th>
                                        <th> Clicks</th>
                                        <th>Spendings</th>
                                        
                                    </tr>
                                    </thead>
      <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with_stateCountry']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
                                    <tbody >
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['country'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['views'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['clicks'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['publisher_earn'];
echo $_smarty_tpl->tpl_vars['sumbole']->value;?>
</td>
                                    </tbody>
      <?php } ?>
         <?php if (!$_smarty_tpl->tpl_vars['foo']->value['id']) {?>
          <td>No available data.</td>
          <?php }?>

         
                                </table>
                            </div></p>
    </div> 


              <div class="page-break" style="overflow: auto;border-style: solid;width: 500px;height: 300px;border-color:<?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;border-top-width: 4px;border-left-width: 4px;border-right-width: 4px;border-bottom-width: 4px;display:inline-block;">
        <h3 class="box-title" style="overflow: auto;background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;color: #ffffff;margin-top: 0px;height: 50px;font-family: Helvetica;font-size: 20px;"><div class="fa fa-share"></div>  Referers</h3>
         <p><div class="table-responsive">
                                <table class="table table-middle">
                                    <thead>
                                    <tr>
                                        <th> Referer</th>
                                        <th> Views</th>
                                        <th> Clicks</th>
                                        <th> Spendings</th>

                                    </tr>
                                    </thead>
      <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with_stateReferer']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
                                    <tbody>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['referer_domain'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['views'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['clicks'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['publisher_earn'];
echo $_smarty_tpl->tpl_vars['sumbole']->value;?>
</td>

                                    </tbody>
      <?php } ?>

         <?php if (!$_smarty_tpl->tpl_vars['foo']->value['id']) {?>
          <td>No available data.</td>
          <?php }?>

                                </table>
                            </div></p>
            </div>





              </div>
        </div>

<?php echo $_smarty_tpl->getSubTemplate ("../Layout/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
