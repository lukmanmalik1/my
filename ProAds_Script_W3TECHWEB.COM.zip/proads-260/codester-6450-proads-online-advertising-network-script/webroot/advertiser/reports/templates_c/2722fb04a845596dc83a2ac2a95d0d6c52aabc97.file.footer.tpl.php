<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-10-01 10:23:10
         compiled from "/home/lodmpcom/public_html/webroot/template/Main/Advertiser/Layout/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16034955915bb1f58e2a59e3-31892270%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2722fb04a845596dc83a2ac2a95d0d6c52aabc97' => 
    array (
      0 => '/home/lodmpcom/public_html/webroot/template/Main/Advertiser/Layout/footer.tpl',
      1 => 1537011676,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16034955915bb1f58e2a59e3-31892270',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'date' => 0,
    'site_url' => 0,
    'name' => 0,
    'HOST' => 0,
    'THEME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bb1f58e2af1f9_02290010',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bb1f58e2af1f9_02290010')) {function content_5bb1f58e2af1f9_02290010($_smarty_tpl) {?><div class="layout-footer">
    <div class="layout-footer-body">
        <small class="version"><?php echo $_smarty_tpl->tpl_vars['date']->value;?>
 &copy; <a href="<?php echo $_smarty_tpl->tpl_vars['site_url']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</a></small>
    </div>
</div>



</div>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/vendor.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/elephant.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/private/application.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/ads.js/" type="text/javascript"><?php echo '</script'; ?>
>

        
<?php echo '<script'; ?>
>
    function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

<?php echo '</script'; ?>
>
</body>
</html><?php }} ?>
