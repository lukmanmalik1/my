<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-10-01 10:23:10
         compiled from "/home/lodmpcom/public_html/webroot/template/Main/Advertiser/Layout/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11190335685bb1f58e265e15-50104828%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e827dcd4e6ccb7d87f29dd1e19b396df01ebb2c8' => 
    array (
      0 => '/home/lodmpcom/public_html/webroot/template/Main/Advertiser/Layout/header.tpl',
      1 => 1537011676,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11190335685bb1f58e265e15-50104828',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'site_description' => 0,
    'site_url' => 0,
    'site_title' => 0,
    'name' => 0,
    'member_head' => 0,
    'dashboard_color' => 0,
    'Favicon_url' => 0,
    'HOST' => 0,
    'THEME' => 0,
    'Logo' => 0,
    'role' => 0,
    'username' => 0,
    'enable_send_info' => 0,
    'enable_banners' => 0,
    'enable_popups' => 0,
    'enable_direct' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bb1f58e2a2990_15442408',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bb1f58e2a2990_15442408')) {function content_5bb1f58e2a2990_15442408($_smarty_tpl) {?><html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description"
      content="<?php echo $_smarty_tpl->tpl_vars['site_description']->value;?>
">
<meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['site_url']->value;?>
">
<meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['site_title']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
">
<meta property="og:description"
      content="description search">
<meta name="twitter:title" content="<?php echo $_smarty_tpl->tpl_vars['site_description']->value;?>
">
<meta name="twitter:description"
      content="<?php echo $_smarty_tpl->tpl_vars['site_description']->value;?>
">
<?php echo $_smarty_tpl->tpl_vars['member_head']->value;?>

<style>
a:hover {
    color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
}

a:active {
    color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
}

 a {
    color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
; }
    
nav.navbar-collapse.collapse {
    background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
    border-color: #ffffff;
}
ul.nav.navbar-nav.navbar-right li a:hover {
    color: #ffffff;
    background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
}
ul.nav.navbar-nav.navbar-right li a:active {
    color:#ffffff;
    background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
}

div.navbar-header {
    background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
    color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
}
li.sidenav-heading {
    color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
}

::selection {
  background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;
  color: white;
}
</style>
<?php echo '<script'; ?>
 src="//code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js"><?php echo '</script'; ?>
>

<link rel="icon" href="<?php echo $_smarty_tpl->tpl_vars['Favicon_url']->value;?>
">

<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,400italic,500,700">

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/css/vendor.min.css">

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/css/elephant.min.css">

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<link href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/Main/Advertiser/Purchase/multi-select/css/multi-select.css" media="screen" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/css/private/application.min.css">

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/css/private/side.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
    
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"><?php echo '</script'; ?>
>

</head>

<body class="layout layout-header-fixed">

<div class="layout-header">
    <div class="navbar navbar-default">
        <div class="navbar-header" style="background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
; color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;">
            <a class="navbar-brand navbar-brand-center" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
home">
                <img class="navbar-brand-logo" src="<?php echo $_smarty_tpl->tpl_vars['Logo']->value;?>
">
            </a>
            <button class="navbar-toggler visible-xs-block collapsed" type="button" data-toggle="collapse"
                    data-target="#sidenav">
                <span class="sr-only">Toggle navigation</span>
                <span class="bars">
                    <span class="bar-line bar-line-1 out"></span>
                    <span class="bar-line bar-line-2 out"></span>
                    <span class="bar-line bar-line-3 out"></span>
                </span>
                <span class="bars bars-x">
                    <span class="bar-line bar-line-4"></span>
                    <span class="bar-line bar-line-5"></span>
                </span>
            </button>
            <button class="navbar-toggler visible-xs-block collapsed" type="button" data-toggle="collapse"
                    data-target="#navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="arrow-up"></span>
                <span class="ellipsis ellipsis-vertical"></span>
            </button>
        </div>
        <div class="navbar-toggleable">
            <nav id="navbar" class="navbar-collapse collapse" style="background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
; color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;">
                <form id="command" action="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
auth/logout" method="POST">

                    <ul class="nav navbar-nav navbar-right" style="background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
; color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;">
                        <li class="visible-xs-block">
                            <h4 class="navbar-text text-center">
                                <?php if ($_smarty_tpl->tpl_vars['role']->value=='admin') {?>
                                
                                Hello, Admin!
                                 
                                <?php } elseif ($_smarty_tpl->tpl_vars['role']->value=='advertiser') {?>
                                  
                                Hello, <?php echo $_smarty_tpl->tpl_vars['username']->value;?>
!
                                
                                <?php }?>
                                
                            
                                <input type="submit" class="btn btn-info" style="padding: 14px 18px;"
                                       value="Logout"/>
                            </h4>
                        </li>

                         
                        <style>
                            .icon-small {
                                height: 18px;
                                margin: 0;
                                padding: 0;
                            }
                        </style>

          
                        <li>
                            <a href="#" data-toggle="dropdown" style="background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
; color: #ffffff;">
                                <div class="fa fa-language"></div>
                                <span id="lanNavSel">Language</span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a id="navEN" href="#" class="language">
                                        <img id="imgNavEN" src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/images/en.gif" class="icon-small">
                                        <span id="lanNavEN">English</span>
                                    </a>
                                </li>
                                
                            </ul>
                        </li>

                        <li class="hidden-xs" style="background-color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
; color: <?php echo $_smarty_tpl->tpl_vars['dashboard_color']->value;?>
;">
                            <a href="dashboard">
                                <?php if ($_smarty_tpl->tpl_vars['role']->value=='admin') {?>
                                
                                Hello, Admin!
                                 
                                <?php } elseif ($_smarty_tpl->tpl_vars['role']->value=='advertiser') {?>
                                
                                Hello, <?php echo $_smarty_tpl->tpl_vars['username']->value;?>
!
                                
                                <?php }?>
                            </a>
                        </li>
<?php if ($_smarty_tpl->tpl_vars['role']->value=='admin') {?>
                        <li class="hidden-xs">
                            <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/dashboard" style="
    background-color: #000000;"><div class="fa fa-dashboard "></div>
                                 Administration Area
                            </a>
                        </li>
<?php }?>
                
                        <li class="hidden-xs">
                        
                             <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
auth/logout"><div class="fa fa-sign-out "></div> 
                                 Logout
                                 </a>
                        </li>
                    </ul>
                </form>
            </nav>
        </div>
    </div>
</div>
<div class="layout-main">

<div class="layout-sidebar">
    <div class="layout-sidebar-backdrop"></div>
    <div class="layout-sidebar-body">
        <nav id="sidenav" class="sidenav-collapse collapse">
            <ul class="sidenav">
                <li class="sidenav-heading">Statistics</li>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/dashboard">
                        <span class="sidenav-label"><div class="fa fa-dashboard"></div> Dashboard</span>
                    </a>
                </li>
                </li>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/reports/index">
                        <span class="sidenav-label"><div class="fa fa-line-chart"></div> Reports </span>
                    </a>
                </li>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/campaigns">
                        <span class="sidenav-label"><div class="fa fa-tag"></div> Campaigns </span>
                    </a>
                </li>
<?php if ($_smarty_tpl->tpl_vars['enable_send_info']->value=='1') {?>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/tracking">
                        <span class="sidenav-label"><div class="fa fa-area-chart"></div> Tracking </span>
                    </a>
                </li>
<?php }?>
                <li class="sidenav-heading">Purchase</li>
                <li class="sidenav-item">
                <li class="sidenav-item">
<?php if ($_smarty_tpl->tpl_vars['enable_banners']->value=='1') {?>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/buy-banner">
                        <span class="sidenav-label"><div class="fa fa-shopping-cart"></div> Create Banner</span>
                    </a>
                </li>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['enable_popups']->value==1) {?>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/buy-popup">
                        <span class="sidenav-label"><div class="fa fa-shopping-cart"></div> Create PopUp</span>
                    </a>
                </li>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['enable_direct']->value==1) {?>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/direct">
                        <span class="sidenav-label"><div class="fa fa-shopping-cart"></div> Create Direct <img src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/images/private/new.gif" /></span>
                    </a>
                </li>
<?php }?>

                <li class="sidenav-heading">Payments</li>
                <li class="sidenav-item">
                <li class="sidenav-item">
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/deposit">
                        <span class="sidenav-label"><div class="fa fa-money"></div> Deposit</span>
                    </a>
                </li>
                
               <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/invoices">
                        <span class="sidenav-label"><div class="fa fa-calendar-o"></div> Invoices </span>
                    </a>
                </li>
                
                <li class="sidenav-heading">Settings</li>
                <li class="sidenav-item">
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/profile">
                         
                        <span class="sidenav-label"><div class="fa fa-cog"></div> Profile</span>
                    </a>
                </li>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
advertiser/support">
                        <span class="sidenav-label"><div class="fa fa-envelope"></div> Support</span>
                    </a>
                </li>
                <li class="sidenav-item">
                    <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
#faq" target="_blank">
                        <span class="sidenav-label"><div class="fa fa-life-ring"></div> Help</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>
<?php }} ?>
