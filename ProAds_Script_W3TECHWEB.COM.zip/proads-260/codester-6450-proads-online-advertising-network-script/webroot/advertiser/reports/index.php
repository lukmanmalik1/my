<?php

require_once '../../functions.php';

if( isset($_GET['fill'])){

if($sr->get() == 'true'){

$arr = explode('|', $_GET['campaign_id']);

header('location: ?campaign_id='.$arr[0].'&campaign='.$arr[1]);

}elseif($sr->get() == 'false'){

redirect(['controller' => 'pages', 'action' => 'error']);
 
}
elseif($sr->get() == 'empty'){

session_acv('erroreports','err_null');

redirect(['controller' => 'advertiser/reports', 'action' => 'index']);
 }
}
else{

alerts('erroreports','err_null');

}





if(isset($_GET['campaign_id'])):

$smarty->assign('campaign_id',$CampaignState=$_GET['campaign_id']);

$smarty->assign('campaign',$CampaignType=$_GET['campaign']);

//============= type ======//

$with_stateAll=array();

$data = $query->normal("SELECT id,type_cam, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat where adv_id = '$user->user_id' and campaign_id ='$CampaignState' and ad_type ='$CampaignType' and country<>' ' and type_cam<>' ' group by type_cam ASC");


while($res=$data->fetch_assoc()){

$ar_stateAll=array('id'=>$res['id'],'type_cam'=>$res['type_cam'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));
array_push($with_stateAll,$ar_stateAll);
}
$smarty->assign('with_stateAll',$with_stateAll);

//============= country ======//
$with_stateCountry=array();

$data = $query->normal("SELECT id,country, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat where  adv_id = '$user->user_id' and campaign_id ='$CampaignState' and ad_type ='$CampaignType' and country<>' ' and type_cam<>' ' group by country ASC");

while($res=$data->fetch_assoc()){

$ar_stateCountry=array('id'=>$res['id'],'country'=>$res['country'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));
array_push($with_stateCountry,$ar_stateCountry);

}
$smarty->assign('with_stateCountry',$with_stateCountry);

//============= referer ======//
$with_stateReferer=array();

$data = $query->normal("SELECT id,referer_domain, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat where  adv_id = '$user->user_id' and campaign_id ='$CampaignState' and ad_type ='$CampaignType' and country<>' '  and type_cam<>' 'group by referer_domain ASC");

while($res=$data->fetch_assoc()){
    
$ar_stateReferer=array('id'=>$res['id'],'referer_domain'=>$res['referer_domain'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));
array_push($with_stateReferer,$ar_stateReferer);

}

$smarty->assign('with_stateReferer',$with_stateReferer);

endif;

//========= Banner =======//
$with_banner=array();

$data = $query->normal("select * from tbl_banner where status = '1' and user_id = '$uid' order by id ASC");

while($res=$data->fetch_assoc()){

$ar_banner=array('id'=>$res['id'],'banner_title'=>$res['banner_title']);

array_push($with_banner,$ar_banner);

}
$smarty->assign('with_banner',$with_banner);

//========= popup =======//

$with_popup=array();

$data = $query->normal("select * from tbl_popup where status = '1' and user_id = '$uid' order by id ASC");

while($res=$data->fetch_assoc()){
$ar_popup=array('id'=>$res['id'],'name'=>$res['name']);
array_push($with_popup,$ar_popup);
	}
$smarty->assign('with_popup',$with_popup);
	

//========= direct =======//

$with_direct=array();

$data = $query->normal("select * from tbl_direct where status = '1' and user_id= '$uid' order by id ASC");

while($res=$data->fetch_assoc()){
    
$ar_direct=array('id'=>$res['id'],'name'=>$res['name']);

array_push($with_direct,$ar_direct);

	}
$smarty->assign('with_direct',$with_direct);


if(!isset($_GET['campaign_id'])){

   
//============= type ======//
$with_stateAll=array();

$data = $query->normal("SELECT id,type_cam, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat where adv_id = '$user->user_id' and type_cam<>' ' group by type_cam ASC");
while($res=$data->fetch_assoc()){
    
$ar_stateAll=array('id'=>$res['id'],'type_cam'=>$res['type_cam'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));
array_push($with_stateAll,$ar_stateAll);

}
$smarty->assign('with_stateAll',$with_stateAll);

//============= country ======//
$with_stateCountry=array();

$data = $query->normal("SELECT id,country, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat where adv_id = '$user->user_id' and country<>' ' group by country ASC");

while($res=$data->fetch_assoc()){
    
$ar_stateCountry=array('id'=>$res['id'],'country'=>$res['country'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));
array_push($with_stateCountry,$ar_stateCountry);

}
$smarty->assign('with_stateCountry',$with_stateCountry);

//============= referer ======//

$with_stateReferer=array();

$data = $query->normal("SELECT id,referer_domain, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat where adv_id = '$user->user_id' and country<>' ' group by referer_domain ASC");

while($res=$data->fetch_assoc()){
    
$ar_stateReferer=array('id'=>$res['id'],'referer_domain'=>$res['referer_domain'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));
array_push($with_stateReferer,$ar_stateReferer);

}
$smarty->assign('with_stateReferer',$with_stateReferer);
}

show('Advertiser/Reports/index');

?>