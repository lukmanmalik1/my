<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('advertiser_balance',number_format($user->advertiser_balance, 5, '.', ''));

$smarty->assign('withdrawal_method',$user->withdrawal_method);

$smarty->assign('pay_success',false);

$smarty->assign('pay_error',false);

if(isset($_COOKIE['ad_pay'])){
    
if($_COOKIE['ad_pay'] == '2'){
$smarty->assign('pay_error',true);
}

elseif($_COOKIE['ad_pay'] == '1'){
$smarty->assign('pay_success',true);
}}

if (isset( $_COOKIE['ad_pay'])) {
    unset( $_COOKIE['ad_pay']);

setcookie('ad_pay', '1',time() - 3600, '/'); 
setcookie('ad_pay', '2',time() - 3600, '/'); 
}


$data = $query->limit('announcements','*','id','desc',$result['screen'].','.$result['perpage'],'i','1','published=?');

while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'title'=>$res['title'],'content'=>$res['content'],'created'=>$res['created']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

$fun->DataCharts('clicks','adv');

$fun->DataCharts('views','adv');

//SPEND
$data = $query->addquery('select','tbl_stat','sum(publisher_earn) as advspendToday','is',"$user->user_id,$current_day",'adv_id=?,date=?');

$smarty->assign('advspendToday',number_format($data->advspendToday, 5, '.', ''));


//VIEWS
$data = $query->addquery('select','tbl_stat','sum(views) as advviewsToday','is',"$user->user_id,$current_day",'adv_id=?,date=?');

$smarty->assign('advviewsToday',number_format($data->advviewsToday));

//CLICKS
$data = $query->addquery('select','tbl_stat','sum(clicks) as advclicksToday','is',"$user->user_id,$current_day",'adv_id=?,date=?');

$smarty->assign('advclicksToday',number_format($data->advclicksToday));

//count campaigns

sign_campagins();

//TOTAL==DEPOSITS
$data = $query->addquery('select','tbl_invoice','count(id) as depositcount','ii',"$user->user_id,'1'",'user_id=?,status=?');

$smarty->assign('depositcount',number_format($data->depositcount));

//AMOUNT==DEPOSITS
$data = $query->addquery('select','tbl_invoice','sum(amount) as amDeposit','ii',"$user->user_id,'1'",'user_id=?,status=?');

$smarty->assign('amDeposit',number_format($data->amDeposit), 5, '.', '');

show('Advertiser/Layout/dashboard');
?>