<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('invoice_num',number_format($query->num_rows('tbl_invoice','id','i',$user->user_id,'user_id=?')));

$data=$query->limit('tbl_invoice','*','id','desc',$result['start'].','.$result['perpage'],'i',$user->user_id,'user_id=?');

while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'user_id'=>$res['user_id'],'amount'=>$res['amount'],'method'=>$res['method'],'status'=>$res['status'],'type'=>$res['type'],'created'=>$res['created']);

array_push($with,$ar);

}

$smarty->assign('with',$with);

if( isset($_POST['pay'] ) ){
 
$encode_result = base64_encode($_POST['i_id']);

//1h
setcookie('pay', $encode_result, time()+60*60*1, 'pay.php', "$site_url");

Redirect(['controller' => 'advertiser', 'action' => 'pay']);
}

if( isset($_POST['new'] ) ){

Redirect(['controller' => 'advertiser', 'action' => 'deposit']);
}	

paging($result['screen']+1,ceil($query->num_rows('tbl_invoice','*','i',$user->user_id,'user_id=?')/$result['perpage'])+1,'invoices?p=');

show('Advertiser/Invoices/index');
?>