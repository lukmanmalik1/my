<?php

  require_once (dirname(dirname(__FILE__)).'/functions.php');

  $id = $_GET['id'];

  switch($_GET['type']){

  case 'banner':

  $data = $query->addquery('select','tbl_banner','*','ii',"$id,$user->user_id",'id=?,user_id=?');

  $smarty->assign('arr',implode(", ",json_decode($data->banner_country)));

  $smarty->assign('image',$data->banner_image);

  $smarty->assign('url',$data->banner_url);
	
  $smarty->assign('title',$data->banner_title);
	
  $smarty->assign('dscr',$data->banner_dscr);
	
  $smarty->assign('views',$data->banner_views);

  $smarty->assign('clicks',$data->banner_clicks);

  $smarty->assign('device',$data->banner_device);

  $smarty->assign('size',$data->banner_size);

  $smarty->assign('type_banner',$data->banner_type);

  $smarty->assign('type_spend',$data->type_spend);

  $smarty->assign('catname',$data->category);

  break;
  case 'popup':

  $data = $query->addquery('select','tbl_popup','*','ii',"$id,$user->user_id",'id=?,user_id=?');

  $smarty->assign('arr',implode(", ",json_decode($data->popup_country)));
  
  $smarty->assign('url',$data->popup_url);
	
  $smarty->assign('title',$data->name);

  $smarty->assign('views',$data->popup_views);

  $smarty->assign('clicks',$data->popup_clicks);

  $smarty->assign('device',$data->popup_device);

  $smarty->assign('type_spend',$data->type_spend);

  $smarty->assign('catname',$data->category);

  break;
  case 'direct':

  $data = $query->addquery('select','tbl_direct','*','ii',"$id,$user->user_id",'id=?,user_id=?');
  
  $smarty->assign('arr',implode(", ",json_decode($data->direct_country)));

  $smarty->assign('url',$data->direct_url);
	
  $smarty->assign('title',$data->name);

  $smarty->assign('clicks',$data->direct_clicks);

  $smarty->assign('device',$data->direct_device);

  $smarty->assign('catname',$data->category);

  break;
  
  }
 
 if(!$data || !$_GET['id'] || !$_GET['type']):

 Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

 endif;

 $data = $query->limit('tbl_cat','*','id','desc',$result['start'].','.$result['perpage'],'i','1','status=?');

 while($res=$data->fetch_assoc()){
    
 $ar=array('id'=>$res['id'],'name'=>$res['name']);

 array_push($with,$ar);

 }

 $smarty->assign('with',$with);

  //Assing default
  
  $smarty->assign('id',$_GET['id']);

  $smarty->assign('campaign',$_GET['type']);
  
  
  if( isset($_POST['change'] ) ){

  $title = check_request('title');

  $dscr = check_request('dscr');

  $url = check_request('url');

  $size = check_request('size');

  $device = check_request('device');

  $cat = check_request('cat');

  if($_POST['country'] == NULL):
  
  $country = json_encode([$_POST['selected_country']]);
  
  else:
      
  $country = json_encode($_POST['country']);

  endif;

  if ($_GET['type'] == 'banner'):
    
  $query->addquery('update','tbl_banner','banner_url=?,banner_title=?,banner_dscr=?,banner_device=?,banner_size=?,banner_country=?,category=?','sssssssi',[$url,$title,$dscr,$device,$size,$country,$cat,$_GET['id']],'id=?');

  elseif($_GET['type'] == 'popup'):
    
  $query->addquery('update','tbl_popup','popup_url=?,name=?,popup_country=?,popup_device=?,category=?','sssssi',[$url,$title,$country,$device,$cat,$_GET['id']],'id=?');

  elseif($_GET['type'] == 'direct'):
    
  $query->addquery('update','tbl_direct','direct_url=?,name=?,direct_device=?,direct_country=?,category=?','sssssi',[$url,$title,$device,$country,$cat,$_GET['id']],'id=?');
 
  endif;

  $_SESSION['success']['succ']=true;

  header('location: campaign?id='.$_GET['id'].'&type='.$_GET['type']);
  
  exit();
  
	}else{

  alerts('success','succ');

  }
	
  if( isset($_POST['delete'])){

  if ($_GET['type'] == 'banner'):
    
  $query->addquery('delete','tbl_banner',false,'i',$_GET['id'],'id=?');

  elseif($_GET['type'] == 'popup'):
    
  $query->addquery('delete','tbl_popup',false,'i',$_GET['id'],'id=?');

  elseif($_GET['type'] == 'direct'):
    
  $query->addquery('delete','tbl_direct',false,'i',$_GET['id'],'id=?');
  
  endif;

  $_SESSION['delete_camp']['deleted']=true;

  Redirect(['controller' => 'advertiser', 'action' => 'campaigns']);

  }

show('Advertiser/Campaigns/edit');

?>