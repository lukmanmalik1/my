<?php

require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

if( isset($_POST['setPay'] ) ){
	
$min_with = $_POST['min_with'];
$post_paypal = $_POST['post_paypal'];
$paypal_m = $_POST['paypal_m'];
$paypal_fees = $_POST['paypal_f'];
$post_bitcoin = $_POST['post_bitcoin'];
$bitcoin_m = $_POST['bitcoin_m'];
$bitcoin_fees = $_POST['bitcoin_f'];
$post_fhb = $_POST['post_fhb'];
$m_fhb = $_POST['m_fhb'];
$f_fhb = $_POST['f_fhb'];
$api_fhb = $_POST['api_fhb'];
$post_payza = $_POST['post_payza'];
$payza_m = $_POST['payza_m'];
$payza_fees = $_POST['payza_f'];
$post_bank = $_POST['post_bank'];
$bank_m = $_POST['bank_m'];
$bank_fees = $_POST['bank_f'];
	

$query->addquery('update','tbl_config','value=?','ss',[$min_with,'with_min'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$api_fhb,'fhb_api'],'header=?');

$query->addquery('update','withdraw_methods','status=?,fee=?,withdraw_min=?','isss',[$post_paypal,$paypal_fees,$paypal_m,'PayPal'],'methods=?');

$query->addquery('update','withdraw_methods','status=?,withdraw_min=?,fee=?','isss',[$post_bitcoin,$bitcoin_m,$bitcoin_fees,'Bitcoin'],'methods=?');

$query->addquery('update','withdraw_methods','status=?,withdraw_min=?,fee=?','isss',[$post_payza,$payza_m,$payza_fees,'Payza'],'methods=?');

$query->addquery('update','withdraw_methods','status=?,withdraw_min=?,fee=?','isss',[$post_fhb,$m_fhb,$f_fhb,'FaucetHub'],'methods=?');

$sqlclm = $query->num_rows('withdraw_methods','*','s','BankTransfer','methods=?');

if ($sqlclm > 0):

$query->addquery('update','withdraw_methods','status=?,withdraw_min=?,fee=?','isss',[$post_bank,$bank_m,$bank_fees,'BankTransfer'],'methods=?');

else:

$query->addquery('insert','withdraw_methods','methods,type,fee,withdraw_min,status','ssssi',['BankTransfer','manual',$bank_fees,$bank_m,$post_bank]);

endif;

$_SESSION['success']['succ']=true;

header("location: withdrawal");

 
}else{

alerts('success','succ');

}

show('Admin/Options/withdrawal');
?>