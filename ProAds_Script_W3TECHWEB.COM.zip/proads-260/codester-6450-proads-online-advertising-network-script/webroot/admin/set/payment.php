<?php

//================================== START PAYMENT ===========================//

require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

if( isset($_POST['setPay'] ) ){

//POST==PAYMENTS	
$currency_c = $_POST['currency_c'];

$sumbole_c = $_POST['sumbole_c'];

$minDeposit = $_POST['min_deposit'];

$post_paypal = $_POST['post_paypal'];

$btcaddr = $_POST['btcaddr'];

$paypal_business = $_POST['paypal_business'];

$bitcoin_processor = $_POST['bitcoin_processor'];

$post_bitcoin = $_POST['post_bitcoin'];

$pubkey_coinpayments = $_POST['publick_key'];

$seckey_coinpayments = $_POST['secret_key'];

$account_coinpayments = $_POST['merchant_id'];

$discover_check = $_POST['discover_check'];

$dinersc_check = $_POST['dinersc_check'];

$americanex_check = $_POST['americanex_check'];

$masterc_check = $_POST['masterc_check'];

$visa_check = $_POST['visa_check'];

$payza_merchant = $_POST['payza_merchant'];

$post_payza = $_POST['post_payza'];

$coinpayments_ipn = $_POST['ipn'];

$coinpayments_curr = $_POST['curr'];

$number_2checkout = $_POST['2checkout_id'];

$secret_2checkout = $_POST['2checkout_secret'];

//database check

$culumn = $query->addquery('select','deposite_methods','info','s','Bitcoin','methods=?');

if (!$culumn->info):

$query->normal("ALTER TABLE deposite_methods ADD info VARCHAR( 100 ) after secret_key");

endif;

//UPDATE==DEPOSITE_METHODS

$query->addquery('update','tbl_config','value=?','ss',[$currency_c,'currency'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$sumbole_c,'sumbole'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$minDeposit,'min_deposit'],'header=?');

$query->addquery('update','tbl_config','value=?','is',[$number_2checkout,'che2ckout_id'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$secret_2checkout,'che2ckout_secret'],'header=?');

$query->addquery('update','deposite_methods','status=?,account=?','iss',[$post_paypal,$paypal_business,'PayPal'],'methods=?');

$query->addquery('update','deposite_methods','processor=?,status=?,publick_key=?,secret_key=?,ipn=?,account=?,address=?,info=?','sisssssss',[$bitcoin_processor,$post_bitcoin,$pubkey_coinpayments,$seckey_coinpayments,$coinpayments_ipn,$account_coinpayments,$btcaddr,$coinpayments_curr,'Bitcoin'],'methods=?');

$query->addquery('update','deposite_methods','status=?','is',[$discover_check,'Discover'],'methods=?');

$query->addquery('update','deposite_methods','status=?','is',[$dinersc_check,'DinersClub'],'methods=?');

$query->addquery('update','deposite_methods','status=?','is',[$americanex_check,'AmericanExpress'],'methods=?');

$query->addquery('update','deposite_methods','status=?','is',[$masterc_check,'MasterCard'],'methods=?');

$query->addquery('update','deposite_methods','status=?','is',[$visa_check,'Visa'],'methods=?');

$query->addquery('update','deposite_methods','status=?,account=?','iss',[$post_payza,$payza_merchant,'Payza'],'methods=?');

$row_bank = $query->num_rows('tbl_config','*','s','enable_bank','header=?');

if ($row_bank > 0):

$query->addquery('update','tbl_config','value=?','is',[$_POST['post_bank'],'enable_bank'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$_POST['bank_details'],'bank_account'],'header=?');

else:

$bank_config = '
                              <td>Account Holder</td>
                                <td>Account</td>
                            </tr>
                            <tr>
                                <td>Bank Name</td>
                                <td>Name</td>
                            </tr>
                            <tr>
                                <td>Bank City or Town</td>
                                <td>City/Town</td>
                            </tr>

                            <tr>
                                <td>Account Number</td>
                                <td>Number</td>
                            </tr>
                            <tr>
                                <td>SWIFT</td>
                                <td>SWIFT</td>
                            </tr>
                            <tr>
                                <td>IBAN</td>
                                <td>IBAN</td>
                            </tr>
                            <tr>
                                <td>Account Currency</td>
                                <td>Currency</td>';

$query->addquery('update','tbl_config','header=?,value=?','sii',['enable_bank',$_POST['post_bank'],'60'],'config_id=?');

$query->addquery('update','tbl_config','header=?,value=?','ssi',['bank_account',$bank_config,'61'],'config_id=?');

endif;

$_SESSION['success']['succ']=true;

header("location: payment");

}

else{

alerts('success','succ');

}

show('Admin/Options/payment');
//================================== END PAYMENT =============================//
?>