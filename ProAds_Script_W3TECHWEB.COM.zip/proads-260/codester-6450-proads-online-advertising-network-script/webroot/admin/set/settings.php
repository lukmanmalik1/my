<?php

//============================= START SETTINGS ===============================//

require_once '../../functions.php';

if( isset($_POST['Save_gen'] ) ){

//POST==GENERAL 
$POST_name = $_POST['site_name'];
$POST_title = $_POST['site_title'];
$POST_desc = $_POST['site_desc'];
$POST_activateSt = $_POST['activate_status'];
$POST_fakeD = $_POST['fake_deals'];
$POST_keywords = $_POST['keywords'];
$POST_domain = $_POST['main_domain'];

//UPDATE==TBL_CONFIG
$query->addquery('update','tbl_config','value=?','ss',[$POST_name,'name'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_title,'site_title'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_desc,'site_description'],'header=?');
$query->addquery('update','tbl_config','value=?','is',[$POST_activateSt,'account_activate_email'],'header=?');
$query->addquery('update','tbl_config','value=?','is',[$POST_fakeD,'fake_deals'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_keywords,'keywords'],'header=?');

//update app file

$appConfig=get_app($POST_domain,Theme,$info->install,$info->version,$info->id,$info->app,$info->start,$info->update);

Write(CONFIG.'app.php',$appConfig,'w');

$_SESSION['success']['generale']=true;

header("location: settings");

}else{

alerts('success','generale');

alerts('error','err');

}


if( isset($_POST['Save_design'] ) ){

//POST==DESIGN 
$POST_Logo = $_POST['Logo'];
$POST_Logo2 = $_POST['Logo2'];
$POST_Favicon = $_POST['Favicon'];
$POST_themeC = $_POST['theme_color'];
$POST_homeC = $_POST['home_color'];

//UPDATE==TBL_CONFIG
$query->addquery('update','tbl_config','value=?','ss',[$POST_themeC,'dashboard_color'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_homeC,'home_color'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_Logo,'logo_url'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_Logo2,'logo_url_home'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_Favicon,'icon_url'],'header=?');

$_SESSION['success']['design']=true;

header("location: settings");

}else{

alerts('success','design');

alerts('error','err');

}

if( isset($_POST['Save_adv'] ) ){

//POST==ADVERTISERS
$POST_advC = $_POST['close_adv'];
$POST_enableB = $_POST['enable_banner'];
$POST_enableP = $_POST['enable_popup'];
$POST_enableD = $_POST['enable_direct'];
$POST_cpmB = $_POST['cpm_banner'];
$POST_viewsB = $_POST['views_banner'];
$POST_cpcB = $_POST['cpc_banner'];
$POST_clicksB = $_POST['clicks_banner'];
$POST_cpmP = $_POST['cpm_pop'];
$POST_popV = $_POST['pop_views'];
$POST_cpcP = $_POST['cpc_pop'];
$POST_popC = $_POST['pop_clicks'];
$POST_priceD = $_POST['price_direct'];
$POST_directH = $_POST['direct_hits'];
$POST_enableRADV = $_POST['enable_refadv'];

//UPDATE==TBL_CONFIG

//close adverstisers register
$query->addquery('update','tbl_config','value=?','ss',[$POST_advC,'close_adv'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$POST_enableB,'enable_banner'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_enableP,'enable_popup'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_enableD,'enable_direct'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_cpmB,'cpm_views'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_viewsB,'views_min'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_cpcB,'cpc_click'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_clicksB,'clicks_min'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_cpmP,'cpm_pop'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_popV,'pop_views'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_cpcP,'cpc_pop'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_popC,'pop_clicks'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_directH,'direct_hits'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_priceD,'cpm_direct'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$POST_enableRADV,'referral_advertiser'],'header=?');

$_SESSION['success']['adv']=true;

header("location: settings");

}else{

alerts('success','adv');

alerts('error','err');

}
	
	
if( isset($_POST['Save_pub'] ) ){

$close_pub = $_POST['close_pub'];
$adm_percent = $_POST['adm_percent'];
$web_status = $_POST['site_status'];
$enable_refpub = $_POST['enable_refpub'];
$ads_persite = $_POST['ads_persite'];
$ads_perpage = $_POST['ads_perpage'];
$referral_code = $_POST['referral_code'];
$referral_percent = $_POST['referral_percent'];

//close publishers register
$query->addquery('update','tbl_config','value=?','is',[$close_pub,'close_pub'],'header=?');

$query->addquery('update','tbl_config','value=?','is',[$adm_percent,'admin_percent'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$web_status,'site_status'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$enable_refpub,'referral_publisher'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$ads_persite,'ads_persite'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$ads_perpage,'ads_perpage'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$referral_code,'ref_code'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$referral_percent,'ref_percent'],'header=?');

$_SESSION['success']['pub']=true;
 
header("location: settings");

}else{
	    
alerts('success','pub');

alerts('error','err');

}

if( isset($_POST['Save_interg'] ) ){
    
$front_head = $_POST['front_head'];
$auth_head = $_POST['auth_head'];
$member_head = $_POST['member_head'];
$admin_head = $_POST['admin_head'];
$footer_code = base64_encode($_POST['footer_code']);
$body_code = $_POST['body_code'];

$query->addquery('update','tbl_config','value=?','ss',[$front_head,'head_code'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$auth_head,'auth_head'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$member_head,'member_head'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$admin_head,'admin_head'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$footer_code,'footer_code'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$body_code,'body_code'],'header=?');

$_SESSION['success']['interg']=true;
 
header("location: settings");
 
}else{

alerts('success','interg');

alerts('error','err');
	    
}

if( isset($_POST['Save_captcha'] ) ){
    
$enable_captcha = $_POST['enable_captcha'];
$captcha_type = $_POST['captcha_type'];
$recaptcha_key = $_POST['recaptcha_key'];
$recaptcha_secret = $_POST['recaptcha_secret'];
$captcha_signup = $_POST['captcha_signup'];
$captcha_login = $_POST['captcha_login'];
$captcha_contact = $_POST['captcha_contact'];
$captcha_forgot = $_POST['captcha_forgot'];


$query->addquery('update','tbl_config','value=?','ss',[$enable_captcha,'enable_captcha'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$captcha_type,'captcha_type'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$recaptcha_key,'reCAPTCHA_site_key'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$recaptcha_secret,'reCAPTCHA_secret_key'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$captcha_signup,'captcha_signup'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$captcha_login,'captcha_login'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$captcha_forgot,'captcha_forgot'],'header=?');

$_SESSION['success']['captcha']=true;
 
header("location: settings");
 
}else{
	    
alerts('success','captcha');

}

if( isset($_POST['Save_adminads'] ) ){
    
$banner_728x90 = $_POST['banner_728x90'];
$banner_468x60 = $_POST['banner_468x60'];
$banner_336x280 = $_POST['banner_336x280'];
$banner_300x250 = $_POST['banner_300x250'];
$banner_300x600 = $_POST['banner_300x600'];
$banner_120x600 = $_POST['banner_120x600'];
$banner_200x200 = $_POST['banner_200x200'];
$banner_125x125 = $_POST['banner_125x125'];

//database
$row_banners = $query->num_rows('tbl_config','*','s','banner_120x600','header=?');

if ($row_banners > 0):

$query->addquery('update','tbl_config','value=?','ss',[$banner_120x600,'banner_120x600'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$banner_200x200,'banner_200x200'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$banner_125x125,'banner_125x125'],'header=?');

else:

$query->addquery('insert','tbl_config','header,value','ss',['banner_120x600',$banner_120x600]);
$query->addquery('insert','tbl_config','header,value','ss',['banner_200x200',$banner_200x200]);
$query->addquery('insert','tbl_config','header,value','ss',['banner_125x125',$banner_125x125]);

endif;

$query->addquery('update','tbl_config','value=?','ss',[$banner_728x90,'banner_728x90'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$banner_468x60,'banner_468x60'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$banner_336x280,'banner_336x280'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$banner_300x250,'banner_300x250'],'header=?');
$query->addquery('update','tbl_config','value=?','ss',[$banner_300x600,'banner_300x600'],'header=?');

$_SESSION['success']['adminads']=true;
 
header("location: settings");

}else{
	    
alerts('success','adminads');

}


if( isset($_POST['Save_system'] ) ){
    
$enable_sites_category = $_POST['enable_sites_category'];

$enable_rcd_tabs = $_POST['enable_rcd_tabs'];

$enable_send_info = $_POST['enable_send_info'];

$enable_text_b = $_POST['enable_text_b'];

$disable_advertiser = $_POST['disable_advertiser'];

$disable_publishers = $_POST['disable_publishers'];


$query->addquery('update','tbl_config','value=?','ss',[$enable_sites_category,'enable_sites_category'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$enable_rcd_tabs,'enable_rcd_tabs'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$enable_send_info,'enable_send_info'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$enable_text_b,'enable_text_b'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$disable_advertiser,'disable_advertiser'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$disable_publishers,'disable_publishers'],'header=?');

$_SESSION['success']['system']=true;

header("location: settings");

}else{
	    
alerts('success','system');

}


if( isset($_POST['Save_security'] ) ){
    
$enable_note = $_POST['enable_note'];

$max_ip_day = $_POST['max_ip_day'];

$query->addquery('update','tbl_config','value=?','ss',[$enable_note,'enable_note'],'header=?');

$query->addquery('update','tbl_config','value=?','ss',[$max_ip_day,'max_ip_day'],'header=?');

$_SESSION['success']['security']=true;

header("location: settings");

}else{
	    
alerts('success','security');

}
	
	
show('Admin/Options/index');
//============================= END SETTINGS ===============================//
?>