<?php

require_once '../../functions.php';

if( isset($_POST['set-mail'])){

$request = check_request('support_mail',false,'email');

if ($request):

$query->addquery('update','tbl_config','value=?','ss',[$request,'support_email'],'header=?');

endif;

$w_option = check_request('option');

$w_host = check_request('host');

$w_port = check_request('port');

$w_ssl = check_request('ssl');

$w_pass = check_request('pass');

$w_username = check_request('username');

$configALL = get_opmail($w_option,$w_host,$w_port,$w_ssl,$w_pass,$w_username);

Write(MAILER.'CONFIG.php',$configALL,'w');

session_acv('success','succ_mail');

header('location: email');
}
else{

alerts('success','succ_mail');

}

show('Admin/Options/email');
?>