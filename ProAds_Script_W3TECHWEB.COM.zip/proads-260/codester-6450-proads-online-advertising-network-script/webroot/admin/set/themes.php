<?php

require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

$data = $query->limit('tbl_themes','*','id','asc','0,8');

while($res=$data->fetch_assoc()){

$ar=array('id'=>$res['id'],'name'=>$res['name'],'version'=>$res['version'],'status'=>$res['status'],'created'=>$res['created']);

array_push($with,$ar);

}

$smarty->assign('with',$with);

$smarty->assign('version_main',$fun->version_('Main'));

$smarty->assign('version_land',$fun->version_('Land'));

$smarty->assign('version_dark',$fun->version_('Dark'));

$smarty->assign('version_sweet',$fun->version_('Sweet'));


 //update a theme

 if(isset($_POST['update'])):

 $name = check_request('name');

 $version = check_request('version');

 Redirect(['controller' => 'admin', 'action' => 'set/update?theme='.$name.'&v='.$version]);

 endif;

 //upload new theme

 if(isset($_POST["new"])){

 if($_FILES["userfile"]["name"]) {

 $filename = $_FILES["userfile"]["name"];

 $source = $_FILES["userfile"]["tmp_name"];

 $type = $_FILES["userfile"]["type"];

 $name = explode(".", $filename);

 $theme_name = array('Land', 'Sweet', 'Main', 'Dark');
 
  if(!in_array($name['0'], $theme_name)):
 
  $_SESSION['new']['failed']=true;

  Redirect(['controller' => 'admin', 'action' => 'set/themes']);
 
  endif;

 $accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');

 foreach($accepted_types as $mime_type) {

 if($mime_type == $type) {
    
  $okay = true;
 
  break;
  }
 }

 $continue = strtolower($name[1]) == 'zip' ? true : false;

 if(!$continue) {

  $_SESSION['new']['failed']=true;

  Redirect(['controller' => 'admin', 'action' => 'set/themes']);
 
 }

 $target_path = WWW_ROOT.'template'.DS.'Uploads'.DS.$filename;

 if(move_uploaded_file($source, $target_path)) {

 $zip = new ZipArchive();

 $x = $zip->open($target_path);

 if ($x === true):

 $zip->extractTo(WWW_ROOT.'template'.DS);

 $zip->close();
 
 unlink($target_path);

 $query->addquery('insert','tbl_themes','name,version,status,created','ssis',[str_replace('.zip','',$filename),'1.0.0','2',$dateForm]);

 else:
     
 unlink($target_path);

 $_SESSION['new']['failed']=true;

 Redirect(['controller' => 'admin', 'action' => 'set/themes']);

 endif;
 
 $_SESSION['new']['pass']=true;

 Redirect(['controller' => 'admin', 'action' => 'set/themes']);

   }else {

 $_SESSION['new']['failed']=true;

 Redirect(['controller' => 'admin', 'action' => 'set/themes']);

 }

}
 }
 else{
  
 alerts('new','failed');

 alerts('new','pass');

 alerts('update','updated');
 
 }
 
 //activate a theme

 if(isset($_POST['activate'])):

 $request = check_request('id',false,'int');

 $name = check_request('name');

 $query->normal("update tbl_themes set status = '2' ");

 $query->addquery('update','tbl_themes','status=?','ii',[1,$request],'id=?');

 $appConfig=get_app($HOST,$name,$info->install,$info->version,$info->id,$info->app,$info->start,$info->update);

 Write(CONFIG.'app.php',$appConfig,'w');

 $_SESSION['success']['activate']=true;

 Redirect(['controller' => 'admin', 'action' => 'set/themes']);

 else:

 alerts('success','activate');

 endif;

 //delete a theme

 if(isset($_POST['delete'])):

 $request = check_request('id',false,'int');

 $name = check_request('name');

 $data = $query->addquery('delete','tbl_themes',false,'i',$request,'id=?');

 delete_files(WWW_ROOT.'template'.DS.$name);

 $_SESSION['success']['delete']=true;

 Redirect(['controller' => 'admin', 'action' => 'set/themes']);

 else:

 alerts('success','delete');

 endif;


 paging(0+1,ceil($query->num_rows('tbl_themes','*')/8)+1,'themes?p=');

 show('Admin/Options/themes');

?>