<?php

//================================== WEBSITES =================================>

require_once (dirname(dirname(__FILE__)).'/functions.php');

//assign
$smarty->assign('site_id',number_format($query->num_rows('tbl_link','*')));

$data = $query->limit('tbl_link','*','link_id','desc',$result['start'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=['link_id'=>$res['link_id'],'user_id'=>$res['user_id'],'url'=>$res['url'],'site_type'=>$res['site_type'],'status'=>$res['status']];

array_push($with,$ar);
}
$smarty->assign('with',$with);


if( isset($_POST['deactivate'] ) ){

$request = check_request('l_id',false,'int');

if ($request):

$data = $query->addquery('select','tbl_link','user_id,url','i',$request,'link_id=?');

$query->addquery('update','tbl_link','status=?,modified=?','isi',[3,$dateForm,$request],'link_id=?');

$query->addquery('insert','tbl_banned','user_id,bann_site,created','sss',[$data->user_id,$data->url,$dateForm]);

$query->addquery('update','tbl_codes','status=?','is',[2,$data->url],'url=?');

$_SESSION['success']['deactivate']=true;

Redirect(['controller' => 'admin', 'action' => 'sites']);

endif;

}
else{

alerts('success','deactivate');

}

if( isset($_POST['activate'] ) ){

$request = check_request('l_id',false,'int');

if ($request):
    
$data = $query->addquery('select','tbl_link','url','i',$request,'link_id=?');

$query->addquery('update','tbl_link','status=?,modified=?','isi',[1,$dateForm,$request],'link_id=?');

$query->addquery('delete','tbl_banned',false,'s',$data->url,'bann_site=?');

$query->addquery('update','tbl_codes','status=?','is',[1,$data->url],'url=?');

$_SESSION['success']['activate']=true;

Redirect(['controller' => 'admin', 'action' => 'sites']);

endif;

}
else{

alerts('success','activate');

}

if( isset($_POST['reject'] ) ){
    
$request = check_request('l_id',false,'int');

if ($request):
    
$data = $query->addquery('select','tbl_link','user_id,url','i',$request,'link_id=?');

$query->addquery('update','tbl_link','status=?,modified=?','isi',[4,$dateForm,$request],'link_id=?');

$_SESSION['success']['reject']=true;

Redirect(['controller' => 'admin', 'action' => 'sites']);

endif;

}
else{

alerts('success','reject');

}

if( isset($_POST['delete'] ) ){
    
$request = check_request('l_id',false,'int');

if ($request):
    
$data = $query->addquery('select','tbl_link','url','i',$request,'link_id=?');

$query->addquery('delete','tbl_link',false,'i',$request,'link_id=?');

$query->addquery('delete','tbl_banned',false,'s',$data->url,'bann_site=?');

$query->addquery('delete','tbl_codes',false,'s',$data->url,'url=?');

$_SESSION['success']['delete']=true;

Redirect(['controller' => 'admin', 'action' => 'sites']);

endif;

}
else{

alerts('success','delete');

}

paging($result['screen']+1,ceil($query->num_rows('tbl_link','*')/$result['perpage'])+1,'sites?p=');

show('Admin/Websites/index');

?>