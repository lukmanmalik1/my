<?php
require_once (dirname(dirname(__FILE__)).'/functions.php');

//updates notices

if(app_version()['version'] > $info->version)
{

$_SESSION['error']['VersionNew']=true;

$alert_ver = '<div class="alert alert-danger">A new version '.app_version()['version'].' has been released click <a href="/admin/update?v='.app_version()['version'] .'">here</a> to update it!</div>';
}
else{
    
$smarty->assign('app_version',false);

}

//NEW VERSION
if(isset($_SESSION['error']['VersionNew'])) {

$smarty->assign('app_version',true);

$smarty->assign('msg_version',$alert_ver);

unset($_SESSION['error']);
}

//admin earnings

$data = $query->addquery('select','tbl_stat','sum(admin_earn) as admearn','s',$current_month,'date=?');

$smarty->assign('admearn',number_format($data->admearn, 5, '.', ''));


//number of publishers

$data = $query->addquery('select','tbl_user','count(user_id) as bcount','s','publisher','role=?');

$smarty->assign('bcount',number_format($data->bcount));
	
//number of advertisers

$data = $query->addquery('select','tbl_user','count(user_id) as acount','s','advertiser','role=?');

$smarty->assign('acount',number_format($data->acount));

	
//number of users

$data = $query->addquery('select','tbl_user','count(user_id) as ucount');

$smarty->assign('ucount',number_format($data->ucount));



//publishers earnings

$data = $query->addquery('select','tbl_user','sum(publisher_earnings) as pubsearn');

$smarty->assign('pubsearn',number_format($data->pubsearn, 5, '.', ''));

//number of views

$data = $query->addquery('select','tbl_stat','sum(views) as vcount','s',$current_day,'date=?');

$smarty->assign('vcount',number_format($data->vcount));

//number of clicks

$data = $query->addquery('select','tbl_stat','sum(clicks) as clcount','s',$current_day,'date=?');

$smarty->assign('clcount',number_format($data->clcount));

//publishers earnings

$data = $query->addquery('select','tbl_user','sum(publisher_earnings) as pubearn','s','publisher','role=?');

$smarty->assign('pubearn',number_format($data->pubearn, 5, '.', ''));

//number of websites

$data = $query->addquery('select','tbl_link','count(link_id) as webcount');

$smarty->assign('webcount',number_format($data->webcount));

//approved websites

$data = $query->addquery('select','tbl_link','count(link_id) as apprcount','i','1','status=?');

$smarty->assign('apprcount',number_format($data->apprcount));

//waiting websites

$data = $query->addquery('select','tbl_link','count(link_id) as waitcount','i','2','status=?');

$smarty->assign('waitcount',number_format($data->waitcount));

//rejected websites

$data = $query->addquery('select','tbl_link','count(link_id) as rejectcount','i','4','status=?');

$smarty->assign('rejectcount',number_format($data->rejectcount));

//banned websites

$data = $query->addquery('select','tbl_banned','count(id) as banncount');

$smarty->assign('banncount',number_format($data->banncount));

//Active zones

$data = $query->addquery('select','tbl_codes','count(code_id) as activezones','i','1','status=?');

$smarty->assign('activezones',number_format($data->activezones));

//inactive zones

$data = $query->addquery('select','tbl_codes','count(code_id) as inactivezones','i','2','status=?');

$smarty->assign('inactivezones',number_format($data->inactivezones));

//earn zones

$data = $query->addquery('select','tbl_codes','sum(code_balance) as earnedzones','i','1','status=?');

$smarty->assign('earnedzones',number_format($data->earnedzones, 5, '.', ''));

//WITHDRWS_NU

$data = $query->addquery('select','tbl_withdrawal','count(withdrawal_id) as ucount');

$smarty->assign('withdraw_n',number_format($data->ucount));
	
//sent amount of withdrawals

$data = $query->addquery('select','tbl_withdrawal','sum(amount) as withcount','i','3','status=?');

$smarty->assign('withcount',number_format($data->withcount, 5, '.', ''));

//pending amount of withdrawals

$data = $query->addquery('select','tbl_withdrawal','sum(amount) as waitwith','i','2','status=?');

$smarty->assign('waitwith',number_format($data->waitwith, 5, '.', ''));


//deposts number

$data = $query->addquery('select','tbl_invoice','count(id) as deposcount');

$smarty->assign('deposcount',number_format($data->deposcount));
	
//paid

$data = $query->addquery('select','tbl_invoice','sum(amount) as depospaid','i','1','status=?');

$smarty->assign('depospaid',number_format($data->depospaid));

//unpaid

$data = $query->addquery('select','tbl_invoice','sum(amount) as deposunpaid','i','2','status=?');

$smarty->assign('deposunpaid',number_format($data->deposunpaid, 5, '.', ''));

//banners number
$data = $query->addquery('select','tbl_banner','count(id) as camacbanner ','i','1','status=?');

$smarty->assign('banner_found',number_format($banner_found=$data->camacbanner));

//pop number
$data = $query->addquery('select','tbl_popup','count(id) as camacpop ','i','1','status=?');

$smarty->assign('pop_found',number_format($pop_found=$data->camacpop));
	
//direct number
$data = $query->addquery('select','tbl_direct','count(id) as camacdir ','i','1','status=?');

$smarty->assign('dir_found',number_format($dir_found=$data->camacdir));

//campaigns found
$smarty->assign('campaigns_found',$banner_found + $pop_found + $dir_found);

show('Admin/Layout/dashboard');
?>