<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$data = $query->limit('announcements','*','id','desc',$result['start'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'title'=>$res['title'],'published'=>$res['published'],'modified'=>$res['modified'],'created'=>$res['created']);

array_push($with,$ar);
}
$smarty->assign('with',$with);


if( isset($_POST['delete'] ) ){

$request = check_request('a_id',false,'int');

if ($request):

$data = $query->addquery('delete','announcements',false,'i',$request,'id=?');

$_SESSION['error']['delete']=true;

Redirect(['controller' => 'admin', 'action' => 'announc']);

endif;

}	
else{

alerts('error','delete');

alerts('success','ann_edit');

alerts('success','succ');

}

paging($result['screen']+1,ceil($query->num_rows('announcements','*')/$result['perpage'])+1,'announc?p=');

show('Admin/Announcements/index');
?>