<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

//assign
$smarty->assign('id',number_format($query->num_rows('tbl_invoice','*')));

$data = $query->limit('tbl_invoice','*','id','desc',$result['start'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'user_id'=>$res['user_id'],'amount'=>$res['amount'],'method'=>$res['method'],'status'=>$res['status'],'created'=>$res['created']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

if(isset($_POST['delete'] ) ){

$request = $_POST['i_id'];

$data = $query->addquery('delete','tbl_invoice',false,'i',$request,'id=?');

$_SESSION['success']['succ']=true;

Redirect(['controller' => 'admin', 'action' => 'invoices']);


}	

else{

alerts('success','succ');

}

if(isset($_POST['paid'])){

$request = check_request('i_id');

$request = check_request('i_am');

if ($request):

$i_id = $_POST['i_id'];

$i_am = $_POST['i_am'];

$i_uid = $_POST['i_uid'];

$query->addquery('update','tbl_invoice','status=?','ii',[1,$i_id],'id=?');

$query->addquery('update','tbl_user','advertiser_balance=advertiser_balance+?','si',[$i_am,$i_uid],'user_id=?');

Redirect(['controller' => 'admin', 'action' => 'invoices']);

endif;

}

paging($result['screen']+1,ceil($query->num_rows('tbl_invoice','*')/$result['perpage'])+1,'invoices?p=');

show('Admin/Invoices/index');
?>