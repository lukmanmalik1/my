<?php
require_once ('../../functions.php');


if(!$_GET['id']){

exit('PLEASE SELECT USER ID!');

}else{

$us_id = $_GET['id'];

$data = $query->addquery('select','tbl_user','*','i',$us_id,'user_id=?');

$referr_id = $data->parent_id;

$smarty->assign('publisher_earnings',$data->publisher_earnings);

$smarty->assign('ucid',$data->user_id);

$data = $query->addquery('select','tbl_user','username,created','i',$referr_id,'user_id=?');

$smarty->assign('user_nameref',!empty($data->username));

$smarty->assign('createdref',!empty($data->created));

$data = $query->addquery('fetch','tbl_user','*','i',$us_id,'user_id=?');

while($res=$data->fetch_assoc()){
		$ar=array('user_id'=>$res['user_id'],'status'=>$res['status'],'username'=>$res['username'],'email'=>$res['email'],'login_ip'=>$res['login_ip'],'register_ip'=>$res['register_ip'],'created'=>$res['created'],'modified'=>$res['modified'],'parent_id'=>$res['parent_id'],'advertiser_balance'=>$res['advertiser_balance'],'publisher_earnings'=>$res['publisher_earnings'],'referral_earnings'=>$res['referral_earnings'],'withdrawal_method'=>$res['withdrawal_method'],'withdrawal_account'=>$res['withdrawal_account'],'first_name'=>$res['first_name'],'last_name'=>$res['last_name'],'country'=>$res['country'],'role'=>$res['role']);
		array_push($with,$ar);
	}

	$smarty->assign('with',$with)
	;


}

show('Admin/Users/view');
?>