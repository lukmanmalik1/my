<?php

require_once ('../../functions.php');

if(!$_GET['id']){

header('location: index');

}else{

$data = $query->addquery('select','tbl_user','*','i',$_GET['id'],'user_id=?');

$smarty->assign('us_id1',$_GET['id']);

$smarty->assign('username1',$data->username);

$smarty->assign('role1',$data->role);
	
$smarty->assign('status1',$data->status);
	
$smarty->assign('email1',$data->email);
	
$smarty->assign('publisher_earnings',$data->publisher_earnings);

$smarty->assign('advertiser_balance',$data->advertiser_balance);

if( isset($_POST['change'] ) ){

$request = check_request('role');

$request = check_request('status',false,'int');

$request = check_request('username');

$request = check_request('email',false,'email');

$request = check_request('publisher_earnings');

$request = check_request('advertiser_balance');

$role = check_request('role');

$status = check_request('status',false,'int');
	
$username = check_request('username');
	
$publisher_earnings = check_request('publisher_earnings');

$advertiser_balance = check_request('advertiser_balance');

$email = check_request('email',false,'email');

$query->addquery('update','tbl_user','role=?,status=?,username=?,email=?,publisher_earnings=?,advertiser_balance=?','sissssi',[$role,$status,$username,$email,$publisher_earnings,$advertiser_balance,$_GET['id']],'user_id=?');

$_SESSION['success']['succ']=true;

header('location: edit?id='.$_GET['id']);

	}

else{

alerts('success','succ');

	}
	
if( isset($_POST['delete'])){

$query->addquery('delete','tbl_user',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','payments',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','tbl_banned',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','tbl_banner',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','tbl_codes',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','tbl_direct',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','tbl_invoice',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','tbl_link',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','tbl_popup',false,'i',$_GET['id'],'user_id=?');

$query->addquery('delete','tbl_withdrawal',false,'i',$_GET['id'],'user_id=?');

$_SESSION['delete']['deleted']=true;

header('location: index');

exit();
}


}

show('Admin/Users/edit');

?>