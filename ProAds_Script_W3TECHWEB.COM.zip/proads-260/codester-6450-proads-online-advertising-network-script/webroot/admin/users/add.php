<?php

require_once ('../../functions.php');

if( isset($_POST['add-user'] ) ){

$request = check_request('status',false,'int');

$request = check_request('role');

$request = check_request('username');

$request = check_request('password','md5');

$request = check_request('password','base64_encode');

$request = check_request('email',false,'email');

if ($request):
    
$user_status= $_POST['status'];
    
$user_role = $_POST['role'];

$u_username = $_POST['username'];
	
$user_password = md5($_POST['password']);
	
$user_recover = base64_encode($_POST['password']);
	
$user_email = $_POST['email'];

$query->addquery('insert','tbl_user','role,status,username,password,email,recover,created','sisssss',[$user_role,$user_status,$u_username,$user_password,$user_email,$user_recover,$dateForm]);

$_SESSION['success']['succ']=true;

header("location: index");

endif;

}

show('Admin/Users/add');

?>