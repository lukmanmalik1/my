<?php

require_once ('../../functions.php');

$data = $query->limit('tbl_user','*','user_id','desc',$result['start'].','.$result['perpage']);


while($res=$data->fetch_assoc()){
    
$ar=array('user_id'=>$res['user_id'],'role'=>$res['role'],'status'=>$res['status'],'username'=>$res['username'],'email'=>$res['email'],'login_ip'=>$res['login_ip'],'register_ip'=>$res['register_ip'],'created'=>$res['created'],'modified'=>$res['modified']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

if( isset($_POST['deactivate'] ) ){

$request = check_request('u_id',false,'int');

if ($request):
    
$query->addquery('update','tbl_user','status=?','ii',[3,$request],'user_id=?');

$query->addquery('update','tbl_link','status=?','ii',[3,$request],'user_id=?');

$query->addquery('update','tbl_codes','status=?','ii',[2,$request],'user_id=?');

$_SESSION['success']['deactivate']=true;

header("location: index");

endif;


}else{

alerts('success','deactivate');

alerts('success','succ');

alerts('delete','deleted');

}

if( isset($_POST['activate'] ) ){
 
$request = check_request('u_id',false,'int');

if ($request):
    
$query->addquery('update','tbl_user','status=?','ii',[1,$request],'user_id=?');

$query->addquery('update','tbl_link','status=?','ii',[1,$request],'user_id=?');

$query->addquery('update','tbl_codes','status=?','ii',[1,$request],'user_id=?');

$_SESSION['success']['activate']=true;

header("location: /admin/users/index");

endif;

}else{

alerts('success','activate');

}


paging($result['screen']+1,ceil($query->num_rows('tbl_user','*')/$result['perpage'])+1,'index?p=');

show('Admin/Users/index');

?>