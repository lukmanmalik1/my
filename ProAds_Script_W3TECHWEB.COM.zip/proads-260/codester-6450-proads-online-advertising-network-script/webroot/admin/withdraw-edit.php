<?php

//============================= EDIT/WITHDRAWS ================================>

require_once (dirname(dirname(__FILE__)).'/functions.php');

if( !isset($_GET['id'])){
    
exit('PLEASE SELECT WITHDRAWAL ID');

}else{

$data = $query->addquery('select','tbl_withdrawal','withdrawal_id,amount,fee,status','s',$_GET['id'],'withdrawal_id=?');

$smarty->assign('withdrawal_edit',$data->withdrawal_id);

$smarty->assign('fee',$data->fee);

$smarty->assign('status',$data->status);

if( isset($_POST['change'])){

$request = check_request('status',false,'int');

$request = check_request('fee');

if ($request):

$status= check_request('status');

$fee = check_request('fee');

$query->addquery('update','tbl_withdrawal','status=?,fee=?','isi',[$status,$fee,$_GET['id']],'withdrawal_id=?');

$_SESSION['success']['succ']=true;

Redirect(['controller' => 'admin', 'action' => 'withdraws']);

endif;

}
}

if( isset($_POST['delete'])){

$return_am = number_format(($data->amount + $data->fee), 5, '.', '');

$query->addquery('update','tbl_user','publisher_earnings=publisher_earnings+?','si',[$return_am,$user->user_id],'user_id=?');

$query->addquery('delete','tbl_withdrawal',false,'i',$_GET['id'],'withdrawal_id=?');

$_SESSION['delete_w']['deleted']=true;

Redirect(['controller' => 'admin', 'action' => 'withdraws']);

}


show('Admin/Withdraws/edit');

?>