<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$alexa = new Get_Alexa_Ranking();

if(!isset($_GET['id'])):
    
exit('PLEASE SELECT A WEBSITE ID!');

endif;

$data = $query->addquery('select','tbl_link','url','i',$_GET['id'],'link_id=?');

$smarty->assign('url',$data->url);

if(empty($alexa->get_rank($data->url))):

$smarty->assign('rank','0');

else:

$smarty->assign('rank',$alexa->get_rank($data->url));

endif;


show('Admin/Websites/alexa')

?>