<?php
//================================ START WITHDRAWALS ==========================>

require_once (dirname(dirname(__FILE__)).'/functions.php');

$data = $query->limit('tbl_withdrawal','*','withdrawal_id','desc',$result['start'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('withdrawal_id'=>$res['withdrawal_id'],'user_id'=>$res['user_id'],'amount'=>$res['amount'],'fee'=>$res['fee'],'withdrawal_account'=>$res['withdrawal_account'],'withdrawal_method'=>$res['withdrawal_method'],'created'=>$res['created'],'status'=>$res['status']);

array_push($with,$ar);
}

$smarty->assign('with',$with);

if(isset($_SESSION['fhb_msg'])):

$smarty->assign('fhb_msg',$_SESSION['fhb_msg']);

endif;

if( isset($_POST['approved'] ) ){

$request = check_request('w_id',false,'int');

if ($request):

$query->addquery('update','tbl_withdrawal','status=?','ii',[1,$request],'withdrawal_id=?');

$_SESSION['success']['approved']=true;

Redirect(['controller' => 'admin', 'action' => 'withdraws']);

endif;

}else{

alerts('success','approved');

alerts('delete_w','deleted');

}

 if( isset($_POST['completed'] ) ){

  $request = check_request('w_id',false,'int');

  if ($request):

  $data = $query->addquery('select','tbl_withdrawal','*','i',$request,'withdrawal_id=?');

  if($data->withdrawal_method == 'FaucetHub'):

      $result = $fhb->send($data->withdrawal_account,$data->amount);

        if($result["success"]):
           
        $query->addquery('update','tbl_withdrawal','status=?','ii',[3,$request],'withdrawal_id=?');
        $_SESSION['success']['completed']=true;
        Redirect(['controller' => 'admin', 'action' => 'withdraws']);
        
        elseif(!$result["success"]):

        $_SESSION['bad']['check']=true;
        $_SESSION['fhb_msg']=$result["message"];
        Redirect(['controller' => 'admin', 'action' => 'withdraws']);
        
        endif;
        else:
        $query->addquery('update','tbl_withdrawal','status=?','ii',[3,$request],'withdrawal_id=?');
        $_SESSION['success']['completed']=true;
        Redirect(['controller' => 'admin', 'action' => 'withdraws']);
        endif;

   endif;

 }else{

 alerts('success','completed');

 alerts('success','succ');

 alerts('bad','check');

 }

 paging($result['screen']+1,ceil($query->num_rows('tbl_withdrawal','*')/$result['perpage'])+1,'withdraws?p=');

 show('Admin/Withdraws/index')

//================================= END WITHDRAWALS ===========================>
?>