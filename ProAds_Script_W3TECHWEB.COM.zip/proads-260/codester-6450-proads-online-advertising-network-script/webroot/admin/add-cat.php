<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');


if( isset($_POST['add-cat'] ) ){

$request = check_request('name');

if ($request):
    
$query->addquery('insert','tbl_cat','name,created','ss',[$request,$dateForm]);

$_SESSION['success']['addcat']=true;

Redirect(['controller' => 'admin', 'action' => 'catsite']);

endif;

}

show('Admin/Websites/add-cat');

?>