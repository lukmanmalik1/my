<?php
require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');
    
if( isset($_POST['banner'] ) ){

//UPLOAD
$up->photo(['photo' => $_FILES["photo"], 'error' => $_FILES["photo"]["error"],'path' => 'advertiser/uploads/','controller' => 'admin', 'action' => 'create-banner']);

$banner = $up->img();

if (!empty($banner)):

$query->addquery('insert','tbl_banner','user_id,banner_image,banner_url,banner_title,banner_dscr,banner_clicks,price,banner_country,banner_device,banner_size,banner_type,type_spend,status,filter,created,role','isssssssssssissi',[$user->user_id,$banner,$_POST['banner_website'],$_POST['banner_title'],$_POST['banner_dsc'],'0','0.000','["ALL"]',$_POST['banner_device'],$_POST['banner_size'],$_POST['banner_type'],'clicks','1','clean',$dateForm,'2']);

else:
    
$query->addquery('insert','tbl_banner','user_id,banner_url,banner_title,banner_dscr,banner_clicks,price,banner_country,banner_device,banner_size,banner_type,type_spend,status,filter,created,role','issssssssssissi',[$user->user_id,$_POST['banner_website'],$_POST['banner_title'],$_POST['banner_dsc'],'0','0.000','["ALL"]',$_POST['banner_device'],$_POST['banner_size'],$_POST['banner_type'],'clicks','1','clean',$dateForm,'2']);

endif;

$_SESSION['success']['campaign_succ']=true;

header("location: index");

}
else{

alerts('error','upe_error');

alerts('error','format_error');

alerts('error','size_error');

alerts('error','up_error');

alerts('error','cpm_error');

alerts('error','cpc_error');

alerts('error','upe_error');
 
}

show('Admin/Campaigns/create-banner');

?>