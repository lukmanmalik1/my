<?php
require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

if( isset($_POST['popup'] ) ){

$query->addquery('insert','tbl_popup','user_id,popup_url,name,popup_clicks,price,popup_country,popup_device,type_spend,status,filter,created,role','isssssssissi',[$user->user_id,$_POST['pop_website'],$_POST['name'],'0','0.000','["ALL"]',$_POST['pop_device'],'clicks','1','clean',$dateForm,'2']);


$_SESSION['success']['campaign_succ']=true;

header("location:index");

}

show('Admin/Campaigns/create-popup');

?>