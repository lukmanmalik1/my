<?php

require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

if( isset($_POST['direct'] ) ){

$query->addquery('insert','tbl_direct','user_id,direct_url,name,direct_clicks,price,direct_country,direct_device,status,filter,created,role','issssssissi',[$user->user_id,$_POST['direct_website'],$_POST['name'],'0','0.00000','["ALL"]',$_POST['direct_device'],'1','clean',$dateForm,'2']);

$_SESSION['success']['campaign_succ']=true;

header("location:index");

}

show('Admin/Campaigns/create-direct');

?>