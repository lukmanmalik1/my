 <?php

 require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

 if(!$_GET['id'] || !$_GET['campaign']){

 exit('Please select a campaign to edit!');

 }else{


  switch($_GET['campaign']){

  case 'banner':

  $data = $query->addquery('select','tbl_banner','*','i',$_GET['id'],'id=?');

  $smarty->assign('arr',implode(", ",json_decode($data->banner_country)));
  
  $smarty->assign('image',$data->banner_image);

  $smarty->assign('url',$data->banner_url);
	
  $smarty->assign('title',$data->banner_title);
	
  $smarty->assign('dscr',$data->banner_dscr);
	
  $smarty->assign('views',$data->banner_views);

  $smarty->assign('clicks',$data->banner_clicks);

  $smarty->assign('device',$data->banner_device);

  $smarty->assign('size',$data->banner_size);

  $smarty->assign('type_banner',$data->banner_type);

  $smarty->assign('type_spend',$data->type_spend);

  break;
  case 'popup':

  $data = $query->addquery('select','tbl_popup','*','i',$_GET['id'],'id=?');

  $smarty->assign('arr',implode(", ",json_decode($data->popup_country)));

  $smarty->assign('url',$data->popup_url);
	
  $smarty->assign('title',$data->name);

  $smarty->assign('views',$data->popup_views);

  $smarty->assign('clicks',$data->popup_clicks);

  $smarty->assign('country',$data->popup_country);

  $smarty->assign('device',$data->popup_device);

  $smarty->assign('type_spend',$data->type_spend);

  break;
  case 'direct':

  $data = $query->addquery('select','tbl_direct','*','i',$_GET['id'],'id=?');

  $smarty->assign('arr',implode(", ",json_decode($data->direct_country)));

  $smarty->assign('url',$data->direct_url);
	
  $smarty->assign('title',$data->name);

  $smarty->assign('clicks',$data->direct_clicks);

  $smarty->assign('country',$data->direct_country);

  $smarty->assign('device',$data->direct_device);

  break;
  
  }
 
  //Assing default
  
  $smarty->assign('id',$_GET['id']);

  $smarty->assign('role',$data->role);

  $smarty->assign('status',$data->status);

  $smarty->assign('campaign',$_GET['campaign']);

  
  if( isset($_POST['change'] ) ){

  $role = check_request('role',false,'int');

  $status = check_request('status',false,'int');

  $title = check_request('title');

  $dscr = check_request('dscr');

  $url = check_request('url');

  $size = check_request('size');

  $device = check_request('device');

  $banner_type = check_request('banner_type');
	
  $type_spend = check_request('type_spend');

  $country = json_encode($_POST['country']);

  if ($_POST['country'] == NULL):
      
  $country = json_encode([$_POST['selected_country']]);

  endif;
  
  if ($_GET['campaign'] == 'banner'):
    
  $query->addquery('update','tbl_banner','role=?,status=?,banner_url=?,banner_title=?,banner_country=?,banner_device=?,banner_size=?','iisssssi',[$role,$status,$url,$title,$country,$device,$size,$_GET['id']],'id=?');

  elseif($_GET['campaign'] == 'popup'):
    
  $query->addquery('update','tbl_popup','role=?,status=?,popup_url=?,name=?,popup_country=?,popup_device=?','iissssi',[$role,$status,$url,$title,$country,$device,$_GET['id']],'id=?');

  elseif($_GET['campaign'] == 'direct'):
    
  $query->addquery('update','tbl_direct','role=?,status=?,direct_url=?,name=?,direct_device=?,direct_country=?','iissssi',[$role,$status,$url,$title,$clicks,$device,$country,$_GET['id']],'id=?');

  endif;

  $_SESSION['success']['succ']=true;

  header('location: edit?id='.$_GET['id'].'&campaign='.$_GET['campaign']);

	}else{

  alerts('success','succ');

  }
	
  if( isset($_POST['delete'])){

  if ($_GET['campaign'] == 'banner'):
    
  $query->addquery('delete','tbl_banner',false,'i',$_GET['id'],'id=?');

  elseif($_GET['campaign'] == 'popup'):
    
  $query->addquery('delete','tbl_popup',false,'i',$_GET['id'],'id=?');

  elseif($_GET['campaign'] == 'direct'):
    
  $query->addquery('delete','tbl_direct',false,'i',$_GET['id'],'id=?');

  endif;

  $_SESSION['delete']['deleted']=true;

  header('location: index');

  exit();

  }
 }

show('Admin/Campaigns/edit');

?>