<?php

require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

if(isset($_POST['fill'])){

if(empty($_POST['pub_id']) || empty($_POST['site_id']) || empty($_POST['campaign_id'])){


//var_export($arr);

//exit();
$_SESSION['warning']['report_err']=true;

header( "location: index" );

}else{

$arr = explode('|', $_POST['campaign_id']);

header('location: ?pub_id='.$_POST['pub_id'].'&site_id='.$_POST['site_id'].'&campaign_id='.$arr[0].'&campaign='.$arr[1]);
 }
}else{

alerts('warning','report_err');

$smarty->assign('pub_id',false);

$smarty->assign('site_id',false);

$smarty->assign('campaign_id',false);

$smarty->assign('campaign',false);

}

//========= Publisher =======//


$with_user=array();

$data = $query->normal("SELECT username,user_id FROM tbl_user WHERE role = 'publisher' ORDER BY user_id ASC");

while($res=$data->fetch_assoc()){

$ar_user=array('user_id'=>$res['user_id'],'username'=>$res['username']);

array_push($with_user,$ar_user);}

$smarty->assign('with_user',$with_user);

//========= Site =======//
$with_site=array();

$data = $query->normal("SELECT link_id,url FROM tbl_link WHERE status = '1' ORDER BY link_id ASC");

while($res=$data->fetch_assoc()){

$ar_site=array('link_id'=>$res['link_id'],'url'=>$res['url']);

array_push($with_site,$ar_site);}

$smarty->assign('with_site',$with_site);

//========= Banner =======//
$with_banner=array();

$data = $query->normal("SELECT id,banner_title FROM tbl_banner WHERE status = '1' ORDER BY id ASC");

while($res=$data->fetch_assoc()){

$ar_banner=array('id'=>$res['id'],'banner_title'=>$res['banner_title']);

array_push($with_banner,$ar_banner);}

$smarty->assign('with_banner',$with_banner);

//========= popup =======//
$with_popup=array();

$data = $query->normal("SELECT id,name FROM tbl_popup WHERE status = '1' ORDER BY id ASC");

while($res=$data->fetch_assoc()){

$ar_popup=array('id'=>$res['id'],'name'=>$res['name']);

array_push($with_popup,$ar_popup);}

$smarty->assign('with_popup',$with_popup);
	

//========= direct =======//
$with_direct=array();

$data = $query->normal("SELECT id,name FROM tbl_direct WHERE status = '1' ORDER BY id ASC");

while($res=$data->fetch_assoc()){

$ar_direct=array('id'=>$res['id'],'name'=>$res['name']);

array_push($with_direct,$ar_direct);}

$smarty->assign('with_direct',$with_direct);

if(!empty($_GET['pub_id']) && !empty($_GET['site_id']) && !empty($_GET['campaign_id'])){

$smarty->assign('pub_id',$_GET['pub_id']);

$smarty->assign('site_id',$_GET['site_id']);

$smarty->assign('campaign_id',$_GET['campaign_id']);

$smarty->assign('campaign',$_GET['campaign']);

//============= type ======//
$with_stateAll=array();

$data = $query->normal("SELECT id,type_cam, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat WHERE pub_id ='".$_GET['pub_id']."' and url ='".$_GET['site_id']."' and campaign_id ='".$_GET['campaign_id']."' AND country<>' '  group by type_cam ASC");

while($res=$data->fetch_assoc()){

$ar_stateAll=array('id'=>$res['id'],'type_cam'=>$res['type_cam'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));

array_push($with_stateAll,$ar_stateAll);}

$smarty->assign('with_stateAll',$with_stateAll);

//============= country ======//
$with_stateCountry=array();

$data = $query->normal("SELECT id,country, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat WHERE pub_id ='".$_GET['pub_id']."' and url ='".$_GET['site_id']."' and campaign_id ='".$_GET['campaign_id']."' AND country<>' ' group by country ASC");

while($res=$data->fetch_assoc()){
    
$ar_stateCountry=array('id'=>$res['id'],'country'=>$res['country'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));

array_push($with_stateCountry,$ar_stateCountry);}

$smarty->assign('with_stateCountry',$with_stateCountry);

//============= referer ======//
$with_stateReferer=array();

$data = $query->normal("SELECT referer_domain, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn, COUNT(id) as id FROM tbl_stat WHERE pub_id ='".$_GET['pub_id']."' and url ='".$_GET['site_id']."' and campaign_id ='".$_GET['campaign_id']."' AND country<>' ' group by referer_domain ASC");

while($res=$data->fetch_assoc()){

$ar_stateReferer=array('id'=>$res['id'],'referer_domain'=>$res['referer_domain'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));

array_push($with_stateReferer,$ar_stateReferer);}

$smarty->assign('with_stateReferer',$with_stateReferer);

}else{

//============= type ===
$with_stateAll=array();

$data = $query->normal("SELECT id,type_cam, COUNT(*) total, SUM(views) AS views , SUM(clicks) AS clicks, SUM(publisher_earn) AS publisher_earn FROM tbl_stat WHERE country<>' ' and type_cam<>' ' group by type_cam ASC");

while($res=$data->fetch_assoc()){

$ar_stateAll=array('id'=>$res['id'],'type_cam'=>$res['type_cam'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));

array_push($with_stateAll,$ar_stateAll);}

$smarty->assign('with_stateAll',$with_stateAll);

//============= country ======//

$with_stateCountry=array();

$data = $query->normal("SELECT id,country, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat WHERE country<>' ' and type_cam<>' ' group by country ASC");

while($res=$data->fetch_assoc()){

$ar_stateCountry=array('id'=>$res['id'],'country'=>$res['country'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));

array_push($with_stateCountry,$ar_stateCountry);}

$smarty->assign('with_stateCountry',$with_stateCountry);

//============= referer ======//
$with_stateReferer=array();

$data=$query->normal("SELECT id,referer_domain, count(*) total, SUM(views) as views , SUM(clicks) as clicks, SUM(publisher_earn) as publisher_earn FROM tbl_stat WHERE country<>' 'and type_cam<>' ' group by referer_domain ASC");

while($res=$data->fetch_assoc()){

$ar_stateReferer=array('id'=>$res['id'],'referer_domain'=>$res['referer_domain'],'views'=>number_format($res['views']),'clicks'=>number_format($res['clicks']),'publisher_earn'=>number_format($res['publisher_earn'], 5, '.', ''));

array_push($with_stateReferer,$ar_stateReferer);}

$smarty->assign('with_stateReferer',$with_stateReferer);

}

show('Admin/Reports/index');

?>