<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

if(!isset($_GET['id'])):

exit('PLEASE SELECT ID');

endif;

$data = $query->addquery('select','announcements','*','i',$_GET['id'],'id=?');

$smarty->assign('title',$data->title);

$smarty->assign('content',$data->content);

$smarty->assign('published',$data->published);

if(isset($_POST['edit']) ){

$title = check_request('title');

$role = check_request('role');

$content = $_POST['editor1'];

$query->addquery('update','announcements','title=?,content=?,published=?','sssi',[$title,$content,$role,$_GET['id']],'id=?');

$_SESSION['success']['ann_edit']=true;

Redirect(['controller' => 'admin', 'action' => 'announc']);

}

show('Admin/Announcements/edit');

?>