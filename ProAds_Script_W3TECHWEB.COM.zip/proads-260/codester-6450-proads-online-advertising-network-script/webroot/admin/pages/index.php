<?php

require_once ('../../functions.php');

if( isset($_POST['edit'] ) ){

header('location: edit?p='.$_POST['p_id']);

}

show('Admin/Pages/index');

?>