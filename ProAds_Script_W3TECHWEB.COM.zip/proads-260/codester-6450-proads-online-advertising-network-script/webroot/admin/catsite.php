<?php

//================================== WEBSITES =================================>

require_once (dirname(dirname(__FILE__)).'/functions.php');


$data = $query->limit('tbl_cat','*','id','desc',$result['start'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=['id'=>$res['id'],'name'=>$res['name'],'status'=>$res['status'],'created'=>$res['created']];

array_push($with,$ar);
}
$smarty->assign('with',$with);


if( isset($_POST['deactivate'] ) ){

$request = check_request('c_id',false,'int');

if ($request):

$query->addquery('update','tbl_cat','status=?','ii',[2,$request],'id=?');

$_SESSION['success']['deactivate']=true;

Redirect(['controller' => 'admin', 'action' => 'catsite']);

endif;

}
else{

alerts('success','deactivate');

alerts('success','addcat');

}

if( isset($_POST['activate'] ) ){

$request = check_request('c_id',false,'int');

if ($request):
    
$query->addquery('update','tbl_cat','status=?','ii',[1,$request],'id=?');

$_SESSION['success']['activate']=true;

Redirect(['controller' => 'admin', 'action' => 'catsite']);

endif;

}
else{

alerts('success','activate');

}


if( isset($_POST['delete'] ) ){
    
$request = check_request('c_id',false,'int');

if ($request):
    
$query->addquery('delete','tbl_cat',false,'i',$request,'id=?');

$_SESSION['success']['delete']=true;

Redirect(['controller' => 'admin', 'action' => 'catsite']);

endif;

}
else{

alerts('success','delete');

}

paging($result['screen']+1,ceil($query->num_rows('tbl_cat','*')/$result['perpage'])+1,'catsite?p=');

show('Admin/Websites/cat');

?>