<?php

//================================== ZONES ====================================>
require_once (dirname(dirname(__FILE__)).'/functions.php');

//assign
$smarty->assign('code_id',number_format($query->num_rows('tbl_codes','*')));

$data = $query->limit('tbl_codes','*','code_id','desc',$result['start'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('code_id'=>$res['code_id'],'user_id'=>$res['user_id'],'url'=>$res['url'],'site_type'=>$res['site_type'],'code_type'=>$res['code_type'],'status'=>$res['status'],'code_name'=>$res['code_name'],'code_balance'=>$res['code_balance'],'code_views'=>$res['code_views'],'code_clicks'=>$res['code_clicks']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

if( isset($_POST['deactivate'] ) ){
      
$request = check_request('c_id',false,'int');

$query->addquery('update','tbl_codes','status=?','ii',[2,$request],'code_id=?');

$_SESSION['success']['deactivate']=true;

Redirect(['controller' => 'admin', 'action' => 'codes']);


}	

else{

alerts('success','deactivate');

}

if( isset($_POST['activate'] ) ){
 
$request = check_request('c_id',false,'int');

$query->addquery('update','tbl_codes','status=?','ii',[1,$request],'code_id=?');

$_SESSION['success']['activate']=true;

Redirect(['controller' => 'admin', 'action' => 'codes']);

}	

else{

alerts('success','activate');

}

if( isset($_POST['delete'] ) ){
    
$request = check_request('c_id',false,'int');

if ($request):

$query->addquery('delete','tbl_codes',false,'i',$request,'code_id=?');

$_SESSION['success']['delete']=true;

Redirect(['controller' => 'admin', 'action' => 'codes']);

endif;

}
else{

alerts('success','delete');

}

paging($result['screen']+1,ceil($query->num_rows('tbl_codes','*')/$result['perpage'])+1,'codes?p=');

show('Admin/Zones/index');
?>