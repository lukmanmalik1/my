<?php

//=============================== ADD ANNONCEMENTS ============================>

require_once (dirname(dirname(__FILE__)).'/functions.php');

if( isset($_POST['add-announc'] ) ){

$title = check_request('title');

$role = check_request('role');

$editor1 = $_POST['editor1'];

$data = $query->addquery('insert','announcements','title,published,content,created,modified','sssss',[$title,$role,$editor1,$dateForm,$dateForm]);

session_acv('success','succ');

Redirect(['controller' => 'admin', 'action' => 'announc']);

}

show('Admin/Announcements/add');
?>