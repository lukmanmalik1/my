<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$smarty->assign('bann_s',number_format($query->num_rows('tbl_banned','*')));

$data = $query->limit('tbl_banned','*','id','desc',$result['start'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'bann_site'=>$res['bann_site'],'user_id'=>$res['user_id'],'created'=>$res['created']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

if( isset($_POST['delete']) ){

$request = check_request('b_id',false,'int');

$request = check_request('url');

if ($request):

$id = check_request('b_id',false,'int');

$url = check_request('url');
    
$query->addquery('delete','tbl_banned',false,'i',$id,'id=?');

$query->addquery('delete','tbl_link',false,'i',$url,'id=?');

$_SESSION['success']['delete']=true;

Redirect(['controller' => 'admin', 'action' => 'bannsite']);

endif;

}else{

alerts('success','delete');

}

paging($result['screen']+1,ceil($query->num_rows('tbl_banned','*')/$result['perpage'])+1,'bannsite?p=');

show('Admin/Websites/banned');

?>