<?php
//======================== STEP 3: CREATE ADMIN USER =========================//
//=============== IN STEP 3 WE GONE CREATE YOUR ADMIN PROFILE ================//
//================= THAT'S IT! YOUR INSTALLATION COMPLETED ===================//
//============================== THANK YOU! ==================================//

require_once (dirname(__DIR__)."/loader.php");

require_once (DATA.'config.php');

if(isset($_POST['register'] ) ){

$username = $_POST['username'];

$password = md5($_POST['password']);

$email = $_POST['email'];

$recover = base64_encode($_POST['password']);

$passwordcheck = md5($_POST['passwordcheck']);

$website=$_POST['website'];

if($password == $passwordcheck){

$query->addquery('insert','tbl_user','username,status,password,email,role,recover,created','sisssss',[$username,'1',$password,$email,'admin',$recover,$dateForm]);


  if(!endsWith($website, '/')):
  
   $website = $website.DS;
  
  endif;
  
   $appConfig = get_app($website,Theme,'on','2.5.0',$sr->csrf_token(),'ProAds',$dateForm,$dateForm);
   

WRITE(CONFIG.'app.php',$appConfig,'w');

session_acv('success','express_login');

Redirect(['controller' => 'auth', 'action' => 'login']);

}else{

//pass error

session_acv('errpass','passfaild');

Redirect(['controller' => 'installer', 'action' => 'admin']);

}

}else{

alerts('errpass','passfaild');

}

show('Installer/admin');

?>