-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le :  sam. 15 sep. 2018 à 18:02
-- Version du serveur :  10.2.17-MariaDB
-- Version de PHP :  7.1.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `u947616082_like`
--

-- --------------------------------------------------------

--
-- Structure de la table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `published` enum('1','2') COLLATE utf8_persian_ci NOT NULL DEFAULT '1',
  `content` text CHARACTER SET utf8 DEFAULT NULL,
  `modified` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Structure de la table `deposite_methods`
--

CREATE TABLE `deposite_methods` (
  `id` int(10) NOT NULL,
  `methods` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `processor` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `account` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `address` varchar(200) NOT NULL,
  `publick_key` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `secret_key` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `info` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `ipn` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `status` varchar(10) CHARACTER SET utf8 DEFAULT NULL COMMENT '1=active, 2=inactive',
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `deposite_methods`
--

INSERT INTO `deposite_methods` (`id`, `methods`, `processor`, `account`, `address`, `publick_key`, `secret_key`, `info`, `ipn`, `status`, `created`) VALUES
(1, 'Bitcoin', 'coinpayments', '', '', '', '', 'BTC', '', '', ''),
(2, 'PayPal', 'express_checkout', '', '', '', '', '', '', '1', ''),
(3, 'Payza', 'checkout', '', '', '', '', '', '', '1', ''),
(4, 'Discover', '2checkout', '', '', '', '', '', '', '1', ''),
(5, 'AmericanExpress', '2checkout', '', '', '', '', '', '', '1', ''),
(6, 'DinersClub', '2checkout', '', '', '', '', '', '', '1', ''),
(7, 'Visa', '2checkout', '', '', '', '', '', '', '1', ''),
(8, 'MasterCard', '2checkout', '', '', '', '', '', '', '1', '');

-- --------------------------------------------------------

--
-- Structure de la table `log_history`
--

CREATE TABLE `log_history` (
  `id` int(10) NOT NULL,
  `ip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `status` enum('1','2') CHARACTER SET utf8 DEFAULT NULL COMMENT '1= success,2=failed',
  `date` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT 0,
  `txn_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `item_number` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `payment_gross` decimal(20,3) DEFAULT 0.000,
  `amount_btc` decimal(20,8) DEFAULT NULL,
  `currency_code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `payment_status` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_banned`
--

CREATE TABLE `tbl_banned` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT 0,
  `bann_site` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_banner`
--

CREATE TABLE `tbl_banner` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT 0,
  `banner_image` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `banner_url` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `banner_title` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `banner_dscr` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `views` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `clicks` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `spend` decimal(20,5) DEFAULT 0.00000,
  `price` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `banner_price` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `banner_views` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `banner_clicks` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `banner_country` varchar(1500) CHARACTER SET utf8 NOT NULL,
  `banner_device` varchar(20) CHARACTER SET utf8 NOT NULL,
  `banner_size` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner_type` enum('text','image') CHARACTER SET utf8 DEFAULT NULL,
  `type_spend` enum('views','clicks') CHARACTER SET utf8 DEFAULT NULL,
  `category` varchar(300) DEFAULT NULL,
  `status` enum('1','2','3','4') NOT NULL DEFAULT '2' COMMENT '1=active ,2= inactive , 3=completed ,4= pending,5= rejected',
  `filter` varchar(100) CHARACTER SET utf8 NOT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `role` enum('1','2','3','4','5') CHARACTER SET utf8 NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tbl_banner`
--

INSERT INTO `tbl_banner` (`id`, `user_id`, `banner_image`, `banner_url`, `banner_title`, `banner_dscr`, `views`, `clicks`, `spend`, `price`, `banner_price`, `banner_views`, `banner_clicks`, `banner_country`, `banner_device`, `banner_size`, `banner_type`, `type_spend`, `status`, `filter`, `created`, `role`) VALUES
(1, 1, '', 'http://example.com', 'Default Banner 728x90', 'Default Banner', '0', '0', '0.00000', '0.000', NULL, NULL, '0', '["ALL"]', 'ALL', '728x90', 'text', 'clicks', '1', 'clean', '24/02/18 , 16:34 PM', '2');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_cat`
--

CREATE TABLE `tbl_cat` (
  `id` int(10) NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  `created` varchar(300) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tbl_cat`
--

INSERT INTO `tbl_cat` (`id`, `name`, `status`, `created`) VALUES
(11, 'cat4', '1', '13/09/18 , 08:47 AM'),
(9, 'cat3', '1', '12/09/18 , 17:26 PM'),
(8, 'cat2', '1', '12/09/18 , 17:26 PM'),
(7, 'cat1', '1', '12/09/18 , 17:26 PM'),
(12, 'cat6', '1', '13/09/18 , 08:48 AM'),
(13, 'cat5', '1', '13/09/18 , 08:48 AM'),
(14, 'cat7', '1', '13/09/18 , 08:48 AM'),
(15, 'cat8', '1', '13/09/18 , 13:30 PM');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_codes`
--

CREATE TABLE `tbl_codes` (
  `code_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT 0,
  `site_id` int(10) NOT NULL DEFAULT 0,
  `code_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `code` text CHARACTER SET utf8 DEFAULT NULL,
  `url` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `site_type` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `code_type` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `code_size` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `filter` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `code_balance` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `code_cpm` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `code_views` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `code_clicks` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `status` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2' COMMENT '1=active,2=inactive',
  `token` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_config`
--

CREATE TABLE `tbl_config` (
  `config_id` int(11) NOT NULL,
  `header` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `value` text CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Déchargement des données de la table `tbl_config`
--

INSERT INTO `tbl_config` (`config_id`, `header`, `value`) VALUES
(1, 'name', 'ProAds'),
(2, 'ref_percent', '5'),
(3, 'min_deposit', '10'),
(4, 'sumbole', '$'),
(5, 'with_min', '10.00'),
(6, 'reCAPTCHA_site_key', ''),
(7, 'reCAPTCHA_secret_key', ''),
(8, 'fake_deals', '0'),
(9, 'icon_url', 'https://codsem.com/proads/template/Uploads/favicon.png'),
(10, 'site_description', 'New Style Ad network'),
(11, 'site_title', 'New Style Ad network'),
(12, 'site_urlnon', ''),
(13, 'language', 'en_US'),
(14, 'support_email', ''),
(15, 'head_code', ''),
(16, 'footer_code', 'ICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TdGlsbCBoYXZlIHF1ZXN0aW9ucz8NCiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9J21haWx0bzppbmZvQGNvZGVzZW0uY29tJyBzdHlsZT0nY29sb3I6ICM0Mzc1ZDk7Jz5Db250YWN0IHVzPC9zcGFuPjwvYT4NCiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPg0KICAgICAgICAgICAgICAgICAgICA8YnI+DQogICAgICAgICAgICAgICAgICAgIDxzcGFuPsKpIDIwMTggUHJvQWRzLCBUTEQuIEFsbCByaWdodHMgcmVzZXJ2ZWQuPC9zcGFuPg=='),
(17, 'referral_publisher', '1'),
(18, 'currency', 'USD'),
(19, 'rules', 'PGg0PlRoZSBVc2VyIGlzIHByb2hpYml0ZWQgZnJvbTo8L2g0Pg0KDQo8dWw+DQoJPGxpPjxzdHJvbmc+U2NyZXdpbmcgcmVmZXJyYWxzOzwvc3Ryb25nPjwvbGk+DQoJPGxpPjxzdHJvbmc+SW5zdWx0IGFkbWluaXN0cmF0aW9uOzwvc3Ryb25nPjwvbGk+DQoJPGxpPjxzdHJvbmc+QW55IGF0dGVtcHQgdG8gZnJhdWQgdGhlIHN5c3RlbTs8L3N0cm9uZz48L2xpPg0KCTxsaT48c3Ryb25nPlVzZSBzcGFtIHRvIGF0dHJhY3QgbmV3IHBhcnRpY2lwYW50cyB0byB0aGUgc3lzdGVtOzwvc3Ryb25nPjwvbGk+DQoJPGxpPjxzdHJvbmc+TW90aXZhdGVkIHJlZmVycmFsczs8L3N0cm9uZz48L2xpPg0KCTxsaT48c3Ryb25nPkNyZWF0ZSBtdWx0aXBsZSBhY2NvdW50cyBpbiB0aGUgc3lzdGVtPC9zdHJvbmc+PC9saT4NCjwvdWw+DQo='),
(20, 'terms', 'PHA+PGVtPjxzdHJvbmc+PHNwYW4gc3R5bGU9ImNvbG9yOiNlNzRjM2MiPiZsdDstLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBZT1VSIFRFUk1TIENPTlRFTlQgSEVSRSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tJmd0Ozwvc3Bhbj48L3N0cm9uZz48L2VtPjwvcD4NCg=='),
(21, 'policy', 'PHA+PGVtPjxzdHJvbmc+PHNwYW4gc3R5bGU9ImNvbG9yOiNlNzRjM2MiPiZsdDstLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBZT1VSIFBPTElDWSBDT05URU5UIEhFUkUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSZndDs8L3NwYW4+PC9zdHJvbmc+PC9lbT48L3A+DQo='),
(22, 'app_version', '2.4.0'),
(23, 'banner_728x90', '1'),
(24, 'banner_468x60', '1'),
(25, 'banner_336x280', '1'),
(26, 'banner_300x250', '1'),
(27, 'banner_300x600', '1'),
(28, 'logo_url', 'https://codsem.com/proads/template/Uploads/board-logo.png'),
(29, 'logo_url_home', 'https://codsem.com/proads/template/Uploads/home-logo.png'),
(30, 'account_activate_email', '2'),
(31, 'enable_banner', '1'),
(32, 'enable_popup', '1'),
(33, 'member_head', ''),
(34, 'admin_head', ''),
(35, 'site_status', '2'),
(36, 'cpm_views', '0.50'),
(37, 'views_min', '1000'),
(38, 'clicks_min', '1000'),
(39, 'ads_persite', '5'),
(40, 'ads_perpage', '3'),
(41, 'admin_percent', '20'),
(42, 'cpc_click', '10.00'),
(43, 'enable_note', '1'),
(44, 'body_code', ''),
(45, 'auth_head', ''),
(46, 'dashboard_color', '#00a65a'),
(47, 'home_color', '#00a65a'),
(48, 'cpm_pop', '0.08'),
(49, 'cpc_pop', '0.08'),
(50, 'cpm_direct', '0.05'),
(51, 'pop_clicks', '1000'),
(52, 'pop_views', '1000'),
(53, 'direct_hits', '1000'),
(54, 'captcha_type', 'recaptcha'),
(55, 'captcha_signup', '2'),
(56, 'captcha_login', '2'),
(57, 'captcha_forgot', '2'),
(58, 'che2ckout_id', ''),
(59, 'che2ckout_secret', ''),
(60, 'enable_bank', '2'),
(61, 'bank_account', '<td>Account Holder</td><td>Account</td></tr><tr><td>Bank Name</td><td>Name</td></tr><tr><td>Bank City or Town</td><td>City/Town</td></tr><tr><td>Account Number</td><td>Number</td></tr><tr><td>SWIFT</td><td>SWIFT</td></tr><tr><td>IBAN</td><td>IBAN</td></tr><tr><td>Account Currency</td><td>Currency</td>'),
(62, 'banner_120x600', '2'),
(63, 'banner_200x200', '2'),
(64, 'banner_125x125', '2'),
(65, 'enable_direct', '1'),
(66, 'keywords', 'keyword1,keyword2,keyword3'),
(67, 'enable_sites_category', '1'),
(68, 'enable_rcd_tabs', '2'),
(69, 'enable_send_info', '1'),
(70, 'enable_text_b', '1'),
(71, 'disable_advertiser', '2'),
(72, 'disable_publishers', '2'),
(73, 'max_ip_day', '20'),
(74, 'fhb_api', '');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_direct`
--

CREATE TABLE `tbl_direct` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT 0,
  `direct_url` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `clicks` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `spend` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `price` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `direct_price` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `direct_clicks` varchar(600) CHARACTER SET utf8 DEFAULT NULL,
  `direct_country` varchar(1500) CHARACTER SET utf8 DEFAULT NULL,
  `direct_device` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `category` varchar(300) DEFAULT NULL,
  `status` enum('1','2','3','4','5') NOT NULL DEFAULT '2' COMMENT '1=active ,2= inactive , 3=completed ,4= pending,5= rejected',
  `filter` varchar(100) CHARACTER SET utf8 NOT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `role` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tbl_direct`
--

INSERT INTO `tbl_direct` (`id`, `user_id`, `direct_url`, `name`, `clicks`, `spend`, `price`, `direct_price`, `direct_clicks`, `direct_country`, `direct_device`, `status`, `filter`, `created`, `role`) VALUES
(1, 1, 'http://example.com', 'Default Direct', '0', '0.00000', '0.00000', '0.00000', '0', '["ALL"]', 'ALL', '1', 'clean', '24/02/18 , 16:35 PM', '2');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_invoice`
--

CREATE TABLE `tbl_invoice` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT 0,
  `amount` decimal(20,2) NOT NULL DEFAULT 0.00,
  `method` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `token` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `status` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2' COMMENT '1=paid,2=unpaid',
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_link`
--

CREATE TABLE `tbl_link` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT 0,
  `url` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `fraud` int(10) DEFAULT 0,
  `hits` int(10) NOT NULL DEFAULT 0,
  `earn` decimal(20,3) NOT NULL DEFAULT 0.000,
  `site_type` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `status` enum('1','2','3','4','5') NOT NULL DEFAULT '2' COMMENT '1=active, 2=pending, 3=banned, 4=rejected',
  `modified` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_popup`
--

CREATE TABLE `tbl_popup` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT 0,
  `popup_url` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `views` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `clicks` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `spend` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `price` decimal(20,3) NOT NULL DEFAULT 0.000,
  `popup_price` decimal(20,3) NOT NULL DEFAULT 0.000,
  `popup_views` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `popup_clicks` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `popup_country` varchar(1500) CHARACTER SET utf8 DEFAULT NULL,
  `popup_device` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `type_spend` enum('views','clicks') CHARACTER SET utf8 NOT NULL,
  `category` varchar(300) DEFAULT NULL,
  `status` int(10) DEFAULT 2 COMMENT '1=active ,2= inactive , 3=completed ,4= pending,5= unpaid',
  `filter` varchar(100) CHARACTER SET utf8 NOT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `role` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tbl_popup`
--

INSERT INTO `tbl_popup` (`id`, `user_id`, `popup_url`, `name`, `views`, `clicks`, `spend`, `price`, `popup_price`, `popup_views`, `popup_clicks`, `popup_country`, `popup_device`, `type_spend`, `status`, `filter`, `created`, `role`) VALUES
(1, 1, 'http://example.com', 'Default Popup', '0', '0', '0.00000', '0.000', '0.000', NULL, '0', '["ALL"]', 'ALL', 'clicks', 1, 'clean', '24/02/18 , 16:35 PM', '2');

-- --------------------------------------------------------


--
-- Structure de la table `tbl_stat`
--

CREATE TABLE `tbl_stat` (
  `id` int(10) NOT NULL,
  `code_id` int(10) NOT NULL DEFAULT 0,
  `pub_id` int(10) NOT NULL DEFAULT 0,
  `adv_id` int(10) NOT NULL DEFAULT 0,
  `url` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `referral_id` int(10) NOT NULL DEFAULT 0,
  `ad_type` enum('1','2','3') CHARACTER SET utf8 DEFAULT NULL COMMENT '1=banner,2=popup,3=direct',
  `campaign_id` int(10) DEFAULT NULL,
  `ip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `referer_domain` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `referer` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `admin_earn` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `publisher_earn` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `referral_earn` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `views` int(10) NOT NULL DEFAULT 0,
  `clicks` int(10) NOT NULL DEFAULT 0,
  `type_cam` enum('1','2','3','4') CHARACTER SET utf8 DEFAULT NULL COMMENT '1=Earn,2= IP Changed, 3=Don''t count,4= Fraud',
  `date` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_themes`
--

CREATE TABLE `tbl_themes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `version` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `status` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2' COMMENT '1=active,2=inactive',
  `created` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tbl_themes`
--

INSERT INTO `tbl_themes` (`id`, `name`, `version`, `status`, `created`) VALUES
(1, 'Main', '1.1.0', '1', '21/04/18 , 09:20 AM'),
(2, 'Dark', '1.0.0', '2', '21/04/18 , 09:20 AM');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(2) UNSIGNED NOT NULL DEFAULT 1 COMMENT '1=active, 2=pending, 3=inactive',
  `username` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `password` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `email` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `parent_id` int(11) UNSIGNED DEFAULT NULL,
  `advertiser_balance` decimal(20,3) NOT NULL DEFAULT 0.000,
  `publisher_earnings` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `admin_earnings` decimal(20,3) NOT NULL DEFAULT 0.000,
  `referral_earnings` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `withdrawal_method` varchar(250) COLLATE utf8_persian_ci DEFAULT NULL,
  `withdrawal_account` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `first_name` varchar(250) COLLATE utf8_persian_ci DEFAULT NULL,
  `last_name` varchar(250) COLLATE utf8_persian_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `reset` int(11) NOT NULL DEFAULT 0,
  `recover` varchar(250) COLLATE utf8_persian_ci DEFAULT NULL,
  `login_ip` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `register_ip` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `created` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `modified` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `token` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_withdrawal`
--

CREATE TABLE `tbl_withdrawal` (
  `withdrawal_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT 0,
  `amount` decimal(20,5) UNSIGNED NOT NULL DEFAULT 0.00000,
  `fee` decimal(20,5) NOT NULL DEFAULT 0.00000,
  `withdrawal_account` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `withdrawal_method` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `status` enum('1','2','3','4') COLLATE utf8_persian_ci NOT NULL DEFAULT '2' COMMENT '1=Approved, 2=Pending, 3=Complete, 4=Denied',
  `created` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Structure de la table `withdraw_methods`
--

CREATE TABLE `withdraw_methods` (
  `id` int(10) NOT NULL,
  `methods` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `fee` decimal(20,5) DEFAULT 0.00000,
  `withdraw_min` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL COMMENT '1= active,2=inactive'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `withdraw_methods`
--

INSERT INTO `withdraw_methods` (`id`, `methods`, `type`, `fee`, `withdraw_min`, `status`) VALUES
(1, 'Bitcoin', 'manual', '0.00000', '30.00', '1'),
(2, 'PayPal', 'manual', '0.00000', '5.00', '1'),
(3, 'Payza', 'manual', '0.00000', '5.00', '1'),
(10, 'FaucetHub', 'manual', '0.00000', '0.00', '1');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `deposite_methods`
--
ALTER TABLE `deposite_methods`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_history`
--
ALTER TABLE `log_history`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_banned`
--
ALTER TABLE `tbl_banned`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_cat`
--
ALTER TABLE `tbl_cat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  ADD PRIMARY KEY (`code_id`);

--
-- Index pour la table `tbl_config`
--
ALTER TABLE `tbl_config`
  ADD PRIMARY KEY (`config_id`);

--
-- Index pour la table `tbl_direct`
--
ALTER TABLE `tbl_direct`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_invoice`
--
ALTER TABLE `tbl_invoice`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_link`
--
ALTER TABLE `tbl_link`
  ADD UNIQUE KEY `link_id` (`link_id`);

--
-- Index pour la table `tbl_popup`
--
ALTER TABLE `tbl_popup`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_stat`
--
ALTER TABLE `tbl_stat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_themes`
--
ALTER TABLE `tbl_themes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Index pour la table `tbl_withdrawal`
--
ALTER TABLE `tbl_withdrawal`
  ADD PRIMARY KEY (`withdrawal_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `deposite_methods`
--
ALTER TABLE `deposite_methods`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `log_history`
--
ALTER TABLE `log_history`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT pour la table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tbl_banned`
--
ALTER TABLE `tbl_banned`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `tbl_cat`
--
ALTER TABLE `tbl_cat`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  MODIFY `code_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT pour la table `tbl_config`
--
ALTER TABLE `tbl_config`
  MODIFY `config_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT pour la table `tbl_direct`
--
ALTER TABLE `tbl_direct`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `tbl_invoice`
--
ALTER TABLE `tbl_invoice`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `tbl_link`
--
ALTER TABLE `tbl_link`
  MODIFY `link_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `tbl_popup`
--
ALTER TABLE `tbl_popup`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `tbl_stat`
--
ALTER TABLE `tbl_stat`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT pour la table `tbl_themes`
--
ALTER TABLE `tbl_themes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `tbl_withdrawal`
--
ALTER TABLE `tbl_withdrawal`
  MODIFY `withdrawal_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD CONSTRAINT `tbl_user_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `tbl_user` (`user_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
