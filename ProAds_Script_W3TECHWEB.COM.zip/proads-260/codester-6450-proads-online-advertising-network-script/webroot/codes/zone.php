<?php
//==============================  DESCRIPTIOPN ===============================//
//For every visitor will show a popup ,When visitor click popup appear & sleep for 2m
//Max click & views count by default are 20 / we count only 20 visit per ip in 24h
//Change max coutning per ip in 24h in => Admin Panel => Settings => Security
//==============================  DESCRIPTIOPN ===============================//

 require_once(dirname(dirname(__FILE__)).'/loader.php');
 
 if (!isset($_GET['rcd'])):
     
 exit('NOT ALLOWED');
 
 endif;

 if(isset($_GET['rcd'])){

 //decode

 $rcd = base64_decode($_GET['rcd']);

 $zone = $query->addquery('select','tbl_codes','*','i',$rcd,'code_id=?');

 if (!$zone):
     
 exit('Error: Zone Not Found !');

 endif;
 
 if ($zone->status != '1'):
     
 exit('Error: Zone Inactive!');

 endif;

 if ($zone->status == '1'){

 $ref = $query->addquery('select','tbl_user','parent_id','i',$zone->user_id,'user_id=?');
 
 $country = ip_visitor_country();
 
 $referer = $fun->referer(isset($_SERVER['HTTP_REFERER']));
 
 $paid = $query->PaidPopup();

 $device = $query->addquery('select','tbl_popup',' count(id) as num','si',detectDevice().',1','popup_device=?,status=?');
 
 if ($device->num > 0):
     
 $deviceRole = detectDevice();
     
 else:
     
 $deviceRole = 'ALL';
     
 endif;
 
 $countries = $query->CoPopup($country->code);
 
 if ($countries->num > 0):
     
 $countryRole = $country->code;
     
 else:
     
 $countryRole = 'ALL';
     
 endif;
 
 
 //VIEW
 if(!isset($_GET['clicked'])){
 
 $allowed = json_decode($zone->filter);
 
 $imploded = implode("','", $allowed);

 if ($paid->nu > 0):
 
 $campaign = $query->getPopup($deviceRole, $imploded, $countryRole, 1);

 else:
 
 $campaign = $query->getPopup($deviceRole, $imploded, $countryRole, 2);

 endif;
 
 if ($campaign == NULL):
     
 errorAndDie('Please create at least one default '.$zone->code_type);

 endif;

 $advertiser = $query->addquery('select','tbl_popup','user_id','i',$campaign->id,'id=?');

 $fraud = $query->addquery('select','tbl_user','login_ip,register_ip','i',$zone->user_id,'user_id=?');
 
 $access = $query->countAccess($ip_visit);

 if($campaign->role != '1'):
    
 //default campaign
 
 $url = $HOST.'codes/zone?clicked='.base64_encode($campaign->id).'&rcd='.base64_encode($rcd).'&id='.hash('sha256', $zone->code_id.$campaign->id.$country->code.$ip_visit.$zone->token);
 
 else:
    
    
 if($campaign->popup_views != $campaign->views && $access->access_ip < $option[72][0] && !isset($_COOKIE['pop_seen'])):

 //calucate

 $pub_earn = number_format($campaign->popup_price / $campaign->popup_views, 5, '.', '');

 $ref_earn = number_format(($option[1][0] / 100) * $pub_earn, 5, '.', '');

 
 if($fraud->login_ip == $ip_visit || $fraud->register_ip == $ip_visit || $user->user_id == $zone->user_id):

 //fraud
 
 $query->addquery('insert','tbl_stat','code_id,pub_id,adv_id,url,referral_id,ad_type,campaign_id,ip,country,referer_domain,referer,publisher_earn,referral_earn,views,clicks,type_cam,date,created','iiisisisssssssssss',[$rcd,$zone->user_id,$advertiser->user_id,$zone->url,'0','2',$campaign->id,$ip_visit,$country->name,$zone->url,$zone->url,'0.00000','0.00000','1','0','4',$current_day,$dateForm]);

 else:

 if($option[16][0] == '1' && !empty($ref->parent_id) && $campaign->type_spend == 'views'):

 $query->addquery('update','tbl_user','publisher_earnings=publisher_earnings+?,referral_earnings=referral_earnings+?','ssi',[$ref_earn,$ref_earn,$ref_id],'user_id=?');

 endif;

 if ($campaign->type_spend == 'views'):

 $query->addquery('insert','tbl_stat','code_id,pub_id,adv_id,url,referral_id,ad_type,campaign_id,ip,country,referer_domain,referer,publisher_earn,referral_earn,views,clicks,type_cam,date,created','iiisisisssssssssss',[$rcd,$zone->user_id,$advertiser->user_id,$zone->url,'0','2',$campaign->id,$ip_visit,$country->name,$zone->url,$zone->url,$pub_earn,'0.00000','1','0','1',$current_day,$dateForm]);

 $query->addquery('update','tbl_popup','spend=spend+?,views=views+?','siis',[$pub_earn,'1',$campaign->id,'views'],'id=?,type_spend=?');

 $query->addquery('update','tbl_codes','code_balance=code_balance+?,code_views=code_views+?','siii',[$pub_earn,'1',$campaign->id,$rcd,'1'],'code_id=?,status=?');

 $query->addquery('update','tbl_user','publisher_earnings=publisher_earnings+?','si',[$pub_earn,$zone->user_id],'user_id=?');

 else:

 $query->addquery('insert','tbl_stat','code_id,pub_id,adv_id,url,referral_id,ad_type,campaign_id,ip,country,referer_domain,referer,publisher_earn,referral_earn,views,clicks,type_cam,date,created','iiisisisssssssssss',[$rcd,$zone->user_id,$advertiser->user_id,$zone->url,'0','2',$campaign->id,$ip_visit,$country->name,$zone->url,$zone->url,'0.00000','0.00000','1','0','1',$current_day,$dateForm]);

 $query->addquery('update','tbl_popup','views=views+?','ii',['1',$campaign->id],'id=?');

 $query->addquery('update','tbl_codes','code_views=code_views+?','ii',['1',$rcd],'code_id=?');

 endif;

 endif;

 endif;

 //completed

 if($campaign->popup_views == $campaign->views):

 $query->addquery('update','tbl_popup','status=?','ii',['3',$campaign->id],'id=?');

 endif;

 //url
 
 $url = $HOST.'codes/zone?clicked='.base64_encode($campaign->id).'&rcd='.base64_encode($rcd).'&id='.hash('sha256', $zone->code_id.$campaign->id.$country->code.$ip_visit.$zone->token);
 
 endif;

     
 
 //show popup <script> / if visitor doesn't seen it yet 
 
 if ( !isset($_COOKIE['pop_seen'])):
 
 header("Content-Type: application/javascript");

 echo 'var homepage = document.querySelector("body");

    var popUp = function(e) {
      window.open ("'.$url.'", "Window","status=1,toolbar=1,width=800,height=700,top=300,left=250,resizable=yes");
      homepage.removeEventListener("click", popUp, false);
    }
    homepage.addEventListener("click", popUp, false);';

 endif;
 
 }
 
 }

 
}

 if(isset($_GET['clicked'])){

 //decoded

 $id = base64_decode($_GET['clicked']);

 $rcd = base64_decode($_GET['rcd']);

 $token = $_GET['id'];

 $campaign = $query->clickedPopup($id);

 $zone = $query->addquery('select','tbl_codes','user_id,url,token','i',$rcd,'code_id=?');

 $ref = $query->addquery('select','tbl_user','parent_id','i',$zone->user_id,'user_id=?');

 //set cookie
 
 setcookie('pop_seen', 1, time()+ 60*2, '/', $zone->url);
 
 if ($token == hash('sha256', $rcd.$campaign->id.$country->code.$ip_visit.$zone->token)):
 
 $advertiser = $query->addquery('select','tbl_popup','user_id','i',$campaign->id,'id=?');

 $fraud = $query->addquery('select','tbl_user','login_ip,register_ip','i',$zone->user_id,'user_id=?');

 $access = $query->countAccess($ip_visit);

 if($campaign->role != '1'):

 //default campaign

 switch($option[68][0]):
     
 case '1' :
    
 if(startsWith($campaign->popup_url, 'https://') || startsWith($campaign->popup_url, 'http://')):
     
 header('location:'. $campaign->popup_url.'?utm_source='.$option[0][0].'&utm_campaign='.$campaign->id.'&utm_ip='.$ip_visit.'&utm_country='.$country->name);

 else:

 header('location:'. 'http://'.$campaign->popup_url.'?utm_source='.$option[0][0].'&utm_campaign='.$campaign->id.'&utm_ip='.$ip_visit.'&utm_country='.$country->name);
     
 endif;

 exit;
 
 break;
 
 case '2' :
     
 if(startsWith($campaign->popup_url, 'https://') || startsWith($campaign->popup_url, 'http://')):
     
 header('location:'. $campaign->popup_url);

 else:

 header('location:'. 'http://'.$campaign->popup_url);

 endif;
     
 exit;
 
 break;
 
 endswitch;

 
 else:

 if($campaign->popup_clicks != $campaign->clicks && $access->access_ip < $option[72][0]):

 $pub_earn = number_format($campaign->popup_price / $campaign->popup_clicks, 5, '.', '');

 $ref_earn = number_format(($option[1][0] / 100) * $pub_earn, 5, '.', '');

 //fraud

 if($fraud->login_ip == $ip_visit || $fraud->register_ip == $ip_visit  || $user->user_id == $zone->user_id):

 $query->addquery('insert','tbl_stat','code_id,pub_id,adv_id,url,referral_id,ad_type,campaign_id,ip,country,referer_domain,referer,publisher_earn,referral_earn,views,clicks,type_cam,date,created','iiisisisssssssssss',[$rcd,$zone->user_id,$advertiser->user_id,$zone->url,'0','2',$campaign->id,$ip_visit,$country->name,$zone->url,$zone->url,'0.00000','0.00000','0','1','4',$current_day,$dateForm]);

 else:

 if($option[16][0] == '1' && !empty($ref->parent_id) && $campaign->type_spend == 'clicks'):

 $query->addquery('update','tbl_user','publisher_earnings=publisher_earnings+?,referral_earnings=referral_earnings+?','ssi',[$ref_earn,$ref_earn,$ref->parent_id],'user_id=?');

 endif;

if ($campaign->type_spend == 'clicks'):

$query->addquery('insert','tbl_stat','code_id,pub_id,adv_id,url,referral_id,ad_type,campaign_id,ip,country,referer_domain,referer,publisher_earn,referral_earn,views,clicks,type_cam,date,created','iiisisisssssssssss',[$rcd,$zone->user_id,$advertiser->user_id,$zone->url,'0','2',$campaign->id,$ip_visit,$country->name,$zone->url,$zone->url,$pub_earn,'0.00000','0','1','1',$current_day,$dateForm]);

$query->addquery('update','tbl_popup','spend=spend+?,clicks=clicks+?','siis',[$pub_earn,'1',$campaign->id,'clicks'],'id=?,type_spend=?');

$query->addquery('update','tbl_codes','code_balance=code_balance+?,code_clicks=code_clicks+?','siii',[$pub_earn,'1',$campaign->id,$rcd,'1'],'code_id=?,status=?');

$query->addquery('update','tbl_user','publisher_earnings=publisher_earnings+?','si',[$pub_earn,$zone->user_id],'user_id=?');

else:

$query->addquery('insert','tbl_stat','code_id,pub_id,adv_id,url,referral_id,ad_type,campaign_id,ip,country,referer_domain,referer,publisher_earn,referral_earn,views,clicks,type_cam,date,created','iiisisisssssssssss',[$rcd,$zone->user_id,$advertiser->user_id,$zone->url,'0','2',$campaign->id,$ip_visit,$country->name,$zone->url,$zone->url,'0.00000','0.00000','0','1','1',$current_day,$dateForm]);

$query->addquery('update','tbl_popup','clicks=clicks+?','ii',['1',$campaign->id],'id=?');

$query->addquery('update','tbl_codes','code_clicks=code_clicks+?','ii',['1',$rcd],'code_id=?');

endif;

endif;

//here was

endif;

if($campaign->popup_clicks == $campaign->clicks && $campaign->role == '1'):

//completed
$query->addquery('update','tbl_popup','status=?','ii',['3',$campaign->id],'id=?');

endif;

 //paid campaign

 switch($option[68][0]):
     
 case '1' :
 
  if(startsWith($campaign->popup_url, 'https://') || startsWith($campaign->popup_url, 'http://')):
     
 header('location:'. $campaign->popup_url.'?utm_source='.$option[0][0].'&utm_campaign='.$campaign->id.'&utm_ip='.$ip_visit.'&utm_country='.$country->name);

 else:

 header('location:'. 'http://'.$campaign->popup_url.'?utm_source='.$option[0][0].'&utm_campaign='.$campaign->id.'&utm_ip='.$ip_visit.'&utm_country='.$country->name);
     
 endif;

 exit;
 
 break;
 
 case '2' :
     
 if(startsWith($campaign->popup_url, 'https://') || startsWith($campaign->popup_url, 'http://')):
     
 header('location:'. $campaign->popup_url);

 else:

 header('location:'. 'http://'.$campaign->popup_url);

 endif;
     
 exit;
 
 break;
 
 endswitch;


 
endif;

endif;


 }


?>