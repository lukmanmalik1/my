<?php

require_once (dirname(dirname(__FILE__)).'/loader.php');

//Logged

if(IsLogged):
    
Redirect(['controller' => 'member', 'action' => 'dashboard']);

endif;


if( isset($_POST['register'] ) ){

$request = check_request('username');

$request = check_request('email',false,'email');

$request = check_request('password','md5');

$request = check_request('passwordcheck','md5');

$request = check_request('role');

if($sr->post() == 'true' && $request){

if(ReCaptcha($option['6']['0']) == true || $option['54']['0'] == '2'){

$data_user=$query->addquery('select','tbl_user','user_id','s',check_request('username'),'username=?');

$data_mail=$query->addquery('select','tbl_user','email','si',check_request('email',false,'email'),'1','email=?,status=?');


if($data_mail->email == check_request('email',false,'email')){

session_acv('reg_error','rep_emailreg');

Redirect(['controller' => 'auth', 'action' => 'signup']);
}

if(check_request('password','md5') != check_request('passwordcheck','md5')){

session_acv('reg_error','notmatchreg');

Redirect(['controller' => 'auth', 'action' => 'signup']);
}

if(check_request('role') == 'admin'){

errorAndDie('NOT ALLOWED! Trying to access as admin');

}

if(check_request('role') == 'advertiser' && $option[70][0] == 1){

exit('Sorry! Advertisers signup are closed.');

}

if(check_request('role') == 'publisher' && $option[71][0] == 1){

exit('Sorry! Publishers signup are closed.');

}


if($data_user){

session_acv('reg_error','repreg');

Redirect(['controller' => 'auth', 'action' => 'signup']);

}

if(check_request('password','md5') == check_request('passwordcheck','md5') && !$data && check_request('role') != 'admin')
{

$username = check_request('username');

$pass = check_request('password','md5');

$email = check_request('email',false,'email');

$role = check_request('role');

$recover = check_request('password','base64_encode');

 if(isset($_COOKIE['r'])):

$data = $query->addquery('insert','tbl_user','role,username,password,email,recover,parent_id,register_ip,created','sssssiss',[$role,$username,$pass,$email,$recover,$_COOKIE['r'],$ip_visit,$dateForm]);

 else:

$data = $query->addquery('insert','tbl_user','role,username,password,email,recover,register_ip,created','sssssss',[$role,$username,$pass,$email,$recover,$ip_visit,$dateForm]);

 endif;

if($option['29']['0'] == '2'){

session_acv('success','express_login');

Redirect(['controller' => 'auth', 'action' => 'login']);

}elseif($option['29']['0'] == '1'){

$bin_token = bin2hex(openssl_random_pseudo_bytes(16));

$mail_encode = check_request('email','base64_encode');

$query->addquery('update','tbl_user','status=?,token=?','isi',['2',$bin_token,$data],'user_id=?');

$GoMail->activation(["from"=> $option[13][0],"to"=> $_POST['email'],"username" => $_POST['username'],"token" => $bin_token,"enc_email" => $mail_encode]);

session_acv('success','mail_sent');

Redirect(['controller' => 'auth', 'action' => 'signup']);

}
	}

}
elseif(ReCaptcha($option['6']['0']) == false && $option['54']['0'] == '1'){

session_acv('reg_error','wrongreg');

Redirect(['controller' => 'auth', 'action' => 'signup']);
 }
}

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('reg_error','requiredreg');

Redirect(['controller' => 'auth', 'action' => 'signup']);
}
}
else{

//EXIST==EMAIL
alerts('reg_error','rep_emailreg');

//NOTMATCH==PASS
alerts('reg_error','notmatchreg');

//RECAPTCHA==WRONG
alerts('reg_error','wrongreg');

//REPEAT
alerts('reg_error','repreg');

//REQUIRED
alerts('reg_error','requiredreg'); 

//MAIL==SENT
alerts('success','mail_sent');
}

show('Auth/Signup/index');
?>