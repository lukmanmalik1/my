<?php

require_once (dirname(dirname(__FILE__)).'/loader.php');

//Logged

if(IsLogged):
    
Redirect(['controller' => 'member', 'action' => 'dashboard']);

endif;


if( isset($_POST['rec'] ) ){

if (empty($option[13][0])):

errorAndDie('Administration not specified their email');

endif;

$request = check_request('username');

if($sr->post() == 'true' && $request){

//true
if( ReCaptcha($option['6']['0']) == true || $option['56']['0'] == '2'){

$data = $query->addquery('select','tbl_user','email','s',$_POST['username'],'username=?');

$email_user = base64_encode($data->email);

$mail_decode = $data->email;

$token_user = bin2hex(openssl_random_pseudo_bytes(16));

$query->addquery('update','tbl_user','token=?','ss',[$token_user,$request],'username=?');

$GoMail->recover(["from"=> $option[13][0],"to"=> $mail_decode,"username" => $request,"token" => $token_user,"email" => $email_user]);

session_acv('success','sent');

Redirect(['controller' => 'auth', 'action' => 'rec']);

}
elseif(ReCaptcha($option['6']['0']) == false && $option['56']['0'] == '1'){
	
session_acv('errorec','wrong');

Redirect(['controller' => 'auth', 'action' => 'rec']);
}

}

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('errorec','required');

Redirect(['controller' => 'auth', 'action' => 'rec']);
}
}
else{

//WRONG
alerts('errorec','wrong');

//REQUIRED
alerts('errorec','required');

//SENT
alerts('success','sent');

}

show('Auth/Login/rec');

?>