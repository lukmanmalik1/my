<?php

require_once (dirname(dirname(__FILE__)).'/loader.php');

//Logged

if(IsLogged):
    
Redirect(['controller' => 'member', 'action' => 'dashboard']);

endif;

//============================ START RECOVER PASS ============================//

if( isset($_GET['req'])){

$reco_req = $_GET['req'];

$reco_email = base64_decode($_GET['tk']);

$data = $query->addquery('select','tbl_user','*','s',$reco_req,'token=?');

if($reco_req == $data->token){

$query->addquery('update','tbl_user','token=?','ss',[' ',$reco_email],'email=?');

$GoMail->Getpass(["from"=> $option[13][0],"to"=> $reco_email,"username" => $data->username,"recover"=> base64_decode($data->recover)]);

$_SESSION['success']['recovered']=true;

Redirect(['controller' => 'auth', 'action' => 'login']);

}else{

$_SESSION['error']['inrecover']=true;

Redirect(['controller' => 'auth', 'action' => 'login']);

}
}else{
    
alerts('success','recovered');

alerts('error','inrecover');

}


//=============================== START LOGIN ===============================//

if( isset($_POST['login'] ) ){

if ($sr->post() == 'true'){

if (ReCaptcha($option['6']['0']) == true || $option['55']['0'] == '2'){

$data=$query->addquery('select','tbl_user','user_id,password,status,role','s',check_request('username'),'username=?');

if($data->status == '2'){

session_acv('Usererror','pendinguser');

Redirect(['controller' => 'auth', 'action' => 'login']);

}

if($data->status == '3'){

session_acv('Usererror','banneduser');

Redirect(['controller' => 'auth', 'action' => 'login']);

}

//CORRECT
if($data->password == check_request('password','md5') && $data->status == '1'){

$_SESSION['user']['logged'] = true;

$_SESSION['user']['uid'] = $data->user_id;

$query->addquery('update','tbl_user','login_ip=?','si',[$ip_visit,$data->user_id],'user_id=?');

if($data->role == 'admin'):

if ($option['42']['0'] == 1):

$query->addquery('insert','log_history','ip,status,date','sis',[$ip_visit,'1',$dateForm]);

endif;

endif;

if($system->getSetting()['login_role_refrech'] == 'active'):

Redirect(['controller' => 'auth', 'action' => 'role']);

elseif($data->role == 'admin'):
    
Redirect(['controller' => 'admin', 'action' => 'dashboard']);

elseif($data->role == 'publisher'):

Redirect(['controller' => 'member', 'action' => 'dashboard']);

elseif($data->role == 'advertiser'):

Redirect(['controller' => 'advertiser', 'action' => 'dashboard']);

endif;

}

else{

session_acv('Usererror','invaliduser');

Redirect(['controller' => 'auth', 'action' => 'login']);

}

}elseif(ReCaptcha($option['6']['0']) == false && $option['55']['0'] == '1'){

session_acv('Usererror','wronguser');

Redirect(['controller' => 'auth', 'action' => 'login']);

}
 }

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('Usererror','requireduser');

Redirect(['controller' => 'auth', 'action' => 'login']);
}

}
else{
  //PENDING
alerts('Usererror','pendinguser');

    //BANNED
alerts('Usererror','banneduser');

    //INVALID
alerts('Usererror','invaliduser');

    //WRONG
alerts('Usererror','wronguser');

    //REQUIRED
alerts('Usererror','requireduser');


    //EXPIRED
alerts('success','expired');

    //ERROR
alerts('error','err');

    //ACTIVATED
alerts('success','activated');

    //WRONG_TOKEN
alerts('error','token_wrong');

    //GO_LOGIN
alerts('success','express_login');

}

show('Auth/Login/index');

//================================ END LOGIN =================================//
?>