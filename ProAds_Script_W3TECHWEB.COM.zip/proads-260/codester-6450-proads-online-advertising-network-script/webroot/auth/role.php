<?php

require_once (dirname(dirname(__FILE__)).'/loader.php');

if (strpos($_SERVER['HTTP_REFERER'], '/auth/login') && !empty($uid) && $uid != '0'):

$smarty->assign('admin',false);

if($user->role == 'publisher'){

$smarty->assign('user',$user->username);

//publisher

header( 'refresh:3;url='.$HOST.'member/dashboard');

}

elseif($user->role == 'advertiser'){

$smarty->assign('user',$user->username);

//advertiser

header('refresh:3;url='.$HOST.'advertiser/dashboard');

}

elseif($user->role == 'admin'){

$smarty->assign('admin',true);

if ($option['42']['0'] == '1'){

$_SESSION['success']['noteIp']=true;
}
else{

}

//admin

header('refresh:3;url='.$HOST.'admin/dashboard');

}else{

Redirect(['controller' => 'auth', 'action' => 'login']);

}else:

Redirect(['controller' => 'auth', 'action' => 'login']);

endif;

show('Auth/Login/role');
?>