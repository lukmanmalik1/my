<?php
//=============================== START ACTIVATE ACCOUNTS ====================//

require_once (dirname(dirname(__FILE__)).'/loader.php');

if( !isset($_GET['id'])):

exit('NOT ALLOWED');

endif;

$reg_token = $_GET['id'];

$reg_email = base64_decode($_GET['tk']);

$data = $query->addquery('select','tbl_user','token,email','s',$reg_token,'token=?');

if($reg_token == $data->token){

$data = $query->addquery('update','tbl_user','token=?,status=?','sis',[' ','1',$data->token],'token=?');

$_SESSION['success']['activated']=true;

Redirect(['controller' => 'auth', 'action' => 'login']);

}else{

$_SESSION['error']['token_wrong']=true;

Redirect(['controller' => 'auth', 'action' => 'login']);

}

//================================ END ACTIVATE ACCOUNTS =====================//
?>