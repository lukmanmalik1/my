<?php

//uploads limits

ini_set('upload_max_filesize','40M');

ini_set('post_max_size','40M');

//memory limit

ini_set('memory_limit', '512M');