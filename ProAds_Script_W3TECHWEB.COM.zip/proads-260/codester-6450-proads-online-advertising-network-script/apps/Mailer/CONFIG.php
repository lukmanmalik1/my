
<?php

$mail_option = 'smtp';

$mail_username = 'doblzero@gmail.com';

$mail_host = 'smtp.gmail.com';

$mail_port = '587';

$mail_ssluse = 'tls';

$mail_pass = 'Blobllo2233';
